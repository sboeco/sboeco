"use client"

import { createContext, useContext, useState, useEffect, useRef } from "react"

const WishlistContext = createContext({
  items: [],
  addToWishlist: () => {},
  removeFromWishlist: () => {},
  isInWishlist: () => false,
  clearWishlist: () => {},
  getWishlistCount: () => 0,
})

export const useWishlist = () => useContext(WishlistContext)

export function WishlistProvider({ children }) {
  const [wishlist, setWishlist] = useState([])
  const isMounted = useRef(true)

  // Load wishlist from localStorage on initial render
  useEffect(() => {
    try {
      const savedWishlist = localStorage.getItem("wishlist")
      if (savedWishlist) {
        const parsedWishlist = JSON.parse(savedWishlist)
        if (Array.isArray(parsedWishlist)) {
          setWishlist(parsedWishlist)
        }
      }
    } catch (error) {
      console.error("Error loading wishlist from localStorage:", error)
      // If there's an error, reset the wishlist
      localStorage.removeItem("wishlist")
    }

    return () => {
      isMounted.current = false
    }
  }, [])

  // Save wishlist to localStorage whenever it changes
  useEffect(() => {
    try {
      if (isMounted.current) {
        localStorage.setItem("wishlist", JSON.stringify(wishlist))
      }
    } catch (error) {
      console.error("Error saving wishlist to localStorage:", error)
    }
  }, [wishlist])

  const addToWishlist = (product) => {
    if (!product) return

    try {
      setWishlist((prevWishlist) => {
        // Check if product already exists in wishlist
        const existingItem = prevWishlist.find((item) => item.id === product.id)

        if (existingItem) {
          // Product already in wishlist, no need to add
          return prevWishlist
        } else {
          // Add new product to wishlist
          return [...prevWishlist, product]
        }
      })
    } catch (error) {
      console.error("Error adding item to wishlist:", error)
    }
  }

  const removeFromWishlist = (productId) => {
    if (!productId) return

    try {
      setWishlist((prevWishlist) => prevWishlist.filter((item) => item.id !== productId))
    } catch (error) {
      console.error("Error removing item from wishlist:", error)
    }
  }

  const isInWishlist = (productId) => {
    if (!productId) return false

    try {
      return wishlist.some((item) => item.id === productId)
    } catch (error) {
      console.error("Error checking if item is in wishlist:", error)
      return false
    }
  }

  const clearWishlist = () => {
    try {
      setWishlist([])
      localStorage.removeItem("wishlist")
    } catch (error) {
      console.error("Error clearing wishlist:", error)
    }
  }

  const getWishlistCount = () => {
    try {
      return wishlist.length
    } catch (error) {
      console.error("Error getting wishlist count:", error)
      return 0
    }
  }

  return (
    <WishlistContext.Provider
      value={{
        items: wishlist,
        addToWishlist,
        removeFromWishlist,
        isInWishlist,
        clearWishlist,
        getWishlistCount,
      }}
    >
      {children}
    </WishlistContext.Provider>
  )
}

