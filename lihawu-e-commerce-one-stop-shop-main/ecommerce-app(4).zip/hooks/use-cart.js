"use client"

import { createContext, useContext, useState, useEffect, useRef } from "react"

const CartContext = createContext({
  items: [],
  cartTotal: 0,
  addToCart: () => {},
  removeFromCart: () => {},
  updateQuantity: () => {},
  clearCart: () => {},
  getCartItemCount: () => 0,
})

export const useCart = () => useContext(CartContext)

export function CartProvider({ children }) {
  const [cart, setCart] = useState([])
  const [cartTotal, setCartTotal] = useState(0)
  const isMounted = useRef(true)

  // Load cart from localStorage on initial render
  useEffect(() => {
    try {
      const savedCart = localStorage.getItem("cart")
      if (savedCart) {
        const parsedCart = JSON.parse(savedCart)
        if (Array.isArray(parsedCart)) {
          setCart(parsedCart)
        }
      }
    } catch (error) {
      console.error("Error loading cart from localStorage:", error)
      // If there's an error, reset the cart
      localStorage.removeItem("cart")
    }

    return () => {
      isMounted.current = false
    }
  }, [])

  // Update cart total whenever cart changes
  useEffect(() => {
    try {
      const total = cart.reduce((sum, item) => {
        const price = item.salePrice || item.price
        const numericPrice = typeof price === "number" ? price : Number(price) || 0
        return sum + numericPrice * item.quantity
      }, 0)

      if (isMounted.current) {
        setCartTotal(total)
        // Save cart to localStorage
        localStorage.setItem("cart", JSON.stringify(cart))
      }
    } catch (error) {
      console.error("Error updating cart total:", error)
    }
  }, [cart])

  const addToCart = (product, quantity = 1) => {
    if (!product) return

    try {
      setCart((prevCart) => {
        // Check if product already exists in cart
        const existingItemIndex = prevCart.findIndex((item) => item.id === product.id)

        if (existingItemIndex !== -1) {
          // Update quantity if product already exists
          const updatedCart = [...prevCart]
          updatedCart[existingItemIndex] = {
            ...updatedCart[existingItemIndex],
            quantity: updatedCart[existingItemIndex].quantity + quantity,
          }
          return updatedCart
        } else {
          // Add new product to cart
          return [...prevCart, { ...product, quantity }]
        }
      })
    } catch (error) {
      console.error("Error adding item to cart:", error)
    }
  }

  const removeFromCart = (productId) => {
    if (!productId) return

    try {
      setCart((prevCart) => prevCart.filter((item) => item.id !== productId))
    } catch (error) {
      console.error("Error removing item from cart:", error)
    }
  }

  const updateQuantity = (productId, quantity) => {
    if (!productId || quantity < 1) return

    try {
      setCart((prevCart) => {
        return prevCart.map((item) => {
          if (item.id === productId) {
            return { ...item, quantity }
          }
          return item
        })
      })
    } catch (error) {
      console.error("Error updating item quantity:", error)
    }
  }

  const clearCart = () => {
    try {
      setCart([])
      localStorage.removeItem("cart")
    } catch (error) {
      console.error("Error clearing cart:", error)
    }
  }

  const getCartItemCount = () => {
    try {
      return cart.reduce((count, item) => count + item.quantity, 0)
    } catch (error) {
      console.error("Error getting cart item count:", error)
      return 0
    }
  }

  return (
    <CartContext.Provider
      value={{
        items: cart,
        cartTotal,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        getCartItemCount,
      }}
    >
      {children}
    </CartContext.Provider>
  )
}

