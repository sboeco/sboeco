"use client"

import { useState, useEffect, useRef } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/components/auth-provider"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { ShoppingBag, Package, Truck, CheckCircle, Clock, AlertCircle } from "lucide-react"
import { collection, query, where, getDocs } from "firebase/firestore"
import { db } from "@/lib/firebase"
import Image from "next/image"
import Link from "next/link"

export default function OrdersPage() {
  const { user, loading: authLoading } = useAuth()
  const router = useRouter()
  const [orders, setOrders] = useState([])
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState("all")
  const isMounted = useRef(true)

  useEffect(() => {
    return () => {
      isMounted.current = false
    }
  }, [])

  useEffect(() => {
    if (!authLoading && !user) {
      router.push("/login")
      return
    }

    if (user) {
      fetchOrders()
    }
  }, [user, authLoading, router])

  // Update the fetchOrders function to avoid requiring a composite index
  const fetchOrders = async () => {
    try {
      setLoading(true)
      const ordersRef = collection(db, "orders")
      // Remove the orderBy to avoid requiring a composite index
      const q = query(ordersRef, where("userId", "==", user.uid))

      const querySnapshot = await getDocs(q)
      const ordersData = querySnapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }))

      // Sort the orders client-side instead
      ordersData.sort((a, b) => {
        return new Date(b.createdAt) - new Date(a.createdAt)
      })

      if (isMounted.current) {
        setOrders(ordersData)
        setLoading(false)
      }
    } catch (error) {
      console.error("Error fetching orders:", error)
      if (isMounted.current) {
        setLoading(false)
      }
    }
  }

  const getStatusBadge = (status) => {
    switch (status) {
      case "processing":
        return (
          <Badge variant="outline" className="bg-blue-50 text-blue-600 border-blue-200">
            Processing
          </Badge>
        )
      case "shipped":
        return (
          <Badge variant="outline" className="bg-amber-50 text-amber-600 border-amber-200">
            Shipped
          </Badge>
        )
      case "delivered":
        return (
          <Badge variant="outline" className="bg-green-50 text-green-600 border-green-200">
            Delivered
          </Badge>
        )
      case "cancelled":
        return (
          <Badge variant="outline" className="bg-red-50 text-red-600 border-red-200">
            Cancelled
          </Badge>
        )
      default:
        return <Badge variant="outline">Unknown</Badge>
    }
  }

  const getStatusIcon = (status) => {
    switch (status) {
      case "processing":
        return <Clock className="h-5 w-5 text-blue-500" />
      case "shipped":
        return <Truck className="h-5 w-5 text-amber-500" />
      case "delivered":
        return <CheckCircle className="h-5 w-5 text-green-500" />
      case "cancelled":
        return <AlertCircle className="h-5 w-5 text-red-500" />
      default:
        return <Package className="h-5 w-5" />
    }
  }

  const getDeliveryDate = (order) => {
    if (order.status === "delivered" && order.deliveredAt) {
      return new Date(order.deliveredAt).toLocaleDateString()
    }

    if (order.status === "shipped" && order.shippedAt) {
      // Estimate delivery in 3-5 days from shipped date
      const shippedDate = new Date(order.shippedAt)
      const minDelivery = new Date(shippedDate)
      minDelivery.setDate(minDelivery.getDate() + 3)

      const maxDelivery = new Date(shippedDate)
      maxDelivery.setDate(maxDelivery.getDate() + 5)

      return `${minDelivery.toLocaleDateString()} - ${maxDelivery.toLocaleDateString()}`
    }

    if (order.status === "processing") {
      return "Preparing for shipment"
    }

    if (order.status === "cancelled") {
      return "Order cancelled"
    }

    return "Pending"
  }

  const filteredOrders = activeTab === "all" ? orders : orders.filter((order) => order.status === activeTab)

  if (authLoading || loading) {
    return (
      <div className="flex-1 space-y-4 p-8 pt-6">
        <div className="flex items-center justify-center h-full">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
        </div>
      </div>
    )
  }

  return (
    <div className="flex-1 space-y-4 p-8 pt-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">My Orders</h2>
        <p className="text-muted-foreground">View and track your order history</p>
      </div>

      <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList>
          <TabsTrigger value="all">All Orders</TabsTrigger>
          <TabsTrigger value="processing">Processing</TabsTrigger>
          <TabsTrigger value="shipped">Shipped</TabsTrigger>
          <TabsTrigger value="delivered">Delivered</TabsTrigger>
        </TabsList>

        <TabsContent value={activeTab} className="space-y-4">
          {filteredOrders.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <ShoppingBag className="h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-xl font-medium mb-2">No orders found</h3>
                <p className="text-muted-foreground text-center max-w-md mb-6">
                  {activeTab === "all"
                    ? "You haven't placed any orders yet. Start shopping to see your orders here."
                    : `You don't have any ${activeTab} orders at the moment.`}
                </p>
                <Button asChild>
                  <Link href="/shop">Browse Products</Link>
                </Button>
              </CardContent>
            </Card>
          ) : (
            filteredOrders.map((order) => (
              <Card key={order.id} className="overflow-hidden">
                <CardHeader className="pb-3">
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-2">
                    <div>
                      <CardTitle className="text-lg">Order #{order.orderNumber}</CardTitle>
                      <CardDescription>Placed on {new Date(order.createdAt).toLocaleDateString()}</CardDescription>
                    </div>
                    <div className="flex flex-wrap items-center gap-3">
                      {getStatusBadge(order.status)}
                      <span className="font-medium">SZL {order.total.toFixed(2)}</span>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pb-3">
                  <div className="space-y-4">
                    <div className="flex flex-wrap items-center gap-3 text-sm">
                      <div className="flex items-center gap-1.5">
                        <Package className="h-4 w-4 text-muted-foreground" />
                        <span>
                          {order.items.length} {order.items.length === 1 ? "item" : "items"}
                        </span>
                      </div>
                      <Separator orientation="vertical" className="h-4 hidden sm:block" />
                      <div className="flex items-center gap-1.5">
                        <Truck className="h-4 w-4 text-muted-foreground" />
                        <span className="break-all sm:break-normal">Delivery: {getDeliveryDate(order)}</span>
                      </div>
                    </div>

                    <div className="space-y-3">
                      {order.items.slice(0, 3).map((item) => (
                        <div key={item.id} className="flex items-center gap-4">
                          <div className="relative h-12 w-12 sm:h-16 sm:w-16 rounded-md overflow-hidden flex-shrink-0">
                            <Image
                              src={item.images?.[0] || "/placeholder.svg?height=64&width=64"}
                              alt={item.name}
                              fill
                              className="object-cover"
                            />
                          </div>
                          <div className="flex-grow min-w-0">
                            <Link href={`/products/${item.id}`} className="font-medium hover:underline line-clamp-1">
                              {item.name}
                            </Link>
                            <div className="text-sm text-muted-foreground">
                              Qty: {item.quantity} × SZL {item.price.toFixed(2)}
                            </div>
                          </div>
                        </div>
                      ))}
                      {order.items.length > 3 && (
                        <div className="text-sm text-muted-foreground">+ {order.items.length - 3} more items</div>
                      )}
                    </div>

                    <div className="pt-2">
                      <h4 className="font-medium mb-2">Order Timeline</h4>
                      <div className="space-y-3">
                        <div className="flex items-start gap-3">
                          <div className="mt-0.5">
                            <CheckCircle className="h-5 w-5 text-green-500" />
                          </div>
                          <div>
                            <p className="font-medium">Order Placed</p>
                            <p className="text-sm text-muted-foreground">
                              {new Date(order.createdAt).toLocaleString()}
                            </p>
                          </div>
                        </div>

                        {order.status !== "cancelled" && (
                          <div className="flex items-start gap-3">
                            <div className="mt-0.5">
                              {order.status === "processing" ? (
                                <Clock className="h-5 w-5 text-blue-500" />
                              ) : (
                                <CheckCircle className="h-5 w-5 text-green-500" />
                              )}
                            </div>
                            <div>
                              <p className="font-medium">Processing</p>
                              <p className="text-sm text-muted-foreground">
                                {order.processingAt
                                  ? new Date(order.processingAt).toLocaleString()
                                  : order.status === "processing"
                                    ? "In progress"
                                    : "Completed"}
                              </p>
                            </div>
                          </div>
                        )}

                        {(order.status === "shipped" || order.status === "delivered") && (
                          <div className="flex items-start gap-3">
                            <div className="mt-0.5">
                              {order.status === "shipped" ? (
                                <Truck className="h-5 w-5 text-amber-500" />
                              ) : (
                                <CheckCircle className="h-5 w-5 text-green-500" />
                              )}
                            </div>
                            <div>
                              <p className="font-medium">Shipped</p>
                              <p className="text-sm text-muted-foreground">
                                {order.shippedAt
                                  ? new Date(order.shippedAt).toLocaleString()
                                  : "Preparing for shipment"}
                              </p>
                            </div>
                          </div>
                        )}

                        {order.status === "delivered" && (
                          <div className="flex items-start gap-3">
                            <div className="mt-0.5">
                              <CheckCircle className="h-5 w-5 text-green-500" />
                            </div>
                            <div>
                              <p className="font-medium">Delivered</p>
                              <p className="text-sm text-muted-foreground">
                                {order.deliveredAt ? new Date(order.deliveredAt).toLocaleString() : "Pending delivery"}
                              </p>
                            </div>
                          </div>
                        )}

                        {order.status === "cancelled" && (
                          <div className="flex items-start gap-3">
                            <div className="mt-0.5">
                              <AlertCircle className="h-5 w-5 text-red-500" />
                            </div>
                            <div>
                              <p className="font-medium">Cancelled</p>
                              <p className="text-sm text-muted-foreground">
                                {order.cancelledAt
                                  ? new Date(order.cancelledAt).toLocaleString()
                                  : "Order was cancelled"}
                              </p>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}

