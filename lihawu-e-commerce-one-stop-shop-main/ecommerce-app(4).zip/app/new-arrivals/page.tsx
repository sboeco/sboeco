import { NewArrivalsPage } from "@/components/new-arrivals-page"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "New Arrivals | EcoShop",
  description: "Discover our latest products and collections",
}

export default function NewArrivals() {
  return <NewArrivalsPage />
}

