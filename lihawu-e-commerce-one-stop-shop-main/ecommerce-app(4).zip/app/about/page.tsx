import type { Metadata } from "next"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, Users, ShieldCheck, Heart, Zap } from "lucide-react"

export const metadata: Metadata = {
  title: "About Us | EcoShop",
  description: "Learn about our story, mission, and the team behind EcoShop",
}

export default function AboutPage() {
  return (
    <div className="container px-4 md:px-6 py-12 mx-auto">
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-12">
          <Badge className="mb-4">Our Story</Badge>
          <h1 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl mb-4">About EcoShop</h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            We're on a mission to revolutionize online shopping in Eswatini with a focus on quality, sustainability, and
            exceptional customer experience.
          </p>
        </div>

        <div className="grid gap-12">
          {/* Hero section */}
          <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
            <div className="space-y-4">
              <h2 className="text-2xl font-bold tracking-tight">Our Vision</h2>
              <p className="text-muted-foreground">
                Founded in 2023, EcoShop began with a simple idea: to create an online shopping experience that
                prioritizes both people and the planet. We noticed a gap in the Eswatini market for a comprehensive
                e-commerce platform that offers high-quality products while maintaining ethical standards.
              </p>
              <p className="text-muted-foreground">
                Our vision is to become the leading e-commerce platform in Eswatini, known for exceptional customer
                service, curated quality products, and sustainable business practices. We believe that shopping online
                should be enjoyable, secure, and aligned with values that benefit our community and environment.
              </p>
            </div>
            <div className="relative aspect-video overflow-hidden rounded-lg">
              <img
                src="/placeholder.svg?height=400&width=600"
                alt="EcoShop team meeting"
                className="object-cover w-full h-full"
              />
            </div>
          </div>

          {/* Values section */}
          <div className="space-y-6">
            <div className="text-center">
              <h2 className="text-2xl font-bold tracking-tight">Our Core Values</h2>
              <p className="text-muted-foreground mt-2">These principles guide everything we do at EcoShop</p>
            </div>

            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
              <Card>
                <CardContent className="pt-6">
                  <div className="text-center space-y-4">
                    <div className="mx-auto bg-primary/10 p-3 rounded-full w-fit">
                      <Users className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="font-medium">Customer First</h3>
                    <p className="text-sm text-muted-foreground">
                      We prioritize our customers' needs and continuously improve based on their feedback.
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="text-center space-y-4">
                    <div className="mx-auto bg-primary/10 p-3 rounded-full w-fit">
                      <ShieldCheck className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="font-medium">Quality & Trust</h3>
                    <p className="text-sm text-muted-foreground">
                      We carefully curate our products and ensure secure, transparent transactions.
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="text-center space-y-4">
                    <div className="mx-auto bg-primary/10 p-3 rounded-full w-fit">
                      <Heart className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="font-medium">Sustainability</h3>
                    <p className="text-sm text-muted-foreground">
                      We promote eco-friendly products and implement sustainable business practices.
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="text-center space-y-4">
                    <div className="mx-auto bg-primary/10 p-3 rounded-full w-fit">
                      <Zap className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="font-medium">Innovation</h3>
                    <p className="text-sm text-muted-foreground">
                      We continuously evolve our platform to provide the best shopping experience.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Team section */}
          <div className="space-y-6">
            <div className="text-center">
              <h2 className="text-2xl font-bold tracking-tight">Meet Our Team</h2>
              <p className="text-muted-foreground mt-2">The passionate people behind EcoShop</p>
            </div>

            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
              <div className="text-center space-y-3">
                <div className="relative h-40 w-40 mx-auto overflow-hidden rounded-full">
                  <img
                    src="/placeholder.svg?height=160&width=160"
                    alt="Sarah Johnson"
                    className="object-cover w-full h-full"
                  />
                </div>
                <div>
                  <h3 className="font-medium">Sarah Johnson</h3>
                  <p className="text-sm text-muted-foreground">Founder & CEO</p>
                </div>
              </div>

              <div className="text-center space-y-3">
                <div className="relative h-40 w-40 mx-auto overflow-hidden rounded-full">
                  <img
                    src="/placeholder.svg?height=160&width=160"
                    alt="David Nkosi"
                    className="object-cover w-full h-full"
                  />
                </div>
                <div>
                  <h3 className="font-medium">David Nkosi</h3>
                  <p className="text-sm text-muted-foreground">CTO</p>
                </div>
              </div>

              <div className="text-center space-y-3">
                <div className="relative h-40 w-40 mx-auto overflow-hidden rounded-full">
                  <img
                    src="/placeholder.svg?height=160&width=160"
                    alt="Thandi Dlamini"
                    className="object-cover w-full h-full"
                  />
                </div>
                <div>
                  <h3 className="font-medium">Thandi Dlamini</h3>
                  <p className="text-sm text-muted-foreground">Head of Operations</p>
                </div>
              </div>

              <div className="text-center space-y-3">
                <div className="relative h-40 w-40 mx-auto overflow-hidden rounded-full">
                  <img
                    src="/placeholder.svg?height=160&width=160"
                    alt="Michael Chen"
                    className="object-cover w-full h-full"
                  />
                </div>
                <div>
                  <h3 className="font-medium">Michael Chen</h3>
                  <p className="text-sm text-muted-foreground">Marketing Director</p>
                </div>
              </div>
            </div>
          </div>

          {/* Why choose us section */}
          <div className="space-y-6">
            <div className="text-center">
              <h2 className="text-2xl font-bold tracking-tight">Why Choose EcoShop</h2>
              <p className="text-muted-foreground mt-2">What sets us apart from other e-commerce platforms</p>
            </div>

            <Tabs defaultValue="quality" className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="quality">Quality</TabsTrigger>
                <TabsTrigger value="delivery">Delivery</TabsTrigger>
                <TabsTrigger value="support">Support</TabsTrigger>
                <TabsTrigger value="security">Security</TabsTrigger>
              </TabsList>

              <TabsContent value="quality" className="p-6 border rounded-lg mt-6">
                <div className="grid gap-6 lg:grid-cols-2 items-center">
                  <div>
                    <h3 className="text-xl font-medium mb-4">Premium Product Quality</h3>
                    <div className="space-y-3">
                      <div className="flex items-start gap-2">
                        <CheckCircle className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                        <p className="text-muted-foreground">Rigorous quality control process for all products</p>
                      </div>
                      <div className="flex items-start gap-2">
                        <CheckCircle className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                        <p className="text-muted-foreground">Partnerships with trusted brands and suppliers</p>
                      </div>
                      <div className="flex items-start gap-2">
                        <CheckCircle className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                        <p className="text-muted-foreground">Authentic products with manufacturer warranties</p>
                      </div>
                      <div className="flex items-start gap-2">
                        <CheckCircle className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                        <p className="text-muted-foreground">Detailed product descriptions and specifications</p>
                      </div>
                    </div>
                  </div>
                  <div className="relative aspect-video overflow-hidden rounded-lg">
                    <img
                      src="/placeholder.svg?height=300&width=500"
                      alt="Quality control process"
                      className="object-cover w-full h-full"
                    />
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="delivery" className="p-6 border rounded-lg mt-6">
                <div className="grid gap-6 lg:grid-cols-2 items-center">
                  <div>
                    <h3 className="text-xl font-medium mb-4">Fast & Reliable Delivery</h3>
                    <div className="space-y-3">
                      <div className="flex items-start gap-2">
                        <CheckCircle className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                        <p className="text-muted-foreground">Same-day delivery available in Mbabane</p>
                      </div>
                      <div className="flex items-start gap-2">
                        <CheckCircle className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                        <p className="text-muted-foreground">Nationwide delivery within 1-3 business days</p>
                      </div>
                      <div className="flex items-start gap-2">
                        <CheckCircle className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                        <p className="text-muted-foreground">Real-time order tracking</p>
                      </div>
                      <div className="flex items-start gap-2">
                        <CheckCircle className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                        <p className="text-muted-foreground">Secure packaging to ensure product safety</p>
                      </div>
                    </div>
                  </div>
                  <div className="relative aspect-video overflow-hidden rounded-lg">
                    <img
                      src="/placeholder.svg?height=300&width=500"
                      alt="Delivery service"
                      className="object-cover w-full h-full"
                    />
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="support" className="p-6 border rounded-lg mt-6">
                <div className="grid gap-6 lg:grid-cols-2 items-center">
                  <div>
                    <h3 className="text-xl font-medium mb-4">Exceptional Customer Support</h3>
                    <div className="space-y-3">
                      <div className="flex items-start gap-2">
                        <CheckCircle className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                        <p className="text-muted-foreground">24/7 customer service via chat, email, and phone</p>
                      </div>
                      <div className="flex items-start gap-2">
                        <CheckCircle className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                        <p className="text-muted-foreground">Dedicated support team based in Eswatini</p>
                      </div>
                      <div className="flex items-start gap-2">
                        <CheckCircle className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                        <p className="text-muted-foreground">Hassle-free return and refund process</p>
                      </div>
                      <div className="flex items-start gap-2">
                        <CheckCircle className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                        <p className="text-muted-foreground">Comprehensive FAQ and help center</p>
                      </div>
                    </div>
                  </div>
                  <div className="relative aspect-video overflow-hidden rounded-lg">
                    <img
                      src="/placeholder.svg?height=300&width=500"
                      alt="Customer support team"
                      className="object-cover w-full h-full"
                    />
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="security" className="p-6 border rounded-lg mt-6">
                <div className="grid gap-6 lg:grid-cols-2 items-center">
                  <div>
                    <h3 className="text-xl font-medium mb-4">Secure Shopping Experience</h3>
                    <div className="space-y-3">
                      <div className="flex items-start gap-2">
                        <CheckCircle className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                        <p className="text-muted-foreground">SSL-encrypted checkout process</p>
                      </div>
                      <div className="flex items-start gap-2">
                        <CheckCircle className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                        <p className="text-muted-foreground">Multiple secure payment options</p>
                      </div>
                      <div className="flex items-start gap-2">
                        <CheckCircle className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                        <p className="text-muted-foreground">Privacy-focused data handling</p>
                      </div>
                      <div className="flex items-start gap-2">
                        <CheckCircle className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                        <p className="text-muted-foreground">Fraud detection and prevention systems</p>
                      </div>
                    </div>
                  </div>
                  <div className="relative aspect-video overflow-hidden rounded-lg">
                    <img
                      src="/placeholder.svg?height=300&width=500"
                      alt="Secure payment process"
                      className="object-cover w-full h-full"
                    />
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>

          {/* Milestones section */}
          <div className="space-y-6">
            <div className="text-center">
              <h2 className="text-2xl font-bold tracking-tight">Our Journey</h2>
              <p className="text-muted-foreground mt-2">Key milestones in our growth story</p>
            </div>

            <div className="relative border-l border-muted pl-6 ml-3 space-y-10">
              <div className="relative">
                <div className="absolute -left-9 mt-1.5 h-5 w-5 rounded-full border-4 border-background bg-primary"></div>
                <div>
                  <h3 className="font-medium">2023</h3>
                  <p className="text-sm text-muted-foreground mb-2">Foundation</p>
                  <p className="text-muted-foreground">
                    EcoShop was founded with a vision to transform online shopping in Eswatini. We launched with a small
                    team of 5 and a curated selection of 200 products.
                  </p>
                </div>
              </div>

              <div className="relative">
                <div className="absolute -left-9 mt-1.5 h-5 w-5 rounded-full border-4 border-background bg-primary"></div>
                <div>
                  <h3 className="font-medium">2024</h3>
                  <p className="text-sm text-muted-foreground mb-2">Expansion</p>
                  <p className="text-muted-foreground">
                    We expanded our product range to over 1,000 items and grew our customer base by 300%. Our team
                    doubled in size to meet growing demand.
                  </p>
                </div>
              </div>

              <div className="relative">
                <div className="absolute -left-9 mt-1.5 h-5 w-5 rounded-full border-4 border-background bg-primary"></div>
                <div>
                  <h3 className="font-medium">2025</h3>
                  <p className="text-sm text-muted-foreground mb-2">Innovation</p>
                  <p className="text-muted-foreground">
                    Launched our mobile app and same-day delivery service in major cities. Introduced our sustainability
                    initiative to reduce packaging waste by 50%.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Partners section */}
          <div className="space-y-6">
            <div className="text-center">
              <h2 className="text-2xl font-bold tracking-tight">Our Partners</h2>
              <p className="text-muted-foreground mt-2">Trusted brands we work with</p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 items-center">
              <div className="flex justify-center">
                <img src="/placeholder.svg?height=80&width=160" alt="Partner 1" className="h-12 object-contain" />
              </div>
              <div className="flex justify-center">
                <img src="/placeholder.svg?height=80&width=160" alt="Partner 2" className="h-12 object-contain" />
              </div>
              <div className="flex justify-center">
                <img src="/placeholder.svg?height=80&width=160" alt="Partner 3" className="h-12 object-contain" />
              </div>
              <div className="flex justify-center">
                <img src="/placeholder.svg?height=80&width=160" alt="Partner 4" className="h-12 object-contain" />
              </div>
            </div>
          </div>

          {/* CTA section */}
          <div className="bg-muted rounded-lg p-8 text-center">
            <h2 className="text-2xl font-bold tracking-tight mb-4">Join Our Journey</h2>
            <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
              We're constantly growing and looking for passionate individuals to join our team. Check out our current
              openings or shop our latest products.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Button asChild size="lg">
                <Link href="/careers">View Careers</Link>
              </Button>
              <Button variant="outline" size="lg" asChild>
                <Link href="/shop">Shop Now</Link>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

