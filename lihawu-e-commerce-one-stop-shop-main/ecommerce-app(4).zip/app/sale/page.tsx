import { SalePage } from "@/components/sale-page"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Sale | EcoShop",
  description: "Shop our products on sale with great discounts",
}

export default function Sale() {
  return <SalePage />
}

