import type { Metadata } from "next"
import { CategoryPage } from "@/components/category-page"

export const metadata: Metadata = {
  title: "Category",
  description: "Browse products by category",
}

export default function CategoryPageRoute({ params }) {
  return <CategoryPage slug={params.slug} />
}

