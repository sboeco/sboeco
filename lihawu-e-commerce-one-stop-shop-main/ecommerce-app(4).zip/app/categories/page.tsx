import type { Metadata } from "next"
import { CategoriesPage } from "@/components/categories-page"

export const metadata: Metadata = {
  title: "All Categories",
  description: "Browse all product categories in our store",
}

export default function CategoriesPageRoute() {
  return <CategoriesPage />
}

