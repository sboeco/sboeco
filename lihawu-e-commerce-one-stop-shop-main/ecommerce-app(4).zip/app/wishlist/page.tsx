import { Suspense } from "react"
import { WishlistPage } from "@/components/wishlist-page"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Wishlist | EcoShop",
  description: "View and manage your saved items",
}

// Simple loading skeleton for the wishlist page
function WishlistSkeleton() {
  return (
    <div className="container px-4 md:px-6 py-8 mx-auto">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
        <div>
          <div className="h-8 w-48 bg-gray-200 rounded-md mb-2"></div>
          <div className="h-4 w-64 bg-gray-200 rounded-md"></div>
        </div>
      </div>
      <div className="text-center py-16 border rounded-lg bg-muted/30">
        <div className="h-6 w-48 bg-gray-200 rounded-md mx-auto mb-2"></div>
        <div className="h-4 w-80 bg-gray-200 rounded-md mx-auto mb-6"></div>
        <div className="h-10 w-40 bg-gray-200 rounded-md mx-auto"></div>
      </div>
    </div>
  )
}

export default function Wishlist() {
  return (
    <Suspense fallback={<WishlistSkeleton />}>
      <WishlistPage />
    </Suspense>
  )
}

