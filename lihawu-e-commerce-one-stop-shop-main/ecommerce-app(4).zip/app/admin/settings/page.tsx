"use client"

import { useState, useEffect, useRef } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/components/auth-provider"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Store, CreditCard, Bell, Shield, Palette, Save, AlertTriangle } from "lucide-react"
import { doc, getDoc, updateDoc } from "firebase/firestore"
import { db } from "@/lib/firebase"

export default function SettingsPage() {
  const { user, loading: authLoading, isAdmin } = useAuth()
  const router = useRouter()
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [settings, setSettings] = useState({
    store: {
      name: "Your Store",
      email: "store@example.com",
      phone: "+1234567890",
      address: "123 Main St, City, Country",
      currency: "SZL",
      logo: "",
      favicon: "",
    },
    payment: {
      enableCreditCard: true,
      enablePaypal: false,
      enableCrypto: false,
      enableCashOnDelivery: true,
      taxRate: 15,
      shippingFee: 50,
    },
    notifications: {
      orderConfirmation: true,
      orderStatusUpdate: true,
      lowStockAlert: true,
      marketingEmails: false,
      emailTemplate: "default",
    },
    security: {
      twoFactorAuth: false,
      passwordExpiry: 90,
      sessionTimeout: 30,
      ipRestriction: false,
    },
    appearance: {
      theme: "light",
      primaryColor: "#3b82f6",
      accentColor: "#10b981",
      fontFamily: "Inter",
      enableDarkMode: true,
    },
  })
  const isMounted = useRef(true)

  useEffect(() => {
    return () => {
      isMounted.current = false
    }
  }, [])

  useEffect(() => {
    if (!authLoading) {
      if (!user) {
        router.push("/login")
        return
      }

      if (!isAdmin()) {
        router.push("/dashboard")
        return
      }

      fetchSettings()
    }
  }, [user, authLoading, router, isAdmin])

  const fetchSettings = async () => {
    try {
      setLoading(true)
      // Fetch settings from Firestore
      const settingsDoc = await getDoc(doc(db, "settings", "global"))

      if (settingsDoc.exists()) {
        if (isMounted.current) {
          setSettings(settingsDoc.data())
        }
      }

      if (isMounted.current) {
        setLoading(false)
      }
    } catch (error) {
      console.error("Error fetching settings:", error)
      if (isMounted.current) {
        setLoading(false)
      }
    }
  }

  const saveSettings = async () => {
    try {
      setSaving(true)
      // Save settings to Firestore
      await updateDoc(doc(db, "settings", "global"), settings)

      if (isMounted.current) {
        setSaving(false)
      }
    } catch (error) {
      console.error("Error saving settings:", error)
      if (isMounted.current) {
        setSaving(false)
      }
    }
  }

  const handleStoreChange = (e) => {
    const { name, value } = e.target
    setSettings({
      ...settings,
      store: {
        ...settings.store,
        [name]: value,
      },
    })
  }

  const handlePaymentChange = (e) => {
    const { name, value, type, checked } = e.target
    setSettings({
      ...settings,
      payment: {
        ...settings.payment,
        [name]: type === "checkbox" ? checked : value,
      },
    })
  }

  const handleSwitchChange = (section, name, checked) => {
    setSettings({
      ...settings,
      [section]: {
        ...settings[section],
        [name]: checked,
      },
    })
  }

  return (
    <div className="flex-1 space-y-4 p-8 pt-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Store Settings</h2>
          <p className="text-muted-foreground">Manage your store configuration and preferences</p>
        </div>
        <Button onClick={saveSettings} disabled={saving}>
          {saving ? (
            <>Saving...</>
          ) : (
            <>
              <Save className="h-4 w-4 mr-2" />
              Save Changes
            </>
          )}
        </Button>
      </div>

      <Tabs defaultValue="store" className="space-y-4">
        <TabsList>
          <TabsTrigger value="store">
            <Store className="h-4 w-4 mr-2" />
            Store
          </TabsTrigger>
          <TabsTrigger value="payment">
            <CreditCard className="h-4 w-4 mr-2" />
            Payment
          </TabsTrigger>
          <TabsTrigger value="notifications">
            <Bell className="h-4 w-4 mr-2" />
            Notifications
          </TabsTrigger>
          <TabsTrigger value="security">
            <Shield className="h-4 w-4 mr-2" />
            Security
          </TabsTrigger>
          <TabsTrigger value="appearance">
            <Palette className="h-4 w-4 mr-2" />
            Appearance
          </TabsTrigger>
        </TabsList>

        <TabsContent value="store" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Store Information</CardTitle>
              <CardDescription>Basic information about your store</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="store-name">Store Name</Label>
                  <Input id="store-name" name="name" value={settings.store.name} onChange={handleStoreChange} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="store-email">Email Address</Label>
                  <Input
                    id="store-email"
                    name="email"
                    type="email"
                    value={settings.store.email}
                    onChange={handleStoreChange}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="store-phone">Phone Number</Label>
                  <Input id="store-phone" name="phone" value={settings.store.phone} onChange={handleStoreChange} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="store-currency">Currency</Label>
                  <Input
                    id="store-currency"
                    name="currency"
                    value={settings.store.currency}
                    onChange={handleStoreChange}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="store-address">Store Address</Label>
                <Textarea
                  id="store-address"
                  name="address"
                  value={settings.store.address}
                  onChange={handleStoreChange}
                  rows={3}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="store-logo">Store Logo URL</Label>
                  <Input
                    id="store-logo"
                    name="logo"
                    value={settings.store.logo}
                    onChange={handleStoreChange}
                    placeholder="https://example.com/logo.png"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="store-favicon">Favicon URL</Label>
                  <Input
                    id="store-favicon"
                    name="favicon"
                    value={settings.store.favicon}
                    onChange={handleStoreChange}
                    placeholder="https://example.com/favicon.ico"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Business Hours</CardTitle>
              <CardDescription>Set your store's operating hours</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"].map((day) => (
                  <div key={day} className="flex items-center justify-between">
                    <Label htmlFor={`hours-${day.toLowerCase()}`}>{day}</Label>
                    <div className="flex items-center gap-2">
                      <Input id={`hours-${day.toLowerCase()}-open`} type="time" defaultValue="09:00" className="w-24" />
                      <span>to</span>
                      <Input
                        id={`hours-${day.toLowerCase()}-close`}
                        type="time"
                        defaultValue={day === "Saturday" || day === "Sunday" ? "17:00" : "18:00"}
                        className="w-24"
                      />
                      <div className="flex items-center space-x-2">
                        <Switch id={`hours-${day.toLowerCase()}-closed`} />
                        <Label htmlFor={`hours-${day.toLowerCase()}-closed`}>Closed</Label>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="payment" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Payment Methods</CardTitle>
              <CardDescription>Configure available payment options for your customers</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Credit Card</Label>
                    <p className="text-sm text-muted-foreground">Accept Visa, Mastercard, and American Express</p>
                  </div>
                  <Switch
                    checked={settings.payment.enableCreditCard}
                    onCheckedChange={(checked) => handleSwitchChange("payment", "enableCreditCard", checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>PayPal</Label>
                    <p className="text-sm text-muted-foreground">Allow customers to pay with PayPal</p>
                  </div>
                  <Switch
                    checked={settings.payment.enablePaypal}
                    onCheckedChange={(checked) => handleSwitchChange("payment", "enablePaypal", checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Cryptocurrency</Label>
                    <p className="text-sm text-muted-foreground">Accept Bitcoin and other cryptocurrencies</p>
                  </div>
                  <Switch
                    checked={settings.payment.enableCrypto}
                    onCheckedChange={(checked) => handleSwitchChange("payment", "enableCrypto", checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Cash on Delivery</Label>
                    <p className="text-sm text-muted-foreground">
                      Allow customers to pay when they receive their order
                    </p>
                  </div>
                  <Switch
                    checked={settings.payment.enableCashOnDelivery}
                    onCheckedChange={(checked) => handleSwitchChange("payment", "enableCashOnDelivery", checked)}
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Tax & Shipping</CardTitle>
              <CardDescription>Configure tax rates and shipping options</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="tax-rate">Tax Rate (%)</Label>
                  <Input
                    id="tax-rate"
                    name="taxRate"
                    type="number"
                    min="0"
                    max="100"
                    value={settings.payment.taxRate}
                    onChange={handlePaymentChange}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="shipping-fee">Default Shipping Fee</Label>
                  <div className="flex items-center">
                    <span className="mr-2">{settings.store.currency}</span>
                    <Input
                      id="shipping-fee"
                      name="shippingFee"
                      type="number"
                      min="0"
                      value={settings.payment.shippingFee}
                      onChange={handlePaymentChange}
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Shipping Methods</Label>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <input type="checkbox" id="shipping-standard" defaultChecked />
                    <Label htmlFor="shipping-standard">Standard Shipping</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input type="checkbox" id="shipping-express" defaultChecked />
                    <Label htmlFor="shipping-express">Express Shipping</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input type="checkbox" id="shipping-pickup" />
                    <Label htmlFor="shipping-pickup">Store Pickup</Label>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notifications" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Email Notifications</CardTitle>
              <CardDescription>Configure automated email notifications for your store</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Order Confirmation</Label>
                    <p className="text-sm text-muted-foreground">Send email when a customer places an order</p>
                  </div>
                  <Switch
                    checked={settings.notifications.orderConfirmation}
                    onCheckedChange={(checked) => handleSwitchChange("notifications", "orderConfirmation", checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Order Status Updates</Label>
                    <p className="text-sm text-muted-foreground">Notify customers when their order status changes</p>
                  </div>
                  <Switch
                    checked={settings.notifications.orderStatusUpdate}
                    onCheckedChange={(checked) => handleSwitchChange("notifications", "orderStatusUpdate", checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Low Stock Alerts</Label>
                    <p className="text-sm text-muted-foreground">Receive notifications when product stock is low</p>
                  </div>
                  <Switch
                    checked={settings.notifications.lowStockAlert}
                    onCheckedChange={(checked) => handleSwitchChange("notifications", "lowStockAlert", checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Marketing Emails</Label>
                    <p className="text-sm text-muted-foreground">Send promotional emails to customers</p>
                  </div>
                  <Switch
                    checked={settings.notifications.marketingEmails}
                    onCheckedChange={(checked) => handleSwitchChange("notifications", "marketingEmails", checked)}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="email-template">Email Template</Label>
                <select
                  id="email-template"
                  className="w-full bg-background border rounded-md px-3 py-2 text-sm"
                  value={settings.notifications.emailTemplate}
                  onChange={(e) => handleSwitchChange("notifications", "emailTemplate", e.target.value)}
                >
                  <option value="default">Default Template</option>
                  <option value="minimal">Minimal</option>
                  <option value="modern">Modern</option>
                  <option value="branded">Branded</option>
                </select>
                <p className="text-xs text-muted-foreground">Select the template style for all outgoing emails</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="security" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Security Settings</CardTitle>
              <CardDescription>Configure security options for your store</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Two-Factor Authentication</Label>
                    <p className="text-sm text-muted-foreground">Require 2FA for admin accounts</p>
                  </div>
                  <Switch
                    checked={settings.security.twoFactorAuth}
                    onCheckedChange={(checked) => handleSwitchChange("security", "twoFactorAuth", checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>IP Restriction</Label>
                    <p className="text-sm text-muted-foreground">Limit admin access to specific IP addresses</p>
                  </div>
                  <Switch
                    checked={settings.security.ipRestriction}
                    onCheckedChange={(checked) => handleSwitchChange("security", "ipRestriction", checked)}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="password-expiry">Password Expiry (days)</Label>
                  <Input
                    id="password-expiry"
                    type="number"
                    min="0"
                    value={settings.security.passwordExpiry}
                    onChange={(e) => handleSwitchChange("security", "passwordExpiry", Number.parseInt(e.target.value))}
                  />
                  <p className="text-xs text-muted-foreground">Set to 0 for no expiration</p>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="session-timeout">Session Timeout (minutes)</Label>
                  <Input
                    id="session-timeout"
                    type="number"
                    min="5"
                    value={settings.security.sessionTimeout}
                    onChange={(e) => handleSwitchChange("security", "sessionTimeout", Number.parseInt(e.target.value))}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <AlertTriangle className="h-4 w-4 text-amber-500" />
                  <Label>Security Audit Log</Label>
                </div>
                <Button variant="outline" size="sm">
                  View Security Logs
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="appearance" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Theme Settings</CardTitle>
              <CardDescription>Customize the appearance of your store</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="theme">Theme Mode</Label>
                <select
                  id="theme"
                  className="w-full bg-background border rounded-md px-3 py-2 text-sm"
                  value={settings.appearance.theme}
                  onChange={(e) => handleSwitchChange("appearance", "theme", e.target.value)}
                >
                  <option value="light">Light</option>
                  <option value="dark">Dark</option>
                  <option value="system">System Default</option>
                </select>
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Enable Dark Mode Toggle</Label>
                  <p className="text-sm text-muted-foreground">Allow users to switch between light and dark mode</p>
                </div>
                <Switch
                  checked={settings.appearance.enableDarkMode}
                  onCheckedChange={(checked) => handleSwitchChange("appearance", "enableDarkMode", checked)}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="primary-color">Primary Color</Label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      id="primary-color"
                      value={settings.appearance.primaryColor}
                      onChange={(e) => handleSwitchChange("appearance", "primaryColor", e.target.value)}
                      className="w-10 h-10 rounded-md border"
                    />
                    <Input
                      value={settings.appearance.primaryColor}
                      onChange={(e) => handleSwitchChange("appearance", "primaryColor", e.target.value)}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="accent-color">Accent Color</Label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      id="accent-color"
                      value={settings.appearance.accentColor}
                      onChange={(e) => handleSwitchChange("appearance", "accentColor", e.target.value)}
                      className="w-10 h-10 rounded-md border"
                    />
                    <Input
                      value={settings.appearance.accentColor}
                      onChange={(e) => handleSwitchChange("appearance", "accentColor", e.target.value)}
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="font-family">Font Family</Label>
                <select
                  id="font-family"
                  className="w-full bg-background border rounded-md px-3 py-2 text-sm"
                  value={settings.appearance.fontFamily}
                  onChange={(e) => handleSwitchChange("appearance", "fontFamily", e.target.value)}
                >
                  <option value="Inter">Inter</option>
                  <option value="Roboto">Roboto</option>
                  <option value="Open Sans">Open Sans</option>
                  <option value="Montserrat">Montserrat</option>
                  <option value="Poppins">Poppins</option>
                </select>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

