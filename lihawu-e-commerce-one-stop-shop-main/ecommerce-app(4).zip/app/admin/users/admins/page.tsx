"use client"

import { useState, useEffect, useRef } from "react"
import { collection, getDocs, query, orderBy } from "firebase/firestore"
import { db } from "@/lib/firebase"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Badge } from "@/components/ui/badge"
import { Trash2 } from "lucide-react"
import { format } from "date-fns"
import { toast } from "@/components/ui/use-toast"
import { Input } from "@/components/ui/input"
import { removeAdmin } from "@/lib/firebase/admin"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

export default function AdminUsersAdminsPage() {
  const [admins, setAdmins] = useState([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
  const [selectedAdmin, setSelectedAdmin] = useState(null)
  const isMounted = useRef(true)

  useEffect(() => {
    return () => {
      isMounted.current = false
    }
  }, [])

  useEffect(() => {
    const fetchAdmins = async () => {
      try {
        // Get all admins from the admins collection
        const adminsQuery = query(collection(db, "admins"), orderBy("createdAt", "desc"))
        const adminsSnapshot = await getDocs(adminsQuery)

        if (!isMounted.current) return

        // Get user details for each admin
        const adminsData = await Promise.all(
          adminsSnapshot.docs.map(async (docSnapshot) => {
            const adminData = {
              id: docSnapshot.id,
              ...docSnapshot.data(),
              createdAt: docSnapshot.data().createdAt ? new Date(docSnapshot.data().createdAt) : new Date(),
            }

            // Try to get additional user info from users collection
            try {
              const userDoc = await getDocs(query(collection(db, "users"), query.where("uid", "==", docSnapshot.id)))

              if (!userDoc.empty) {
                const userData = userDoc.docs[0].data()
                adminData.displayName = userData.displayName
                adminData.photoURL = userData.photoURL
                // Use email from user doc if available, otherwise use the one in admin doc
                adminData.email = userData.email || adminData.email
              }
            } catch (error) {
              console.error("Error fetching user details for admin:", error)
            }

            return adminData
          }),
        )

        setAdmins(adminsData)
      } catch (error) {
        console.error("Error fetching admins:", error)
        toast({
          title: "Error",
          description: "Failed to load admin data",
          variant: "destructive",
        })
      } finally {
        if (isMounted.current) {
          setLoading(false)
        }
      }
    }

    fetchAdmins()
  }, [])

  const handleRemoveAdmin = async (id) => {
    try {
      await removeAdmin(id)

      if (isMounted.current) {
        setAdmins(admins.filter((admin) => admin.id !== id))
        toast({
          title: "Success",
          description: "Admin privileges removed successfully",
        })
      }
    } catch (error) {
      console.error("Error removing admin:", error)
      toast({
        title: "Error",
        description: "Failed to remove admin privileges",
        variant: "destructive",
      })
    } finally {
      setDeleteDialogOpen(false)
    }
  }

  const confirmRemoveAdmin = (admin) => {
    setSelectedAdmin(admin)
    setDeleteDialogOpen(true)
  }

  const filteredAdmins = admins.filter((admin) => {
    const searchLower = searchTerm.toLowerCase()
    return (
      (admin.email && admin.email.toLowerCase().includes(searchLower)) ||
      (admin.displayName && admin.displayName.toLowerCase().includes(searchLower))
    )
  })

  if (loading) {
    return (
      <div className="container mx-auto py-10">
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl">Admin Management</CardTitle>
            <CardDescription>View and manage administrator accounts</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[400px] w-full flex items-center justify-center">
              <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="container mx-auto py-10">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl">Admin Management</CardTitle>
          <CardDescription>View and manage administrator accounts</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mb-6 flex items-center justify-between">
            <Input
              placeholder="Search admins..."
              className="max-w-sm"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200 text-sm">
              Total Admins: {admins.length}
            </Badge>
          </div>

          {filteredAdmins.length === 0 ? (
            <div className="text-center py-10">
              <p className="text-muted-foreground">No admins found</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Admin</TableHead>
                  <TableHead>Added</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredAdmins.map((admin) => (
                  <TableRow key={admin.id}>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <Avatar>
                          <AvatarImage src={admin.photoURL || ""} alt={admin.displayName || admin.email} />
                          <AvatarFallback>{admin.displayName?.[0] || admin.email?.[0] || "A"}</AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="font-medium">{admin.displayName || "No name"}</div>
                          <div className="text-sm text-muted-foreground">{admin.email || "No email"}</div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      {admin.createdAt instanceof Date ? format(admin.createdAt, "MMM dd, yyyy") : "Unknown date"}
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200">
                        Admin
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="icon" onClick={() => confirmRemoveAdmin(admin)}>
                        <Trash2 className="h-4 w-4 text-red-500" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will remove admin privileges from this user. They will no longer have access to the admin panel.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-red-500 hover:bg-red-600"
              onClick={() => selectedAdmin && handleRemoveAdmin(selectedAdmin.id)}
            >
              Remove Admin
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

