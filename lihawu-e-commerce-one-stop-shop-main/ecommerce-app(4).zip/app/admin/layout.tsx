"use client"

import { useState } from "react"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/components/auth-provider"
import { AdminSidebar } from "@/components/admin-sidebar"
import { isAdmin } from "@/lib/firebase/admin"

export default function AdminLayout({ children }) {
  const { user, loading } = useAuth()
  const router = useRouter()
  const [isAdminUser, setIsAdminUser] = useState(false)
  const [checkingAdmin, setCheckingAdmin] = useState(true)

  useEffect(() => {
    const checkAdminStatus = async () => {
      if (user) {
        try {
          const adminStatus = await isAdmin(user.uid)
          setIsAdminUser(adminStatus)
        } catch (error) {
          console.error("Error checking admin status:", error)
          setIsAdminUser(false)
        } finally {
          setCheckingAdmin(false)
        }
      } else if (!loading) {
        setCheckingAdmin(false)
      }
    }

    checkAdminStatus()
  }, [user, loading])

  useEffect(() => {
    if (!loading && !checkingAdmin && (!user || !isAdminUser)) {
      router.push("/login")
    }
  }, [user, loading, checkingAdmin, isAdminUser, router])

  if (loading || checkingAdmin) {
    return (
      <div className="flex h-screen w-full items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
      </div>
    )
  }

  if (!user || !isAdminUser) {
    return null
  }

  return (
    <div className="grid min-h-screen w-full md:grid-cols-[240px_1fr]">
      <AdminSidebar />
      <main className="flex flex-col">{children}</main>
    </div>
  )
}

