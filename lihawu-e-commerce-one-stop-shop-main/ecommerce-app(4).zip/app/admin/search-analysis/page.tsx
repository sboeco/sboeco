"use client"

import { useState, useEffect, useRef } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/components/auth-provider"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts"
import { Search, TrendingUp, Calendar, Download, ArrowUpDown, Clock, Tag } from "lucide-react"
import { collection, query, orderBy, getDocs, where, Timestamp } from "firebase/firestore"
import { db } from "@/lib/firebase"

export default function SearchAnalysisPage() {
  const { user, loading: authLoading, isAdmin } = useAuth()
  const router = useRouter()
  const [loading, setLoading] = useState(true)
  const [searchData, setSearchData] = useState([])
  const [filteredData, setFilteredData] = useState([])
  const [searchTerm, setSearchTerm] = useState("")
  const [timeRange, setTimeRange] = useState("30days")
  const [sortConfig, setSortConfig] = useState({ key: "count", direction: "desc" })
  const isMounted = useRef(true)

  useEffect(() => {
    return () => {
      isMounted.current = false
    }
  }, [])

  useEffect(() => {
    if (!authLoading) {
      if (!user) {
        router.push("/login")
        return
      }

      if (!isAdmin()) {
        router.push("/dashboard")
        return
      }

      fetchSearchData()
    }
  }, [user, authLoading, router, isAdmin, timeRange])

  useEffect(() => {
    if (searchData.length > 0) {
      const filtered = searchData.filter((item) => item.term.toLowerCase().includes(searchTerm.toLowerCase()))

      const sorted = [...filtered].sort((a, b) => {
        if (a[sortConfig.key] < b[sortConfig.key]) {
          return sortConfig.direction === "asc" ? -1 : 1
        }
        if (a[sortConfig.key] > b[sortConfig.key]) {
          return sortConfig.direction === "asc" ? 1 : -1
        }
        return 0
      })

      setFilteredData(sorted)
    }
  }, [searchData, searchTerm, sortConfig])

  const getDateRange = () => {
    const now = new Date()
    const endDate = now
    let startDate

    switch (timeRange) {
      case "7days":
        startDate = new Date(now)
        startDate.setDate(now.getDate() - 7)
        break
      case "30days":
        startDate = new Date(now)
        startDate.setDate(now.getDate() - 30)
        break
      case "90days":
        startDate = new Date(now)
        startDate.setDate(now.getDate() - 90)
        break
      case "year":
        startDate = new Date(now)
        startDate.setFullYear(now.getFullYear() - 1)
        break
      default:
        startDate = new Date(now)
        startDate.setDate(now.getDate() - 30)
    }

    return {
      startDate: Timestamp.fromDate(startDate),
      endDate: Timestamp.fromDate(endDate),
    }
  }

  const fetchSearchData = async () => {
    try {
      setLoading(true)
      const { startDate, endDate } = getDateRange()

      // Fetch search queries from Firestore
      const searchesRef = collection(db, "searches")
      const searchesQuery = query(
        searchesRef,
        where("timestamp", ">=", startDate),
        where("timestamp", "<=", endDate),
        orderBy("timestamp", "desc"),
      )

      const searchesSnapshot = await getDocs(searchesQuery)

      // Process search data
      const searches = searchesSnapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }))

      // Aggregate search terms
      const searchTerms = {}
      const searchByDay = {}
      const searchByHour = {}
      const searchByUser = {}

      searches.forEach((search) => {
        // Count by term
        const term = search.term.toLowerCase()
        if (!searchTerms[term]) {
          searchTerms[term] = {
            term: search.term,
            count: 0,
            resultsCount: 0,
            clickCount: 0,
            conversionRate: 0,
            lastSearched: search.timestamp,
          }
        }
        searchTerms[term].count += 1
        searchTerms[term].resultsCount += search.resultsCount || 0
        searchTerms[term].clickCount += search.clicked ? 1 : 0

        if (search.timestamp.toDate() > searchTerms[term].lastSearched.toDate()) {
          searchTerms[term].lastSearched = search.timestamp
        }

        // Count by day
        const day = search.timestamp.toDate().toISOString().split("T")[0]
        searchByDay[day] = (searchByDay[day] || 0) + 1

        // Count by hour
        const hour = search.timestamp.toDate().getHours()
        searchByHour[hour] = (searchByHour[hour] || 0) + 1

        // Count by user type
        const userType = search.userId ? "registered" : "guest"
        searchByUser[userType] = (searchByUser[userType] || 0) + 1
      })

      // Calculate conversion rates and format data
      const searchTermsArray = Object.values(searchTerms).map((item) => {
        item.conversionRate = item.count > 0 ? (item.clickCount / item.count) * 100 : 0
        item.averageResults = item.count > 0 ? item.resultsCount / item.count : 0
        item.lastSearched = item.lastSearched.toDate().toLocaleString()
        return item
      })

      // Format data for charts
      const searchByDayArray = Object.entries(searchByDay)
        .map(([date, count]) => ({ date, count }))
        .sort((a, b) => a.date.localeCompare(b.date))

      const searchByHourArray = Array.from({ length: 24 }, (_, i) => ({
        hour: i,
        count: searchByHour[i] || 0,
      }))

      const searchByUserArray = Object.entries(searchByUser).map(([type, count]) => ({ type, count }))

      // Combine all data
      const analysisData = {
        terms: searchTermsArray,
        byDay: searchByDayArray,
        byHour: searchByHourArray,
        byUser: searchByUserArray,
        total: searches.length,
      }

      if (isMounted.current) {
        setSearchData(analysisData.terms)
        setLoading(false)
      }
    } catch (error) {
      console.error("Error fetching search data:", error)
      if (isMounted.current) {
        setLoading(false)
      }
    }
  }

  const handleSort = (key) => {
    let direction = "asc"
    if (sortConfig.key === key && sortConfig.direction === "asc") {
      direction = "desc"
    }
    setSortConfig({ key, direction })
  }

  const exportToCSV = () => {
    const headers = ["Term", "Search Count", "Avg Results", "Click Count", "Conversion Rate", "Last Searched"]
    const csvData = [
      headers.join(","),
      ...filteredData.map((item) =>
        [
          `"${item.term}"`,
          item.count,
          item.averageResults.toFixed(1),
          item.clickCount,
          `${item.conversionRate.toFixed(1)}%`,
          item.lastSearched,
        ].join(","),
      ),
    ].join("\n")

    const blob = new Blob([csvData], { type: "text/csv;charset=utf-8;" })
    const url = URL.createObjectURL(blob)
    const link = document.createElement("a")
    link.setAttribute("href", url)
    link.setAttribute("download", `search-analysis-${new Date().toISOString().split("T")[0]}.csv`)
    link.style.visibility = "hidden"
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  // Sample data for charts when no real data is available
  const sampleHourlyData = Array.from({ length: 24 }, (_, i) => ({
    hour: i,
    count: Math.floor(Math.random() * 50) + 10,
  }))

  const sampleUserTypeData = [
    { type: "Registered", count: 65 },
    { type: "Guest", count: 35 },
  ]

  const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#8884D8"]

  return (
    <div className="flex-1 space-y-4 p-8 pt-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Search Analysis</h2>
          <p className="text-muted-foreground">Analyze customer search behavior and patterns</p>
        </div>
        <div className="flex items-center gap-2">
          <Calendar className="h-4 w-4 text-muted-foreground" />
          <select
            className="bg-background border rounded-md px-3 py-2 text-sm"
            value={timeRange}
            onChange={(e) => setTimeRange(e.target.value)}
          >
            <option value="7days">Last 7 days</option>
            <option value="30days">Last 30 days</option>
            <option value="90days">Last 90 days</option>
            <option value="year">Last year</option>
          </select>
          <Button variant="outline" size="sm" onClick={exportToCSV}>
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Searches</CardTitle>
            <Search className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {loading ? (
                <div className="h-8 w-16 bg-muted rounded animate-pulse"></div>
              ) : (
                filteredData.reduce((sum, item) => sum + item.count, 0)
              )}
            </div>
            <p className="text-xs text-muted-foreground">
              {timeRange === "7days"
                ? "Past 7 days"
                : timeRange === "30days"
                  ? "Past 30 days"
                  : timeRange === "90days"
                    ? "Past 90 days"
                    : "Past year"}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Unique Search Terms</CardTitle>
            <Tag className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {loading ? <div className="h-8 w-16 bg-muted rounded animate-pulse"></div> : filteredData.length}
            </div>
            <p className="text-xs text-muted-foreground">
              {timeRange === "7days"
                ? "Past 7 days"
                : timeRange === "30days"
                  ? "Past 30 days"
                  : timeRange === "90days"
                    ? "Past 90 days"
                    : "Past year"}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Average Conversion</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {loading ? (
                <div className="h-8 w-16 bg-muted rounded animate-pulse"></div>
              ) : (
                `${(filteredData.reduce((sum, item) => sum + item.conversionRate, 0) / (filteredData.length || 1)).toFixed(1)}%`
              )}
            </div>
            <p className="text-xs text-muted-foreground">Searches resulting in clicks</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Peak Search Hour</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {loading ? (
                <div className="h-8 w-16 bg-muted rounded animate-pulse"></div>
              ) : (
                `${sampleHourlyData.reduce((max, item) => (item.count > max.count ? item : max), { count: 0 }).hour}:00`
              )}
            </div>
            <p className="text-xs text-muted-foreground">Most active hour of the day</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="terms" className="space-y-4">
        <TabsList>
          <TabsTrigger value="terms">Search Terms</TabsTrigger>
          <TabsTrigger value="trends">Trends</TabsTrigger>
          <TabsTrigger value="users">User Behavior</TabsTrigger>
        </TabsList>

        <TabsContent value="terms" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Search Terms Analysis</CardTitle>
              <CardDescription>View and analyze search terms used by customers</CardDescription>
              <div className="flex items-center gap-2 mt-2">
                <Search className="h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Filter search terms..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="max-w-sm"
                />
              </div>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="space-y-2">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <div key={i} className="w-full h-12 bg-muted rounded animate-pulse"></div>
                  ))}
                </div>
              ) : filteredData.length > 0 ? (
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-[300px]">
                          <Button variant="ghost" onClick={() => handleSort("term")}>
                            Search Term
                            <ArrowUpDown className="ml-2 h-4 w-4" />
                          </Button>
                        </TableHead>
                        <TableHead>
                          <Button variant="ghost" onClick={() => handleSort("count")}>
                            Count
                            <ArrowUpDown className="ml-2 h-4 w-4" />
                          </Button>
                        </TableHead>
                        <TableHead>
                          <Button variant="ghost" onClick={() => handleSort("averageResults")}>
                            Avg Results
                            <ArrowUpDown className="ml-2 h-4 w-4" />
                          </Button>
                        </TableHead>
                        <TableHead>
                          <Button variant="ghost" onClick={() => handleSort("clickCount")}>
                            Clicks
                            <ArrowUpDown className="ml-2 h-4 w-4" />
                          </Button>
                        </TableHead>
                        <TableHead>
                          <Button variant="ghost" onClick={() => handleSort("conversionRate")}>
                            Conversion
                            <ArrowUpDown className="ml-2 h-4 w-4" />
                          </Button>
                        </TableHead>
                        <TableHead>
                          <Button variant="ghost" onClick={() => handleSort("lastSearched")}>
                            Last Searched
                            <ArrowUpDown className="ml-2 h-4 w-4" />
                          </Button>
                        </TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredData.map((term) => (
                        <TableRow key={term.term}>
                          <TableCell className="font-medium">{term.term}</TableCell>
                          <TableCell>{term.count}</TableCell>
                          <TableCell>{term.averageResults.toFixed(1)}</TableCell>
                          <TableCell>{term.clickCount}</TableCell>
                          <TableCell>
                            <Badge
                              variant={
                                term.conversionRate > 50
                                  ? "success"
                                  : term.conversionRate > 20
                                    ? "default"
                                    : "secondary"
                              }
                            >
                              {term.conversionRate.toFixed(1)}%
                            </Badge>
                          </TableCell>
                          <TableCell>{term.lastSearched}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-8 text-center">
                  <Search className="h-10 w-10 text-muted-foreground mb-2" />
                  <h3 className="text-lg font-medium">No search data available</h3>
                  <p className="text-sm text-muted-foreground">
                    There are no searches in the selected period or matching your filter.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="trends" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Search Trends by Hour</CardTitle>
              <CardDescription>Distribution of searches throughout the day</CardDescription>
            </CardHeader>
            <CardContent className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={sampleHourlyData}
                  margin={{
                    top: 5,
                    right: 30,
                    left: 20,
                    bottom: 5,
                  }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="hour" tickFormatter={(hour) => `${hour}:00`} />
                  <YAxis />
                  <Tooltip
                    formatter={(value) => [value, "Searches"]}
                    labelFormatter={(hour) => `${hour}:00 - ${hour + 1}:00`}
                  />
                  <Legend />
                  <Bar dataKey="count" name="Searches" fill="#8884d8" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Top 10 Search Terms</CardTitle>
                <CardDescription>Most frequently searched terms</CardDescription>
              </CardHeader>
              <CardContent className="h-[300px]">
                {loading ? (
                  <div className="h-full w-full bg-muted rounded animate-pulse"></div>
                ) : filteredData.length > 0 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={filteredData.slice(0, 10)}
                      layout="vertical"
                      margin={{
                        top: 5,
                        right: 30,
                        left: 80,
                        bottom: 5,
                      }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis type="number" />
                      <YAxis type="category" dataKey="term" tick={{ fontSize: 12 }} width={80} />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="count" name="Search Count" fill="#82ca9d" />
                    </BarChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="flex flex-col items-center justify-center h-full text-center">
                    <Search className="h-10 w-10 text-muted-foreground mb-2" />
                    <h3 className="text-lg font-medium">No data available</h3>
                    <p className="text-sm text-muted-foreground">There are no searches in the selected period.</p>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Zero Results Searches</CardTitle>
                <CardDescription>Searches that returned no results</CardDescription>
              </CardHeader>
              <CardContent className="h-[300px]">
                {loading ? (
                  <div className="h-full w-full bg-muted rounded animate-pulse"></div>
                ) : (
                  <div className="flex flex-col h-full">
                    <div className="flex-1 overflow-auto">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Search Term</TableHead>
                            <TableHead>Count</TableHead>
                            <TableHead>Last Searched</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {filteredData
                            .filter((term) => term.averageResults === 0)
                            .slice(0, 10)
                            .map((term) => (
                              <TableRow key={term.term}>
                                <TableCell className="font-medium">{term.term}</TableCell>
                                <TableCell>{term.count}</TableCell>
                                <TableCell>{term.lastSearched}</TableCell>
                              </TableRow>
                            ))}
                        </TableBody>
                      </Table>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="users" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Search by User Type</CardTitle>
                <CardDescription>Distribution of searches between registered users and guests</CardDescription>
              </CardHeader>
              <CardContent className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={sampleUserTypeData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="count"
                      nameKey="type"
                      label={({ type, percent }) => `${type}: ${(percent * 100).toFixed(0)}%`}
                    >
                      {sampleUserTypeData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => [`${value} searches`, "Count"]} />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>User Search Behavior</CardTitle>
                <CardDescription>Insights into how users search on your store</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">Average searches per session</span>
                    <span className="font-bold">3.2</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">Average search term length</span>
                    <span className="font-bold">2.8 words</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">Search to purchase rate</span>
                    <span className="font-bold">18.5%</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">Mobile searches</span>
                    <span className="font-bold">68%</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">Desktop searches</span>
                    <span className="font-bold">32%</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Search Recommendations</CardTitle>
              <CardDescription>Actionable insights based on search analysis</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="p-4 border rounded-lg bg-muted/50">
                  <h3 className="font-medium mb-2">Improve product discoverability</h3>
                  <p className="text-sm text-muted-foreground">
                    Consider adding more relevant keywords to products with high search volume but low click rates.
                  </p>
                </div>
                <div className="p-4 border rounded-lg bg-muted/50">
                  <h3 className="font-medium mb-2">Address zero-result searches</h3>
                  <p className="text-sm text-muted-foreground">
                    Create content or add products for the top zero-result search terms to improve customer
                    satisfaction.
                  </p>
                </div>
                <div className="p-4 border rounded-lg bg-muted/50">
                  <h3 className="font-medium mb-2">Optimize for peak hours</h3>
                  <p className="text-sm text-muted-foreground">
                    Consider running promotions during peak search hours to maximize visibility and conversions.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

