"use client"

import { useState, useEffect, useRef } from "react"
import { collection, getDocs, deleteDoc, doc, query, orderBy } from "firebase/firestore"
import { db } from "@/lib/firebase"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Badge } from "@/components/ui/badge"
import { Trash2, Eye } from "lucide-react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { format } from "date-fns"
import { toast } from "@/components/ui/use-toast"
import { ResponsiveTable } from "@/components/ui/responsive-table"

export default function AdminFeedbackPage() {
  const [feedback, setFeedback] = useState([])
  const [loading, setLoading] = useState(true)
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
  const [selectedFeedback, setSelectedFeedback] = useState(null)
  const [viewDialogOpen, setViewDialogOpen] = useState(false)
  const isMounted = useRef(true)

  useEffect(() => {
    return () => {
      isMounted.current = false
    }
  }, [])

  useEffect(() => {
    const fetchFeedback = async () => {
      try {
        const feedbackQuery = query(collection(db, "feedback"), orderBy("createdAt", "desc"))
        const querySnapshot = await getDocs(feedbackQuery)

        if (!isMounted.current) return

        const feedbackData = querySnapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
          createdAt: doc.data().createdAt ? new Date(doc.data().createdAt) : new Date(),
        }))

        setFeedback(feedbackData)
      } catch (error) {
        console.error("Error fetching feedback:", error)
        toast({
          title: "Error",
          description: "Failed to load feedback data",
          variant: "destructive",
        })
      } finally {
        if (isMounted.current) {
          setLoading(false)
        }
      }
    }

    fetchFeedback()
  }, [])

  const handleDelete = async (id) => {
    try {
      await deleteDoc(doc(db, "feedback", id))

      if (isMounted.current) {
        setFeedback(feedback.filter((item) => item.id !== id))
        toast({
          title: "Success",
          description: "Feedback deleted successfully",
        })
      }
    } catch (error) {
      console.error("Error deleting feedback:", error)
      toast({
        title: "Error",
        description: "Failed to delete feedback",
        variant: "destructive",
      })
    } finally {
      setDeleteDialogOpen(false)
    }
  }

  const confirmDelete = (feedback) => {
    setSelectedFeedback(feedback)
    setDeleteDialogOpen(true)
  }

  const viewFeedback = (feedback) => {
    setSelectedFeedback(feedback)
    setViewDialogOpen(true)
  }

  const getSeverityBadge = (severity) => {
    const severityMap = {
      low: (
        <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
          Low
        </Badge>
      ),
      medium: (
        <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
          Medium
        </Badge>
      ),
      high: (
        <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
          High
        </Badge>
      ),
    }
    return severityMap[severity?.toLowerCase()] || severityMap.low
  }

  if (loading) {
    return (
      <div className="container mx-auto py-10">
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl">Customer Feedback</CardTitle>
            <CardDescription>View and manage customer feedback and suggestions</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[400px] w-full flex items-center justify-center">
              <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="container mx-auto py-10">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl">Customer Feedback</CardTitle>
          <CardDescription>View and manage customer feedback and suggestions</CardDescription>
        </CardHeader>
        <CardContent>
          {feedback.length === 0 ? (
            <div className="text-center py-10">
              <p className="text-muted-foreground">No feedback found</p>
            </div>
          ) : (
            <ResponsiveTable>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="hidden md:table-cell">Date</TableHead>
                    <TableHead className="w-[40%]">Customer</TableHead>
                    <TableHead className="hidden sm:table-cell">Subject</TableHead>
                    <TableHead className="hidden sm:table-cell">Type</TableHead>
                    <TableHead>Severity</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {feedback.map((item) => (
                    <TableRow key={item.id}>
                      <TableCell className="hidden md:table-cell">
                        {item.createdAt instanceof Date ? format(item.createdAt, "MMM dd, yyyy") : "Unknown date"}
                      </TableCell>
                      <TableCell>
                        <div className="font-medium truncate">{item.name || "Anonymous"}</div>
                        <div className="text-sm text-muted-foreground truncate">{item.email || "No email"}</div>
                        <div className="md:hidden text-xs text-muted-foreground mt-1">
                          {item.createdAt instanceof Date ? format(item.createdAt, "MMM dd, yyyy") : "Unknown date"}
                        </div>
                        <div className="sm:hidden text-xs text-muted-foreground mt-1 truncate">
                          {item.subject || "No subject"}
                        </div>
                      </TableCell>
                      <TableCell className="hidden sm:table-cell truncate max-w-[150px]">
                        {item.subject || "No subject"}
                      </TableCell>
                      <TableCell className="hidden sm:table-cell">
                        <Badge variant="outline">{item.type || "General"}</Badge>
                      </TableCell>
                      <TableCell>{getSeverityBadge(item.severity)}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button variant="ghost" size="icon" onClick={() => viewFeedback(item)}>
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" onClick={() => confirmDelete(item)}>
                            <Trash2 className="h-4 w-4 text-red-500" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </ResponsiveTable>
          )}
        </CardContent>
      </Card>

      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete this feedback. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-red-500 hover:bg-red-600"
              onClick={() => selectedFeedback && handleDelete(selectedFeedback.id)}
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <Dialog open={viewDialogOpen} onOpenChange={setViewDialogOpen}>
        <DialogContent className="sm:max-w-[525px]">
          <DialogHeader>
            <DialogTitle>Feedback Details</DialogTitle>
            <DialogDescription>
              {selectedFeedback?.createdAt instanceof Date
                ? format(selectedFeedback.createdAt, "MMMM dd, yyyy")
                : "Unknown date"}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 mt-4">
            <div>
              <h4 className="text-sm font-medium">Customer</h4>
              <p>{selectedFeedback?.name || "Anonymous"}</p>
              <p className="text-sm text-muted-foreground">{selectedFeedback?.email || "No email"}</p>
            </div>
            <div>
              <h4 className="text-sm font-medium">Subject</h4>
              <p>{selectedFeedback?.subject || "No subject"}</p>
            </div>
            <div>
              <h4 className="text-sm font-medium">Type</h4>
              <p>{selectedFeedback?.type || "General"}</p>
            </div>
            <div>
              <h4 className="text-sm font-medium">Severity</h4>
              <p>{selectedFeedback?.severity || "Low"}</p>
            </div>
            <div>
              <h4 className="text-sm font-medium">Message</h4>
              <p className="whitespace-pre-wrap">{selectedFeedback?.message || "No message"}</p>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}

