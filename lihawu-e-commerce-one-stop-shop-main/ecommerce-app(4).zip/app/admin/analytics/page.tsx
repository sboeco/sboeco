"use client"

import { useState, useEffect, useRef } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/components/auth-provider"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts"
import {
  DollarSign,
  ShoppingBag,
  Users,
  TrendingUp,
  ArrowUpRight,
  ArrowDownRight,
  Calendar,
  BarChartIcon,
} from "lucide-react"
import { collection, query, where, getDocs, orderBy, Timestamp } from "firebase/firestore"
import { db } from "@/lib/firebase"

export default function AnalyticsPage() {
  const { user, loading: authLoading, isAdmin } = useAuth()
  const router = useRouter()
  const [loading, setLoading] = useState(true)
  const [timeRange, setTimeRange] = useState("30days")
  const [salesData, setSalesData] = useState([])
  const [ordersData, setOrdersData] = useState([])
  const [customersData, setCustomersData] = useState([])
  const [topProducts, setTopProducts] = useState([])
  const [categoryDistribution, setCategoryDistribution] = useState([])
  const [metrics, setMetrics] = useState({
    totalRevenue: 0,
    totalOrders: 0,
    totalCustomers: 0,
    averageOrderValue: 0,
    revenueChange: 0,
    ordersChange: 0,
    customersChange: 0,
  })
  const isMounted = useRef(true)

  useEffect(() => {
    return () => {
      isMounted.current = false
    }
  }, [])

  useEffect(() => {
    if (!authLoading) {
      if (!user) {
        router.push("/login")
        return
      }

      if (!isAdmin()) {
        router.push("/dashboard")
        return
      }

      fetchAnalyticsData()
    }
  }, [user, authLoading, router, isAdmin, timeRange])

  const getDateRange = () => {
    const now = new Date()
    const endDate = now
    let startDate

    switch (timeRange) {
      case "7days":
        startDate = new Date(now)
        startDate.setDate(now.getDate() - 7)
        break
      case "30days":
        startDate = new Date(now)
        startDate.setDate(now.getDate() - 30)
        break
      case "90days":
        startDate = new Date(now)
        startDate.setDate(now.getDate() - 90)
        break
      case "year":
        startDate = new Date(now)
        startDate.setFullYear(now.getFullYear() - 1)
        break
      default:
        startDate = new Date(now)
        startDate.setDate(now.getDate() - 30)
    }

    return {
      startDate: Timestamp.fromDate(startDate),
      endDate: Timestamp.fromDate(endDate),
    }
  }

  const fetchAnalyticsData = async () => {
    try {
      setLoading(true)
      const { startDate, endDate } = getDateRange()

      // Get previous period for comparison
      const periodLength = endDate.toDate() - startDate.toDate()
      const prevStartDate = new Date(startDate.toDate().getTime() - periodLength)
      const prevEndDate = new Date(endDate.toDate().getTime() - periodLength)

      // Fetch orders for current period
      const ordersRef = collection(db, "orders")
      const ordersQuery = query(
        ordersRef,
        where("createdAt", ">=", startDate),
        where("createdAt", "<=", endDate),
        orderBy("createdAt", "desc"),
      )

      // Fetch orders for previous period
      const prevOrdersQuery = query(
        ordersRef,
        where("createdAt", ">=", Timestamp.fromDate(prevStartDate)),
        where("createdAt", "<=", Timestamp.fromDate(prevEndDate)),
        orderBy("createdAt", "desc"),
      )

      // Fetch users
      const usersRef = collection(db, "users")
      const usersQuery = query(
        usersRef,
        where("createdAt", ">=", startDate.toDate().toISOString()),
        where("createdAt", "<=", endDate.toDate().toISOString()),
        where("role", "==", "user"),
      )

      const prevUsersQuery = query(
        usersRef,
        where("createdAt", ">=", prevStartDate.toISOString()),
        where("createdAt", "<=", prevEndDate.toISOString()),
        where("role", "==", "user"),
      )

      // Execute queries
      const [ordersSnapshot, prevOrdersSnapshot, usersSnapshot, prevUsersSnapshot] = await Promise.all([
        getDocs(ordersQuery),
        getDocs(prevOrdersQuery),
        getDocs(usersQuery),
        getDocs(prevUsersQuery),
      ])

      // Process orders data
      const orders = ordersSnapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }))

      const prevOrders = prevOrdersSnapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }))

      // Process users data
      const customers = usersSnapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }))

      const prevCustomers = prevUsersSnapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }))

      // Calculate metrics
      const totalRevenue = orders.reduce((sum, order) => sum + (order.total || 0), 0)
      const prevTotalRevenue = prevOrders.reduce((sum, order) => sum + (order.total || 0), 0)
      const revenueChange = prevTotalRevenue === 0 ? 100 : ((totalRevenue - prevTotalRevenue) / prevTotalRevenue) * 100

      const totalOrders = orders.length
      const prevTotalOrders = prevOrders.length
      const ordersChange = prevTotalOrders === 0 ? 100 : ((totalOrders - prevTotalOrders) / prevTotalOrders) * 100

      const totalCustomers = customers.length
      const prevTotalCustomers = prevCustomers.length
      const customersChange =
        prevTotalCustomers === 0 ? 100 : ((totalCustomers - prevTotalCustomers) / prevTotalCustomers) * 100

      const averageOrderValue = totalOrders === 0 ? 0 : totalRevenue / totalOrders

      // Prepare sales data for charts
      const salesByDay = {}
      const ordersByDay = {}
      const customersByDay = {}

      // Initialize with zeros for all days in the range
      const days = Math.ceil((endDate.toDate() - startDate.toDate()) / (1000 * 60 * 60 * 24))
      for (let i = 0; i < days; i++) {
        const date = new Date(startDate.toDate())
        date.setDate(date.getDate() + i)
        const dateStr = date.toISOString().split("T")[0]
        salesByDay[dateStr] = 0
        ordersByDay[dateStr] = 0
        customersByDay[dateStr] = 0
      }

      // Fill in actual data
      orders.forEach((order) => {
        const date = new Date(order.createdAt.toDate()).toISOString().split("T")[0]
        salesByDay[date] = (salesByDay[date] || 0) + order.total
        ordersByDay[date] = (ordersByDay[date] || 0) + 1
      })

      customers.forEach((customer) => {
        const date = new Date(customer.createdAt).toISOString().split("T")[0]
        customersByDay[date] = (customersByDay[date] || 0) + 1
      })

      // Convert to array format for charts
      const salesChartData = Object.entries(salesByDay).map(([date, value]) => ({
        date,
        value,
      }))

      const ordersChartData = Object.entries(ordersByDay).map(([date, value]) => ({
        date,
        value,
      }))

      const customersChartData = Object.entries(customersByDay).map(([date, value]) => ({
        date,
        value,
      }))

      // Calculate top products
      const productSales = {}
      orders.forEach((order) => {
        order.items.forEach((item) => {
          if (!productSales[item.id]) {
            productSales[item.id] = {
              id: item.id,
              name: item.name,
              quantity: 0,
              revenue: 0,
            }
          }
          productSales[item.id].quantity += item.quantity
          productSales[item.id].revenue += item.price * item.quantity
        })
      })

      const topProductsData = Object.values(productSales)
        .sort((a, b) => b.revenue - a.revenue)
        .slice(0, 5)

      // Calculate category distribution
      const categorySales = {}
      orders.forEach((order) => {
        order.items.forEach((item) => {
          const category = item.category || "Uncategorized"

          if (!categorySales[category]) {
            categorySales[category] = {
              name: category,
              value: 0,
            }
          }
          categorySales[category].value += item.price * item.quantity
        })
      })

      const categoryDistributionData = Object.values(categorySales).sort((a, b) => b.value - a.value)

      if (isMounted.current) {
        // Update state with all the calculated data
        setSalesData(salesChartData)
        setOrdersData(ordersChartData)
        setCustomersData(customersChartData)
        setTopProducts(topProductsData)
        setCategoryDistribution(categoryDistributionData)
        setMetrics({
          totalRevenue,
          totalOrders,
          totalCustomers,
          averageOrderValue,
          revenueChange,
          ordersChange,
          customersChange,
        })
        setLoading(false)
      }
    } catch (error) {
      console.error("Error fetching analytics data:", error)
      if (isMounted.current) {
        setLoading(false)
      }
    }
  }

  const formatCurrency = (value) => {
    return `SZL ${value.toFixed(2)}`
  }

  const formatDate = (dateString) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("en-US", { month: "short", day: "numeric" })
  }

  const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#8884D8", "#82ca9d"]

  return (
    <div className="flex-1 space-y-4 p-8 pt-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Analytics Dashboard</h2>
          <p className="text-muted-foreground">Get detailed insights about your store's performance</p>
        </div>
        <div className="flex items-center gap-2">
          <Calendar className="h-4 w-4 text-muted-foreground" />
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select time range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7days">Last 7 days</SelectItem>
              <SelectItem value="30days">Last 30 days</SelectItem>
              <SelectItem value="90days">Last 90 days</SelectItem>
              <SelectItem value="year">Last year</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {loading ? (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  <div className="h-4 w-24 bg-muted rounded"></div>
                </CardTitle>
                <div className="h-4 w-4 bg-muted rounded-full"></div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  <div className="h-8 w-16 bg-muted rounded"></div>
                </div>
                <div className="text-xs text-muted-foreground">
                  <div className="h-4 w-32 bg-muted rounded mt-1"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
                <DollarSign className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{formatCurrency(metrics.totalRevenue)}</div>
                <div className="flex items-center text-xs text-muted-foreground">
                  {metrics.revenueChange >= 0 ? (
                    <ArrowUpRight className="mr-1 h-4 w-4 text-green-500" />
                  ) : (
                    <ArrowDownRight className="mr-1 h-4 w-4 text-red-500" />
                  )}
                  <span className={metrics.revenueChange >= 0 ? "text-green-500" : "text-red-500"}>
                    {Math.abs(metrics.revenueChange).toFixed(1)}%
                  </span>
                  <span className="ml-1">vs. previous period</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Orders</CardTitle>
                <ShoppingBag className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{metrics.totalOrders}</div>
                <div className="flex items-center text-xs text-muted-foreground">
                  {metrics.ordersChange >= 0 ? (
                    <ArrowUpRight className="mr-1 h-4 w-4 text-green-500" />
                  ) : (
                    <ArrowDownRight className="mr-1 h-4 w-4 text-red-500" />
                  )}
                  <span className={metrics.ordersChange >= 0 ? "text-green-500" : "text-red-500"}>
                    {Math.abs(metrics.ordersChange).toFixed(1)}%
                  </span>
                  <span className="ml-1">vs. previous period</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">New Customers</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{metrics.totalCustomers}</div>
                <div className="flex items-center text-xs text-muted-foreground">
                  {metrics.customersChange >= 0 ? (
                    <ArrowUpRight className="mr-1 h-4 w-4 text-green-500" />
                  ) : (
                    <ArrowDownRight className="mr-1 h-4 w-4 text-red-500" />
                  )}
                  <span className={metrics.customersChange >= 0 ? "text-green-500" : "text-red-500"}>
                    {Math.abs(metrics.customersChange).toFixed(1)}%
                  </span>
                  <span className="ml-1">vs. previous period</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Avg. Order Value</CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{formatCurrency(metrics.averageOrderValue)}</div>
                <div className="text-xs text-muted-foreground">For {metrics.totalOrders} orders</div>
              </CardContent>
            </Card>
          </div>

          <Tabs defaultValue="sales" className="space-y-4">
            <TabsList>
              <TabsTrigger value="sales">Sales</TabsTrigger>
              <TabsTrigger value="orders">Orders</TabsTrigger>
              <TabsTrigger value="customers">Customers</TabsTrigger>
            </TabsList>

            <TabsContent value="sales" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Sales Trend</CardTitle>
                  <CardDescription>Daily revenue for the selected period</CardDescription>
                </CardHeader>
                <CardContent className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart
                      data={salesData}
                      margin={{
                        top: 5,
                        right: 30,
                        left: 20,
                        bottom: 5,
                      }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" tickFormatter={formatDate} tick={{ fontSize: 12 }} />
                      <YAxis tickFormatter={(value) => `SZL ${value}`} tick={{ fontSize: 12 }} />
                      <Tooltip
                        formatter={(value) => [`SZL ${value.toFixed(2)}`, "Revenue"]}
                        labelFormatter={(label) => formatDate(label)}
                      />
                      <Legend />
                      <Line type="monotone" dataKey="value" name="Revenue" stroke="#8884d8" activeDot={{ r: 8 }} />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <div className="grid gap-4 md:grid-cols-2">
                <Card>
                  <CardHeader>
                    <CardTitle>Top Selling Products</CardTitle>
                    <CardDescription>Products with the highest revenue</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {topProducts.length > 0 ? (
                      <div className="space-y-4">
                        {topProducts.map((product, index) => (
                          <div key={product.id} className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10">
                                {index + 1}
                              </div>
                              <div>
                                <p className="text-sm font-medium">{product.name}</p>
                                <p className="text-xs text-muted-foreground">{product.quantity} units sold</p>
                              </div>
                            </div>
                            <div className="font-medium">{formatCurrency(product.revenue)}</div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="flex flex-col items-center justify-center py-8 text-center">
                        <BarChartIcon className="h-10 w-10 text-muted-foreground mb-2" />
                        <h3 className="text-lg font-medium">No data available</h3>
                        <p className="text-sm text-muted-foreground">There are no sales in the selected period.</p>
                      </div>
                    )}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Sales by Category</CardTitle>
                    <CardDescription>Revenue distribution across product categories</CardDescription>
                  </CardHeader>
                  <CardContent className="h-[300px]">
                    {categoryDistribution.length > 0 ? (
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={categoryDistribution}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            outerRadius={80}
                            fill="#8884d8"
                            dataKey="value"
                            nameKey="name"
                            label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                          >
                            {categoryDistribution.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                          </Pie>
                          <Tooltip formatter={(value) => formatCurrency(value)} />
                          <Legend />
                        </PieChart>
                      </ResponsiveContainer>
                    ) : (
                      <div className="flex flex-col items-center justify-center h-full text-center">
                        <BarChartIcon className="h-10 w-10 text-muted-foreground mb-2" />
                        <h3 className="text-lg font-medium">No data available</h3>
                        <p className="text-sm text-muted-foreground">There are no sales in the selected period.</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="orders" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Order Trend</CardTitle>
                  <CardDescription>Daily order count for the selected period</CardDescription>
                </CardHeader>
                <CardContent className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={ordersData}
                      margin={{
                        top: 5,
                        right: 30,
                        left: 20,
                        bottom: 5,
                      }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" tickFormatter={formatDate} tick={{ fontSize: 12 }} />
                      <YAxis allowDecimals={false} tick={{ fontSize: 12 }} />
                      <Tooltip formatter={(value) => [value, "Orders"]} labelFormatter={(label) => formatDate(label)} />
                      <Legend />
                      <Bar dataKey="value" name="Orders" fill="#82ca9d" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="customers" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>New Customers</CardTitle>
                  <CardDescription>Daily new customer registrations for the selected period</CardDescription>
                </CardHeader>
                <CardContent className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={customersData}
                      margin={{
                        top: 5,
                        right: 30,
                        left: 20,
                        bottom: 5,
                      }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" tickFormatter={formatDate} tick={{ fontSize: 12 }} />
                      <YAxis allowDecimals={false} tick={{ fontSize: 12 }} />
                      <Tooltip
                        formatter={(value) => [value, "Customers"]}
                        labelFormatter={(label) => formatDate(label)}
                      />
                      <Legend />
                      <Bar dataKey="value" name="New Customers" fill="#8884d8" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </>
      )}
    </div>
  )
}

