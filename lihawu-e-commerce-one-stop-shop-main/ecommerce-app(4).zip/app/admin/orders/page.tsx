"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Badge } from "@/components/ui/badge"
import { Search, MoreHorizontal, Eye, CheckCircle, Truck, Clock, AlertCircle } from "lucide-react"
import { getOrders, updateOrder } from "@/lib/firebase/orders"
import { useToast } from "@/components/ui/use-toast"
import { ResponsiveTable } from "@/components/ui/responsive-table"

export default function AdminOrdersPage() {
  const [orders, setOrders] = useState([])
  const [filteredOrders, setFilteredOrders] = useState([])
  const [searchQuery, setSearchQuery] = useState("")
  const [loading, setLoading] = useState(true)
  const { toast } = useToast()

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const ordersData = await getOrders()
        setOrders(ordersData || [])
        setFilteredOrders(ordersData || [])
      } catch (error) {
        console.error("Error fetching orders:", error)
        toast({
          title: "Error",
          description: "Failed to load orders. Please try again.",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    }

    fetchOrders()
  }, [toast])

  useEffect(() => {
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      const filtered = orders.filter(
        (order) =>
          order.orderNumber?.toLowerCase().includes(query) ||
          order.customerName?.toLowerCase().includes(query) ||
          order.customerEmail?.toLowerCase().includes(query),
      )
      setFilteredOrders(filtered)
    } else {
      setFilteredOrders(orders)
    }
  }, [searchQuery, orders])

  const handleUpdateOrderStatus = async (id, status, orderNumber) => {
    try {
      await updateOrder(id, { status })
      setOrders((prevOrders) => prevOrders.map((order) => (order.id === id ? { ...order, status } : order)))
      toast({
        title: "Order updated",
        description: `Order #${orderNumber} status changed to ${status}.`,
      })
    } catch (error) {
      console.error("Error updating order:", error)
      toast({
        title: "Error",
        description: "Failed to update order status. Please try again.",
        variant: "destructive",
      })
    }
  }

  const getStatusBadge = (status) => {
    switch (status) {
      case "completed":
        return (
          <Badge className="bg-green-100 text-green-800 border-green-300 flex items-center gap-1">
            <CheckCircle className="h-3 w-3" /> Completed
          </Badge>
        )
      case "processing":
        return (
          <Badge className="bg-blue-100 text-blue-800 border-blue-300 flex items-center gap-1">
            <Truck className="h-3 w-3" /> Processing
          </Badge>
        )
      case "pending":
        return (
          <Badge className="bg-yellow-100 text-yellow-800 border-yellow-300 flex items-center gap-1">
            <Clock className="h-3 w-3" /> Pending
          </Badge>
        )
      case "cancelled":
        return (
          <Badge className="bg-red-100 text-red-800 border-red-300 flex items-center gap-1">
            <AlertCircle className="h-3 w-3" /> Cancelled
          </Badge>
        )
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  return (
    <div className="flex-1 space-y-4 p-8 pt-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Orders</h2>
        <p className="text-muted-foreground">Manage customer orders</p>
      </div>

      <div className="flex items-center gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search orders..."
            className="pl-8 w-full md:max-w-sm"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      {loading ? (
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Order</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Customer</TableHead>
                <TableHead>Total</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {Array.from({ length: 5 }).map((_, i) => (
                <TableRow key={i} className="animate-pulse">
                  <TableCell>
                    <div className="h-4 w-24 bg-muted rounded"></div>
                  </TableCell>
                  <TableCell>
                    <div className="h-4 w-28 bg-muted rounded"></div>
                  </TableCell>
                  <TableCell>
                    <div className="h-4 w-32 bg-muted rounded"></div>
                  </TableCell>
                  <TableCell>
                    <div className="h-4 w-16 bg-muted rounded"></div>
                  </TableCell>
                  <TableCell>
                    <div className="h-6 w-20 bg-muted rounded"></div>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="h-8 w-8 bg-muted rounded-full ml-auto"></div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      ) : filteredOrders.length > 0 ? (
        <ResponsiveTable className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[30%]">Order</TableHead>
                <TableHead className="hidden md:table-cell">Date</TableHead>
                <TableHead className="hidden sm:table-cell">Customer</TableHead>
                <TableHead>Total</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredOrders.map((order) => (
                <TableRow key={order.id}>
                  <TableCell>
                    <div className="font-medium">#{order.orderNumber}</div>
                    <div className="text-sm text-muted-foreground">{order.items?.length || 0} items</div>
                    <div className="md:hidden text-sm text-muted-foreground mt-1">
                      {new Date(order.createdAt).toLocaleDateString()}
                    </div>
                    <div className="sm:hidden text-sm text-muted-foreground mt-1">{order.customerName || "Guest"}</div>
                  </TableCell>
                  <TableCell className="hidden md:table-cell">
                    {new Date(order.createdAt).toLocaleDateString()}
                    <div className="text-sm text-muted-foreground">
                      {new Date(order.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                    </div>
                  </TableCell>
                  <TableCell className="hidden sm:table-cell">
                    <div className="truncate max-w-[150px]">{order.customerName || "Guest"}</div>
                    <div className="text-sm text-muted-foreground truncate max-w-[150px]">
                      {order.customerEmail || "N/A"}
                    </div>
                  </TableCell>
                  <TableCell>SZL {order.total?.toFixed(2) || "0.00"}</TableCell>
                  <TableCell>{getStatusBadge(order.status)}</TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <MoreHorizontal className="h-4 w-4" />
                          <span className="sr-only">Open menu</span>
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuLabel>Actions</DropdownMenuLabel>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem asChild>
                          <a href={`/admin/orders/${order.id}`}>
                            <Eye className="mr-2 h-4 w-4" /> View Details
                          </a>
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuLabel>Update Status</DropdownMenuLabel>
                        <DropdownMenuItem
                          onClick={() => handleUpdateOrderStatus(order.id, "pending", order.orderNumber)}
                          disabled={order.status === "pending"}
                        >
                          <Clock className="mr-2 h-4 w-4" /> Pending
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          onClick={() => handleUpdateOrderStatus(order.id, "processing", order.orderNumber)}
                          disabled={order.status === "processing"}
                        >
                          <Truck className="mr-2 h-4 w-4" /> Processing
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          onClick={() => handleUpdateOrderStatus(order.id, "completed", order.orderNumber)}
                          disabled={order.status === "completed"}
                        >
                          <CheckCircle className="mr-2 h-4 w-4" /> Completed
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          onClick={() => handleUpdateOrderStatus(order.id, "cancelled", order.orderNumber)}
                          disabled={order.status === "cancelled"}
                          className="text-red-600 focus:text-red-600"
                        >
                          <AlertCircle className="mr-2 h-4 w-4" /> Cancelled
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </ResponsiveTable>
      ) : (
        <div className="rounded-md border bg-muted/30 flex flex-col items-center justify-center p-12 text-center">
          <div className="rounded-full bg-muted p-3 mb-4">
            <Search className="h-6 w-6 text-muted-foreground" />
          </div>
          <h3 className="text-lg font-medium mb-2">No orders found</h3>
          <p className="text-muted-foreground mb-6 max-w-md">
            {searchQuery
              ? `No orders match "${searchQuery}". Try a different search term.`
              : "No orders have been placed yet."}
          </p>
        </div>
      )}
    </div>
  )
}

