"use client"

import { useState, useEffect, useRef } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/components/auth-provider"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  AlertTriangle,
  PackageX,
  Package,
  TrendingDown,
  Search,
  Filter,
  ArrowUpDown,
  Settings,
  RefreshCw,
  CheckCircle2,
  XCircle,
  Clock,
} from "lucide-react"
import { getProducts } from "@/lib/firebase/products"

export default function InventoryAlertPage() {
  const { user, loading: authLoading, isAdmin } = useAuth()
  const router = useRouter()
  const [loading, setLoading] = useState(true)
  const [products, setProducts] = useState([])
  const [filteredProducts, setFilteredProducts] = useState([])
  const [searchTerm, setSearchTerm] = useState("")
  const [alertThreshold, setAlertThreshold] = useState(10)
  const [sortConfig, setSortConfig] = useState({ key: "stock", direction: "asc" })
  const [filter, setFilter] = useState("all") // all, low, out
  const isMounted = useRef(true)

  useEffect(() => {
    return () => {
      isMounted.current = false
    }
  }, [])

  useEffect(() => {
    if (!authLoading) {
      if (!user) {
        router.push("/login")
        return
      }

      if (!isAdmin()) {
        router.push("/dashboard")
        return
      }

      fetchProducts()
    }
  }, [user, authLoading, router, isAdmin])

  useEffect(() => {
    if (products.length > 0) {
      let filtered = [...products]

      // Apply search filter
      if (searchTerm) {
        filtered = filtered.filter(
          (product) =>
            product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
            product.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
            product.id.toLowerCase().includes(searchTerm.toLowerCase()),
        )
      }

      // Apply stock filter
      if (filter === "low") {
        filtered = filtered.filter((product) => product.stock > 0 && product.stock <= alertThreshold)
      } else if (filter === "out") {
        filtered = filtered.filter((product) => product.stock === 0)
      }

      // Apply sorting
      filtered.sort((a, b) => {
        if (a[sortConfig.key] < b[sortConfig.key]) {
          return sortConfig.direction === "asc" ? -1 : 1
        }
        if (a[sortConfig.key] > b[sortConfig.key]) {
          return sortConfig.direction === "asc" ? 1 : -1
        }
        return 0
      })

      setFilteredProducts(filtered)
    }
  }, [products, searchTerm, filter, alertThreshold, sortConfig])

  const fetchProducts = async () => {
    try {
      setLoading(true)
      const productsData = await getProducts()

      if (isMounted.current) {
        setProducts(productsData || [])
        setLoading(false)
      }
    } catch (error) {
      console.error("Error fetching products:", error)
      if (isMounted.current) {
        setLoading(false)
      }
    }
  }

  const handleSort = (key) => {
    let direction = "asc"
    if (sortConfig.key === key && sortConfig.direction === "asc") {
      direction = "desc"
    }
    setSortConfig({ key, direction })
  }

  const getStockStatus = (stock) => {
    if (stock === 0) {
      return { label: "Out of Stock", variant: "destructive", icon: PackageX }
    } else if (stock <= alertThreshold) {
      return { label: "Low Stock", variant: "warning", icon: AlertTriangle }
    } else {
      return { label: "In Stock", variant: "success", icon: Package }
    }
  }

  const getLowStockCount = () => {
    return products.filter((product) => product.stock > 0 && product.stock <= alertThreshold).length
  }

  const getOutOfStockCount = () => {
    return products.filter((product) => product.stock === 0).length
  }

  const getStockValue = () => {
    return products.reduce((total, product) => {
      const price = Number(product.price) || 0
      const stock = Number(product.stock) || 0
      return total + price * stock
    }, 0)
  }

  const refreshInventory = () => {
    fetchProducts()
  }

  return (
    <div className="flex-1 space-y-4 p-8 pt-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Inventory Alerts</h2>
          <p className="text-muted-foreground">Monitor low stock and out of stock products</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={refreshInventory}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
          <Button variant="outline" size="sm" onClick={() => router.push("/admin/settings")}>
            <Settings className="h-4 w-4 mr-2" />
            Settings
          </Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Products</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {loading ? <div className="h-8 w-16 bg-muted rounded animate-pulse"></div> : products.length}
            </div>
            <p className="text-xs text-muted-foreground">Total products in inventory</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Low Stock</CardTitle>
            <AlertTriangle className="h-4 w-4 text-amber-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {loading ? <div className="h-8 w-16 bg-muted rounded animate-pulse"></div> : getLowStockCount()}
            </div>
            <p className="text-xs text-muted-foreground">Products below threshold ({alertThreshold} units)</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Out of Stock</CardTitle>
            <PackageX className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {loading ? <div className="h-8 w-16 bg-muted rounded animate-pulse"></div> : getOutOfStockCount()}
            </div>
            <p className="text-xs text-muted-foreground">Products with zero inventory</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Inventory Value</CardTitle>
            <TrendingDown className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {loading ? (
                <div className="h-8 w-16 bg-muted rounded animate-pulse"></div>
              ) : (
                `SZL ${getStockValue().toFixed(2)}`
              )}
            </div>
            <p className="text-xs text-muted-foreground">Total value of current inventory</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="inventory" className="space-y-4">
        <TabsList>
          <TabsTrigger value="inventory">Inventory</TabsTrigger>
          <TabsTrigger value="alerts">Alert Settings</TabsTrigger>
          <TabsTrigger value="history">Alert History</TabsTrigger>
        </TabsList>

        <TabsContent value="inventory" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Inventory Status</CardTitle>
              <CardDescription>Monitor and manage your product inventory levels</CardDescription>
              <div className="flex flex-col sm:flex-row gap-2 mt-2">
                <div className="flex items-center gap-2 flex-1">
                  <Search className="h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search products..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                <div className="flex items-center gap-2">
                  <Filter className="h-4 w-4 text-muted-foreground" />
                  <select
                    className="bg-background border rounded-md px-3 py-2 text-sm"
                    value={filter}
                    onChange={(e) => setFilter(e.target.value)}
                  >
                    <option value="all">All Products</option>
                    <option value="low">Low Stock</option>
                    <option value="out">Out of Stock</option>
                  </select>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="space-y-2">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <div key={i} className="w-full h-12 bg-muted rounded animate-pulse"></div>
                  ))}
                </div>
              ) : filteredProducts.length > 0 ? (
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-[300px]">
                          <Button variant="ghost" onClick={() => handleSort("name")}>
                            Product Name
                            <ArrowUpDown className="ml-2 h-4 w-4" />
                          </Button>
                        </TableHead>
                        <TableHead>
                          <Button variant="ghost" onClick={() => handleSort("category")}>
                            Category
                            <ArrowUpDown className="ml-2 h-4 w-4" />
                          </Button>
                        </TableHead>
                        <TableHead>
                          <Button variant="ghost" onClick={() => handleSort("stock")}>
                            Stock
                            <ArrowUpDown className="ml-2 h-4 w-4" />
                          </Button>
                        </TableHead>
                        <TableHead>
                          <Button variant="ghost" onClick={() => handleSort("price")}>
                            Price
                            <ArrowUpDown className="ml-2 h-4 w-4" />
                          </Button>
                        </TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredProducts.map((product) => {
                        const stockStatus = getStockStatus(product.stock)
                        const StockIcon = stockStatus.icon

                        return (
                          <TableRow key={product.id}>
                            <TableCell className="font-medium">
                              <div className="flex items-center gap-2">
                                <div className="h-8 w-8 rounded bg-muted overflow-hidden">
                                  <img
                                    src={product.image || "/placeholder.svg?height=32&width=32"}
                                    alt={product.name}
                                    className="h-full w-full object-cover"
                                  />
                                </div>
                                <span>{product.name}</span>
                              </div>
                            </TableCell>
                            <TableCell>{product.category}</TableCell>
                            <TableCell>{product.stock}</TableCell>
                            <TableCell>SZL {Number(product.price).toFixed(2)}</TableCell>
                            <TableCell>
                              <Badge variant={stockStatus.variant} className="flex items-center gap-1 w-fit">
                                <StockIcon className="h-3 w-3" />
                                <span>{stockStatus.label}</span>
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => router.push(`/admin/products/edit/${product.id}`)}
                                >
                                  Update
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => router.push(`/products/${product.id}`)}
                                >
                                  View
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        )
                      })}
                    </TableBody>
                  </Table>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-8 text-center">
                  <Package className="h-10 w-10 text-muted-foreground mb-2" />
                  <h3 className="text-lg font-medium">No products found</h3>
                  <p className="text-sm text-muted-foreground">
                    {filter !== "all"
                      ? `No products match the current ${filter === "low" ? "low stock" : "out of stock"} filter.`
                      : "Try adjusting your search or filter to find what you're looking for."}
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="alerts" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Alert Settings</CardTitle>
              <CardDescription>Configure inventory alert thresholds and notifications</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="space-y-2">
                  <h3 className="text-sm font-medium">Low Stock Threshold</h3>
                  <div className="flex items-center gap-4">
                    <Input
                      type="number"
                      min="1"
                      value={alertThreshold}
                      onChange={(e) => setAlertThreshold(Number.parseInt(e.target.value) || 10)}
                      className="max-w-[100px]"
                    />
                    <span className="text-sm text-muted-foreground">units</span>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Products with stock below this threshold will be marked as "Low Stock"
                  </p>
                </div>

                <div className="space-y-2">
                  <h3 className="text-sm font-medium">Email Notifications</h3>
                  <div className="flex items-center gap-4">
                    <div className="flex items-center space-x-2">
                      <input type="checkbox" id="low-stock-email" className="rounded border-gray-300" />
                      <label htmlFor="low-stock-email" className="text-sm">
                        Low stock alerts
                      </label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <input type="checkbox" id="out-of-stock-email" className="rounded border-gray-300" />
                      <label htmlFor="out-of-stock-email" className="text-sm">
                        Out of stock alerts
                      </label>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <h3 className="text-sm font-medium">Notification Recipients</h3>
                  <Input placeholder="Enter email addresses (comma separated)" className="w-full" />
                  <p className="text-xs text-muted-foreground">
                    Add email addresses that should receive inventory alerts
                  </p>
                </div>

                <div className="space-y-2">
                  <h3 className="text-sm font-medium">Alert Frequency</h3>
                  <select className="w-full bg-background border rounded-md px-3 py-2 text-sm">
                    <option value="immediately">Immediately</option>
                    <option value="daily">Daily summary</option>
                    <option value="weekly">Weekly summary</option>
                  </select>
                  <p className="text-xs text-muted-foreground">
                    How often you want to receive inventory alert notifications
                  </p>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button>Save Settings</Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="history" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Alert History</CardTitle>
              <CardDescription>Recent inventory alerts and notifications</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Date & Time</TableHead>
                        <TableHead>Alert Type</TableHead>
                        <TableHead>Product</TableHead>
                        <TableHead>Stock Level</TableHead>
                        <TableHead>Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {/* Sample alert history data */}
                      <TableRow>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Clock className="h-4 w-4 text-muted-foreground" />
                            <span>2023-03-22 14:35</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="warning" className="flex items-center gap-1 w-fit">
                            <AlertTriangle className="h-3 w-3" />
                            <span>Low Stock</span>
                          </Badge>
                        </TableCell>
                        <TableCell>Wireless Headphones</TableCell>
                        <TableCell>5 units</TableCell>
                        <TableCell>
                          <Badge variant="outline" className="flex items-center gap-1 w-fit">
                            <CheckCircle2 className="h-3 w-3 text-green-500" />
                            <span>Resolved</span>
                          </Badge>
                        </TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Clock className="h-4 w-4 text-muted-foreground" />
                            <span>2023-03-21 09:12</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="destructive" className="flex items-center gap-1 w-fit">
                            <PackageX className="h-3 w-3" />
                            <span>Out of Stock</span>
                          </Badge>
                        </TableCell>
                        <TableCell>Smart Watch</TableCell>
                        <TableCell>0 units</TableCell>
                        <TableCell>
                          <Badge variant="outline" className="flex items-center gap-1 w-fit">
                            <XCircle className="h-3 w-3 text-red-500" />
                            <span>Pending</span>
                          </Badge>
                        </TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Clock className="h-4 w-4 text-muted-foreground" />
                            <span>2023-03-20 16:48</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="warning" className="flex items-center gap-1 w-fit">
                            <AlertTriangle className="h-3 w-3" />
                            <span>Low Stock</span>
                          </Badge>
                        </TableCell>
                        <TableCell>Bluetooth Speaker</TableCell>
                        <TableCell>3 units</TableCell>
                        <TableCell>
                          <Badge variant="outline" className="flex items-center gap-1 w-fit">
                            <CheckCircle2 className="h-3 w-3 text-green-500" />
                            <span>Resolved</span>
                          </Badge>
                        </TableCell>
                      </TableRow>
                    </TableBody>
                  </Table>
                </div>

                <div className="flex justify-center">
                  <Button variant="outline" size="sm">
                    Load More
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

