import Link from "next/link"
import type { Metadata } from "next"
import { Button } from "@/components/ui/button"
import { Card, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Clock, Calendar, User, ChevronRight } from "lucide-react"

export const metadata: Metadata = {
  title: "Blog | EcoShop",
  description: "Latest news, tips, and updates from EcoShop",
}

const blogPosts = [
  {
    id: "1",
    title: "Top 10 Summer Fashion Trends for 2025",
    excerpt: "Discover the hottest fashion trends that will dominate the summer season this year.",
    coverImage: "/placeholder.svg?height=400&width=600",
    date: "March 15, 2025",
    readTime: "5 min read",
    author: "Jane Smith",
    category: "Fashion",
    slug: "top-10-summer-fashion-trends-2025",
  },
  {
    id: "2",
    title: "How to Choose the Perfect Smartphone in 2025",
    excerpt:
      "With so many options available, finding the right smartphone can be overwhelming. Here's our guide to help you make the best choice.",
    coverImage: "/placeholder.svg?height=400&width=600",
    date: "March 10, 2025",
    readTime: "8 min read",
    author: "John Doe",
    category: "Technology",
    slug: "how-to-choose-perfect-smartphone-2025",
  },
  {
    id: "3",
    title: "Sustainable Shopping: Making Eco-Friendly Choices",
    excerpt: "Learn how your shopping habits can make a positive impact on the environment.",
    coverImage: "/placeholder.svg?height=400&width=600",
    date: "March 5, 2025",
    readTime: "6 min read",
    author: "Emma Green",
    category: "Sustainability",
    slug: "sustainable-shopping-eco-friendly-choices",
  },
  {
    id: "4",
    title: "The Rise of Smart Home Devices: What You Need to Know",
    excerpt: "Smart home technology is transforming how we live. Here's what you should know before investing.",
    coverImage: "/placeholder.svg?height=400&width=600",
    date: "February 28, 2025",
    readTime: "7 min read",
    author: "Michael Tech",
    category: "Technology",
    slug: "rise-of-smart-home-devices",
  },
  {
    id: "5",
    title: "Budget-Friendly Home Decor Ideas",
    excerpt: "Transform your living space without breaking the bank with these creative decor ideas.",
    coverImage: "/placeholder.svg?height=400&width=600",
    date: "February 20, 2025",
    readTime: "4 min read",
    author: "Sarah Designs",
    category: "Home & Decor",
    slug: "budget-friendly-home-decor-ideas",
  },
  {
    id: "6",
    title: "Essential Kitchen Gadgets Every Home Cook Needs",
    excerpt: "Upgrade your cooking game with these must-have kitchen tools and gadgets.",
    coverImage: "/placeholder.svg?height=400&width=600",
    date: "February 15, 2025",
    readTime: "5 min read",
    author: "Chef Alex",
    category: "Kitchen",
    slug: "essential-kitchen-gadgets",
  },
]

export default function BlogPage() {
  const featuredPost = blogPosts[0]
  const regularPosts = blogPosts.slice(1)

  return (
    <div className="container px-4 md:px-6 py-12 mx-auto">
      <div className="flex flex-col items-start gap-4 md:flex-row md:justify-between md:gap-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">Blog</h1>
          <p className="mt-4 text-lg text-muted-foreground">
            Discover the latest trends, tips, and insights from our experts
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline">Categories</Button>
          <Button variant="outline">Archives</Button>
        </div>
      </div>

      <div className="mt-12">
        {/* Featured post */}
        <div className="mb-12">
          <Card className="overflow-hidden">
            <div className="md:flex">
              <div className="md:w-1/2">
                <img
                  src={featuredPost.coverImage || "/placeholder.svg"}
                  alt={featuredPost.title}
                  className="h-64 w-full object-cover md:h-full"
                />
              </div>
              <div className="md:w-1/2 p-6 md:p-8 flex flex-col justify-center">
                <Badge className="w-fit mb-4">{featuredPost.category}</Badge>
                <CardTitle className="text-2xl md:text-3xl mb-4">{featuredPost.title}</CardTitle>
                <CardDescription className="text-base mb-6">{featuredPost.excerpt}</CardDescription>
                <div className="flex items-center gap-4 text-sm text-muted-foreground mb-6">
                  <div className="flex items-center">
                    <Calendar className="mr-1 h-4 w-4" />
                    {featuredPost.date}
                  </div>
                  <div className="flex items-center">
                    <Clock className="mr-1 h-4 w-4" />
                    {featuredPost.readTime}
                  </div>
                  <div className="flex items-center">
                    <User className="mr-1 h-4 w-4" />
                    {featuredPost.author}
                  </div>
                </div>
                <Button asChild>
                  <Link href={`/blog/${featuredPost.slug}`}>
                    Read More <ChevronRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </div>
            </div>
          </Card>
        </div>

        {/* Regular posts grid */}
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {regularPosts.map((post) => (
            <Card key={post.id} className="overflow-hidden flex flex-col">
              <div className="relative h-48">
                <img
                  src={post.coverImage || "/placeholder.svg"}
                  alt={post.title}
                  className="h-full w-full object-cover"
                />
                <Badge className="absolute top-4 left-4">{post.category}</Badge>
              </div>
              <CardHeader className="flex-1">
                <CardTitle className="line-clamp-2">{post.title}</CardTitle>
                <CardDescription className="line-clamp-3 mt-2">{post.excerpt}</CardDescription>
              </CardHeader>
              <CardFooter className="flex flex-col items-start gap-4 border-t pt-6">
                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                  <div className="flex items-center">
                    <Calendar className="mr-1 h-4 w-4" />
                    {post.date}
                  </div>
                  <div className="flex items-center">
                    <Clock className="mr-1 h-4 w-4" />
                    {post.readTime}
                  </div>
                </div>
                <Button variant="ghost" className="p-0 h-auto" asChild>
                  <Link href={`/blog/${post.slug}`}>
                    Read More <ChevronRight className="ml-1 h-4 w-4" />
                  </Link>
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>

        <div className="mt-12 flex justify-center">
          <Button variant="outline" size="lg">
            Load More Articles
          </Button>
        </div>
      </div>
    </div>
  )
}

