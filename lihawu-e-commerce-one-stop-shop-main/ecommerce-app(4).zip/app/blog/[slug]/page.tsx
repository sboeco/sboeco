import Link from "next/link"
import { notFound } from "next/navigation"
import type { Metadata } from "next"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Clock, Calendar, ArrowLeft, Facebook, Twitter, Linkedin, Share2 } from "lucide-react"

export async function generateMetadata({ params }): Promise<Metadata> {
  // In a real app, you would fetch the blog post data from your database
  const post = getBlogPostBySlug(params.slug)

  if (!post) {
    return {
      title: "Blog Post Not Found | EcoShop",
    }
  }

  return {
    title: `${post.title} | EcoShop Blog`,
    description: post.excerpt,
  }
}

// Mock function to get blog post by slug
function getBlogPostBySlug(slug: string) {
  const blogPosts = [
    {
      id: "1",
      title: "Top 10 Summer Fashion Trends for 2025",
      excerpt: "Discover the hottest fashion trends that will dominate the summer season this year.",
      coverImage: "/placeholder.svg?height=600&width=1200",
      date: "March 15, 2025",
      readTime: "5 min read",
      author: "Jane Smith",
      authorImage: "/placeholder.svg?height=100&width=100",
      category: "Fashion",
      slug: "top-10-summer-fashion-trends-2025",
      content: `
        <p>Summer is just around the corner, and it's time to refresh your wardrobe with the latest trends. This year's summer fashion is all about bold colors, sustainable materials, and comfortable yet stylish pieces that can transition from day to night.</p>
        
        <h2>1. Vibrant Color Blocking</h2>
        <p>Color blocking is making a major comeback this summer. Think bright yellows paired with electric blues, or hot pinks with deep greens. The key is to choose colors that are on opposite sides of the color wheel for maximum impact.</p>
        
        <h2>2. Sustainable Linen</h2>
        <p>As consumers become more environmentally conscious, sustainable fabrics are taking center stage. Linen, with its natural cooling properties, is perfect for hot summer days. Look for oversized linen shirts, wide-leg pants, and breezy dresses in earthy tones.</p>
        
        <h2>3. Statement Sunglasses</h2>
        <p>This summer, eyewear is getting a bold update. Oversized frames, colorful lenses, and unique shapes are all trending. Don't be afraid to make a statement with your sunglasses – they're the perfect accessory to elevate any summer outfit.</p>
        
        <h2>4. Crochet Everything</h2>
        <p>Crochet isn't just for blankets anymore. From tops and dresses to bags and hats, crochet items are everywhere this summer. This handcrafted look adds texture and interest to your summer wardrobe.</p>
        
        <h2>5. Platform Sandals</h2>
        <p>Give your summer style a lift with platform sandals. They're comfortable, versatile, and add height without the discomfort of heels. Look for styles with chunky straps and bold colors to stay on trend.</p>
        
        <h2>6. Cut-Out Details</h2>
        <p>Strategic cut-outs are adding interest to otherwise simple pieces. From dresses with side cut-outs to tops with open backs, this trend allows you to show some skin while still looking sophisticated.</p>
        
        <h2>7. Oversized Shirts</h2>
        <p>The oversized trend continues this summer with billowy shirts that can be worn as cover-ups, tied at the waist, or even as mini dresses. Opt for lightweight fabrics in crisp whites or pastel colors.</p>
        
        <h2>8. Bucket Hats</h2>
        <p>Practical and stylish, bucket hats are having a moment. They protect you from the sun while adding a cool, retro vibe to your outfit. This summer, look for bucket hats in bold prints or bright colors.</p>
        
        <h2>9. Coastal Grandmother Aesthetic</h2>
        <p>Inspired by Nancy Meyers films and coastal living, this trend embraces linen pants, straw hats, and neutral tones. It's all about looking effortlessly chic while staying comfortable.</p>
        
        <h2>10. Sustainable Swimwear</h2>
        <p>Eco-friendly swimwear made from recycled materials is making waves this summer. Look for brands that prioritize sustainability without compromising on style or comfort.</p>
        
        <p>Remember, the best summer fashion is one that makes you feel confident and comfortable. Mix and match these trends to create a summer wardrobe that reflects your personal style while keeping you cool during the hottest months of the year.</p>
      `,
    },
    {
      id: "2",
      title: "How to Choose the Perfect Smartphone in 2025",
      excerpt:
        "With so many options available, finding the right smartphone can be overwhelming. Here's our guide to help you make the best choice.",
      coverImage: "/placeholder.svg?height=600&width=1200",
      date: "March 10, 2025",
      readTime: "8 min read",
      author: "John Doe",
      authorImage: "/placeholder.svg?height=100&width=100",
      category: "Technology",
      slug: "how-to-choose-perfect-smartphone-2025",
      content: `
        <p>Smartphones have become an essential part of our daily lives, and choosing the right one can be a daunting task. With technology evolving rapidly and new models being released every few months, it's important to know what features to prioritize based on your needs.</p>
        
        <h2>Consider Your Budget</h2>
        <p>Before diving into specs and features, establish a clear budget. Smartphones range from budget-friendly options under $300 to premium models exceeding $1,500. Remember that the latest flagship isn't always necessary – mid-range phones have become increasingly capable and offer excellent value.</p>
        
        <h2>Operating System: iOS vs Android</h2>
        <p>The operating system largely determines your smartphone experience. iOS (iPhone) offers a seamless ecosystem if you use other Apple products, consistent updates, and strong security. Android provides more customization options, a wider range of device choices at various price points, and deeper integration with Google services.</p>
        
        <h2>Display Quality</h2>
        <p>In 2025, most smartphones feature high-quality displays, but there are still important differences to consider. Look for OLED or AMOLED screens for better contrast and power efficiency. Higher refresh rates (90Hz, 120Hz, or even 144Hz) provide smoother scrolling and gaming experiences. For outdoor use, prioritize screens with higher brightness levels.</p>
        
        <h2>Camera Capabilities</h2>
        <p>If photography is important to you, pay special attention to camera specifications. However, don't be fooled by megapixel counts alone – sensor size, aperture, and image processing are equally important. Most flagship phones now offer multiple lenses (wide, ultrawide, telephoto) for versatility. Look for optical image stabilization for clearer photos and videos.</p>
        
        <h2>Battery Life</h2>
        <p>Battery capacity (measured in mAh) gives you a rough idea of how long a phone will last, but efficiency matters too. Look for phones with at least 4,000mAh for all-day use. Also consider charging speeds – many phones now offer fast charging that can give you hours of use from just minutes of charging.</p>
        
        <h2>Performance and Storage</h2>
        <p>For smooth performance, look for phones with at least 8GB of RAM in 2025. Storage is another crucial factor – 128GB should be the minimum, with 256GB or 512GB recommended if you take lots of photos or videos. Some Android phones still offer expandable storage via microSD cards, though this feature is becoming less common.</p>
        
        <h2>5G Connectivity</h2>
        <p>By 2025, 5G has become standard, but not all 5G is equal. Premium phones support more 5G bands and faster mmWave technology, while budget options might only support basic sub-6GHz 5G. Check which 5G technologies your carrier supports to ensure compatibility.</p>
        
        <h2>Software Support</h2>
        <p>Consider how long the manufacturer promises to provide software and security updates. Apple typically supports iPhones for 5-7 years, while Android manufacturers vary widely, with Samsung and Google offering the longest support periods (up to 7 years for flagship models as of 2025).</p>
        
        <h2>Additional Features to Consider</h2>
        <p>Depending on your needs, you might want to prioritize water resistance, wireless charging, advanced biometrics (facial recognition or in-display fingerprint sensors), or special features like stylus support or gaming optimizations.</p>
        
        <h2>Try Before You Buy</h2>
        <p>Whenever possible, visit a store to handle phones you're considering. Pay attention to how the phone feels in your hand, the weight, and whether you find the interface intuitive.</p>
        
        <p>Remember that the "perfect" smartphone is different for everyone. By considering these factors and prioritizing features that matter most to you, you'll be able to find a device that meets your needs without overspending on features you'll never use.</p>
      `,
    },
    {
      id: "3",
      title: "Sustainable Shopping: Making Eco-Friendly Choices",
      excerpt: "Learn how your shopping habits can make a positive impact on the environment.",
      coverImage: "/placeholder.svg?height=600&width=1200",
      date: "March 5, 2025",
      readTime: "6 min read",
      author: "Emma Green",
      authorImage: "/placeholder.svg?height=100&width=100",
      category: "Sustainability",
      slug: "sustainable-shopping-eco-friendly-choices",
      content: `
        <p>As consumers become increasingly aware of environmental issues, sustainable shopping has moved from a niche interest to a mainstream concern. Making eco-friendly choices when shopping can significantly reduce your carbon footprint and contribute to a healthier planet. Here's how you can make more sustainable choices in your everyday shopping.</p>
        
        <h2>Understanding Sustainable Shopping</h2>
        <p>Sustainable shopping involves making purchasing decisions that minimize negative environmental impacts while supporting ethical business practices. This includes considering a product's entire lifecycle – from raw material extraction to manufacturing, distribution, use, and disposal.</p>
        
        <h2>Start With the Basics: Reduce, Reuse, Recycle</h2>
        <p>Before making any purchase, ask yourself if you really need the item. The most sustainable product is often the one you don't buy. When you do need to purchase something, consider buying second-hand or borrowing instead. If you must buy new, look for products made from recycled materials and that can be recycled at the end of their life.</p>
        
        <h2>Choose Quality Over Quantity</h2>
        <p>Investing in high-quality items that last longer is more sustainable than repeatedly buying cheap, disposable products. While the upfront cost may be higher, durable goods often save money in the long run and generate less waste.</p>
        
        <h2>Look for Sustainable Materials</h2>
        <p>When shopping for clothing and textiles, look for natural, organic, or recycled materials like organic cotton, hemp, linen, or recycled polyester. For furniture and home goods, consider sustainably sourced wood certified by the Forest Stewardship Council (FSC) or reclaimed materials.</p>
        
        <h2>Check for Certifications</h2>
        <p>Various certifications can help you identify genuinely sustainable products:
          <ul>
            <li>ENERGY STAR for energy-efficient appliances</li>
            <li>USDA Organic for food and textiles</li>
            <li>Fair Trade for ethically produced items</li>
            <li>GOTS (Global Organic Textile Standard) for textiles</li>
            <li>Rainforest Alliance for products from farms that meet environmental and social standards</li>
            <li>B Corp for companies meeting high standards of social and environmental performance</li>
          </ul>
        </p>
        
        <h2>Minimize Packaging Waste</h2>
        <p>Excessive packaging contributes significantly to our waste problem. Choose products with minimal, recyclable, or compostable packaging. Shopping in bulk, using reusable containers, and bringing your own bags can dramatically reduce packaging waste.</p>
        
        <h2>Support Local Businesses</h2>
        <p>Shopping locally reduces transportation emissions and often means less packaging. Local farmers' markets, craft fairs, and independent retailers typically have a smaller carbon footprint than large chains shipping products globally.</p>
        
        <h2>Embrace the Circular Economy</h2>
        <p>The circular economy aims to eliminate waste by keeping products and materials in use. Support brands that offer repair services, take-back programs, or design products for disassembly and recycling. Consider renting or subscribing to services rather than owning products outright.</p>
        
        <h2>Be Wary of Greenwashing</h2>
        <p>As sustainable shopping becomes more popular, some companies make misleading environmental claims. Look beyond marketing buzzwords like "natural" or "eco-friendly" and research a company's actual practices. Transparency about supply chains and manufacturing processes is a good sign.</p>
        
        <h2>Use Technology to Make Better Choices</h2>
        <p>Several apps can help you make more sustainable shopping decisions:
          <ul>
            <li>Good On You rates fashion brands on their ethical practices</li>
            <li>Think Dirty scans product barcodes to reveal potentially harmful ingredients</li>
            <li>HowGood provides sustainability ratings for food products</li>
          </ul>
        </p>
        
        <h2>Start Small and Build Momentum</h2>
        <p>Transitioning to fully sustainable shopping habits takes time. Start with changes that feel manageable, like bringing reusable bags or choosing one product category to focus on. Small, consistent changes add up to significant impact over time.</p>
        
        <p>Remember that no one can be perfectly sustainable all the time. The goal is progress, not perfection. By becoming more mindful about your purchasing decisions, you're contributing to a larger movement toward a more sustainable future.</p>
      `,
    },
  ]

  return blogPosts.find((post) => post.slug === slug)
}

export default function BlogPostPage({ params }) {
  const post = getBlogPostBySlug(params.slug)

  if (!post) {
    notFound()
  }

  return (
    <div className="container px-4 md:px-6 py-12 mx-auto">
      <div className="max-w-3xl mx-auto">
        <div className="mb-8">
          <Button variant="ghost" size="sm" className="mb-4" asChild>
            <Link href="/blog">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Blog
            </Link>
          </Button>

          <Badge className="mb-4">{post.category}</Badge>
          <h1 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl mb-4">{post.title}</h1>

          <div className="flex items-center gap-4 text-sm text-muted-foreground mb-6">
            <div className="flex items-center">
              <Calendar className="mr-1 h-4 w-4" />
              {post.date}
            </div>
            <div className="flex items-center">
              <Clock className="mr-1 h-4 w-4" />
              {post.readTime}
            </div>
          </div>

          <div className="flex items-center gap-3">
            <img
              src={post.authorImage || "/placeholder.svg"}
              alt={post.author}
              className="h-10 w-10 rounded-full object-cover"
            />
            <div>
              <p className="text-sm font-medium">By {post.author}</p>
            </div>
          </div>
        </div>

        <div className="mb-8 aspect-video overflow-hidden rounded-lg">
          <img src={post.coverImage || "/placeholder.svg"} alt={post.title} className="h-full w-full object-cover" />
        </div>

        <div
          className="prose prose-lg dark:prose-invert max-w-none mb-12"
          dangerouslySetInnerHTML={{ __html: post.content }}
        />

        <Separator className="my-8" />

        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h3 className="text-lg font-medium mb-2">Share this article</h3>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="icon">
                <Facebook className="h-4 w-4" />
                <span className="sr-only">Share on Facebook</span>
              </Button>
              <Button variant="outline" size="icon">
                <Twitter className="h-4 w-4" />
                <span className="sr-only">Share on Twitter</span>
              </Button>
              <Button variant="outline" size="icon">
                <Linkedin className="h-4 w-4" />
                <span className="sr-only">Share on LinkedIn</span>
              </Button>
              <Button variant="outline" size="icon">
                <Share2 className="h-4 w-4" />
                <span className="sr-only">Copy link</span>
              </Button>
            </div>
          </div>

          <div>
            <Button asChild>
              <Link href="/blog">Read More Articles</Link>
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}

