"use client"

import { useState, useEffect, useRef } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { useAuth } from "@/components/auth-provider"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { getOrderById } from "@/lib/firebase/orders"
import { CheckCircle, ShoppingBag, Truck, Clock, AlertCircle, Home } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

export default function OrderConfirmationPage() {
  const { user, loading: authLoading } = useAuth()
  const router = useRouter()
  const searchParams = useSearchParams()
  const orderId = searchParams.get("orderId")
  const [order, setOrder] = useState(null)
  const [loading, setLoading] = useState(true)
  const isMounted = useRef(true)

  useEffect(() => {
    return () => {
      isMounted.current = false
    }
  }, [])

  useEffect(() => {
    if (!authLoading) {
      if (!user) {
        router.push("/login")
        return
      }

      if (!orderId) {
        router.push("/")
        return
      }

      fetchOrder()
    }
  }, [user, authLoading, router, orderId])

  const fetchOrder = async () => {
    try {
      setLoading(true)
      const orderData = await getOrderById(orderId)

      if (orderData && isMounted.current) {
        // Verify this order belongs to the current user
        if (orderData.userId !== user.uid) {
          router.push("/")
          return
        }

        setOrder(orderData)
      } else if (isMounted.current) {
        router.push("/")
      }
    } catch (error) {
      console.error("Error fetching order:", error)
      if (isMounted.current) {
        router.push("/")
      }
    } finally {
      if (isMounted.current) {
        setLoading(false)
      }
    }
  }

  if (authLoading || loading) {
    return (
      <div className="container max-w-4xl mx-auto px-4 py-12">
        <div className="flex items-center justify-center h-[60vh]">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
        </div>
      </div>
    )
  }

  if (!order) {
    return (
      <div className="container max-w-4xl mx-auto px-4 py-12">
        <div className="text-center py-12">
          <AlertCircle className="h-12 w-12 text-red-500 mx-auto mb-4" />
          <h1 className="text-2xl font-bold mb-2">Order Not Found</h1>
          <p className="text-muted-foreground mb-6">We couldn't find the order you're looking for.</p>
          <Button asChild>
            <Link href="/">Return to Home</Link>
          </Button>
        </div>
      </div>
    )
  }

  const getEstimatedDelivery = () => {
    const deliveryMethod = order.shipping.method
    const createdDate = new Date(order.createdAt.toDate())

    let minDays, maxDays
    if (deliveryMethod === "express") {
      minDays = 1
      maxDays = 2
    } else {
      minDays = 3
      maxDays = 5
    }

    const minDeliveryDate = new Date(createdDate)
    minDeliveryDate.setDate(minDeliveryDate.getDate() + minDays)

    const maxDeliveryDate = new Date(createdDate)
    maxDeliveryDate.setDate(maxDeliveryDate.getDate() + maxDays)

    const formatDate = (date) => {
      return date.toLocaleDateString("en-US", {
        weekday: "short",
        month: "short",
        day: "numeric",
      })
    }

    return `${formatDate(minDeliveryDate)} - ${formatDate(maxDeliveryDate)}`
  }

  return (
    <div className="container max-w-4xl mx-auto px-4 py-12">
      <div className="text-center mb-8">
        <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
        <h1 className="text-3xl font-bold mb-2">Order Confirmed!</h1>
        <p className="text-muted-foreground">
          Thank you for your purchase. Your order has been received and is being processed.
        </p>
      </div>

      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Order #{order.orderNumber}</CardTitle>
          <CardDescription>Placed on {new Date(order.createdAt.toDate()).toLocaleString()}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <Clock className="h-5 w-5 text-muted-foreground" />
              <div>
                <p className="font-medium">Order Status</p>
                <p className="text-sm text-muted-foreground capitalize">{order.status}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Truck className="h-5 w-5 text-muted-foreground" />
              <div>
                <p className="font-medium">Estimated Delivery</p>
                <p className="text-sm text-muted-foreground">{getEstimatedDelivery()}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <ShoppingBag className="h-5 w-5 text-muted-foreground" />
              <div>
                <p className="font-medium">Order Total</p>
                <p className="text-sm text-muted-foreground">SZL {order.total.toFixed(2)}</p>
              </div>
            </div>
          </div>

          <Separator />

          <div>
            <h3 className="font-medium mb-3">Order Items</h3>
            <div className="space-y-3">
              {order.items.map((item) => (
                <div key={item.id} className="flex items-center gap-3">
                  <div className="relative h-16 w-16 rounded-md overflow-hidden flex-shrink-0">
                    <Image
                      src={item.images?.[0] || "/placeholder.svg?height=64&width=64"}
                      alt={item.name}
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div className="flex-grow">
                    <Link href={`/products/${item.id}`} className="font-medium hover:underline">
                      {item.name}
                    </Link>
                    <p className="text-sm text-muted-foreground">
                      Qty: {item.quantity} × SZL {(item.salePrice || item.price).toFixed(2)}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="font-medium">SZL {((item.salePrice || item.price) * item.quantity).toFixed(2)}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <Separator />

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-medium mb-3">Shipping Information</h3>
              <div className="space-y-1 text-sm">
                <p className="font-medium">{order.shipping.fullName}</p>
                <p>{order.shipping.address}</p>
                <p>
                  {order.shipping.city}, {order.shipping.region} {order.shipping.postalCode}
                </p>
                <p>{order.shipping.phone}</p>
                <p>{order.shipping.email}</p>
              </div>
            </div>
            <div>
              <h3 className="font-medium mb-3">Payment Information</h3>
              <div className="space-y-1 text-sm">
                <p>
                  <span className="font-medium">Method: </span>
                  <span className="capitalize">{order.payment.method.replace(/([A-Z])/g, " $1").trim()}</span>
                </p>
                <p>
                  <span className="font-medium">Status: </span>
                  <span className="capitalize">{order.payment.status}</span>
                </p>
              </div>

              <div className="mt-4 space-y-1">
                <div className="flex justify-between">
                  <span>Subtotal:</span>
                  <span>SZL {order.subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Shipping:</span>
                  <span>SZL {order.shippingCost.toFixed(2)}</span>
                </div>
                <Separator className="my-2" />
                <div className="flex justify-between font-medium">
                  <span>Total:</span>
                  <span>SZL {order.total.toFixed(2)}</span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex flex-col sm:flex-row gap-3 justify-between">
          <Button variant="outline" asChild>
            <Link href="/dashboard/orders">
              <ShoppingBag className="mr-2 h-4 w-4" />
              View All Orders
            </Link>
          </Button>
          <Button asChild>
            <Link href="/">
              <Home className="mr-2 h-4 w-4" />
              Continue Shopping
            </Link>
          </Button>
        </CardFooter>
      </Card>

      <div className="text-center">
        <p className="text-muted-foreground mb-2">Have questions about your order?</p>
        <Button variant="link" asChild>
          <Link href="/contact">Contact Customer Support</Link>
        </Button>
      </div>
    </div>
  )
}

