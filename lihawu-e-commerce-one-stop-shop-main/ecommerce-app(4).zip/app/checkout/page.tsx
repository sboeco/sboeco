"use client"

import { useState, useEffect, useRef } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/components/auth-provider"
import { useCart } from "@/hooks/use-cart"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { useToast } from "@/components/ui/use-toast"
import { createOrder } from "@/lib/firebase/orders"
import { doc, getDoc } from "firebase/firestore"
import { db } from "@/lib/firebase"
import { ArrowLeft, CreditCard, Truck, AlertCircle } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

export default function CheckoutPage() {
  const { user, loading: authLoading } = useAuth()
  const { items: cart, cartTotal, clearCart } = useCart()
  const router = useRouter()
  const { toast } = useToast()
  const isMounted = useRef(true)

  const [isSubmitting, setIsSubmitting] = useState(false)
  const [userData, setUserData] = useState({
    fullName: "",
    email: "",
    phone: "",
    address: "",
    city: "",
    region: "",
    postalCode: "",
  })
  const [paymentMethod, setPaymentMethod] = useState("card")
  const [deliveryMethod, setDeliveryMethod] = useState("standard")
  const [notes, setNotes] = useState("")
  const [errors, setErrors] = useState({})
  const [imageErrors, setImageErrors] = useState({})

  useEffect(() => {
    return () => {
      isMounted.current = false
    }
  }, [])

  useEffect(() => {
    if (!authLoading) {
      if (!user) {
        router.push("/login?redirect=checkout")
        return
      }

      // Check if cart exists and has items
      if (!cart || cart.length === 0) {
        router.push("/cart")
        return
      }

      // Fetch user data from Firestore
      const fetchUserData = async () => {
        try {
          const userDoc = await getDoc(doc(db, "users", user.uid))
          if (userDoc.exists() && isMounted.current) {
            const data = userDoc.data()
            setUserData({
              fullName: user.displayName || "",
              email: user.email || "",
              phone: data.phoneNumber || "",
              address: data.address || "",
              city: data.city || "",
              region: data.region || "",
              postalCode: data.postalCode || "",
            })
          }
        } catch (error) {
          console.error("Error fetching user data:", error)
        }
      }

      fetchUserData()
    }
  }, [user, authLoading, router, cart])

  const handleInputChange = (e) => {
    const { name, value } = e.target
    setUserData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const validateForm = () => {
    const newErrors = {}

    if (!userData.fullName) newErrors.fullName = "Full name is required"
    if (!userData.email) newErrors.email = "Email is required"
    if (!userData.phone) newErrors.phone = "Phone number is required"
    if (!userData.address) newErrors.address = "Address is required"
    if (!userData.city) newErrors.city = "City is required"
    if (!userData.region) newErrors.region = "Region is required"

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = async (e) => {
    e.preventDefault()

    if (!validateForm()) {
      toast({
        title: "Error",
        description: "Please fill in all required fields",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    try {
      // Calculate totals
      const subtotal = cartTotal || 0
      const shippingCost = deliveryMethod === "express" ? 100 : 50
      const total = subtotal + shippingCost

      // Create order object
      const orderData = {
        userId: user.uid,
        userEmail: user.email,
        customerName: userData.fullName,
        customerEmail: userData.email,
        items: cart || [],
        shipping: {
          fullName: userData.fullName,
          email: userData.email,
          phone: userData.phone,
          address: userData.address,
          city: userData.city,
          region: userData.region,
          postalCode: userData.postalCode,
          method: deliveryMethod,
        },
        payment: {
          method: paymentMethod,
          status: "pending",
        },
        notes: notes,
        subtotal,
        shippingCost,
        total,
        status: "processing",
        createdAt: new Date().toISOString(),
        orderNumber: `ORD-${Date.now().toString().slice(-6)}`,
      }

      // Create order in Firestore
      const order = await createOrder(orderData)

      if (isMounted.current) {
        // Clear cart
        clearCart()

        // Redirect to confirmation page
        router.push(`/checkout/confirmation?orderId=${order.id}`)
      }
    } catch (error) {
      console.error("Error creating order:", error)
      if (isMounted.current) {
        toast({
          title: "Error",
          description: "There was a problem processing your order. Please try again.",
          variant: "destructive",
        })
        setIsSubmitting(false)
      }
    }
  }

  const handleImageError = (itemId) => {
    setImageErrors((prev) => ({
      ...prev,
      [itemId]: true,
    }))
  }

  // Calculate totals
  const subtotal = cartTotal || 0
  const shippingCost = deliveryMethod === "express" ? 100 : 50
  const total = subtotal + shippingCost

  if (authLoading) {
    return (
      <div className="container max-w-6xl mx-auto px-4 py-12">
        <div className="flex items-center justify-center h-[60vh]">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
        </div>
      </div>
    )
  }

  return (
    <div className="container max-w-6xl mx-auto px-4 py-12">
      <div className="mb-8">
        <Button variant="ghost" asChild className="mb-4">
          <Link href="/cart">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Cart
          </Link>
        </Button>
        <h1 className="text-3xl font-bold">Checkout</h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <form onSubmit={handleSubmit}>
            <Card className="mb-8">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Truck className="mr-2 h-5 w-5" />
                  Shipping Information
                </CardTitle>
                <CardDescription>Enter your shipping details</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="fullName">
                      Full Name <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="fullName"
                      name="fullName"
                      value={userData.fullName}
                      onChange={handleInputChange}
                      className={errors.fullName ? "border-red-500" : ""}
                    />
                    {errors.fullName && <p className="text-red-500 text-xs">{errors.fullName}</p>}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">
                      Email <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      value={userData.email}
                      onChange={handleInputChange}
                      className={errors.email ? "border-red-500" : ""}
                    />
                    {errors.email && <p className="text-red-500 text-xs">{errors.email}</p>}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone">
                      Phone Number <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="phone"
                      name="phone"
                      value={userData.phone}
                      onChange={handleInputChange}
                      className={errors.phone ? "border-red-500" : ""}
                    />
                    {errors.phone && <p className="text-red-500 text-xs">{errors.phone}</p>}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="region">
                      Region <span className="text-red-500">*</span>
                    </Label>
                    <Select
                      value={userData.region}
                      onValueChange={(value) => setUserData((prev) => ({ ...prev, region: value }))}
                    >
                      <SelectTrigger id="region" className={errors.region ? "border-red-500" : ""}>
                        <SelectValue placeholder="Select your region" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Hhohho">Hhohho</SelectItem>
                        <SelectItem value="Manzini">Manzini</SelectItem>
                        <SelectItem value="Lubombo">Lubombo</SelectItem>
                        <SelectItem value="Shiselweni">Shiselweni</SelectItem>
                      </SelectContent>
                    </Select>
                    {errors.region && <p className="text-red-500 text-xs">{errors.region}</p>}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="city">
                      City/Town <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="city"
                      name="city"
                      value={userData.city}
                      onChange={handleInputChange}
                      className={errors.city ? "border-red-500" : ""}
                    />
                    {errors.city && <p className="text-red-500 text-xs">{errors.city}</p>}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="address">
                      Address <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="address"
                      name="address"
                      value={userData.address}
                      onChange={handleInputChange}
                      className={errors.address ? "border-red-500" : ""}
                    />
                    {errors.address && <p className="text-red-500 text-xs">{errors.address}</p>}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="postalCode">Postal Code</Label>
                    <Input id="postalCode" name="postalCode" value={userData.postalCode} onChange={handleInputChange} />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="notes">Order Notes (Optional)</Label>
                  <Textarea
                    id="notes"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="Special instructions for delivery or order"
                    className="min-h-[100px]"
                  />
                </div>
              </CardContent>
            </Card>

            <Card className="mb-8">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Truck className="mr-2 h-5 w-5" />
                  Delivery Method
                </CardTitle>
                <CardDescription>Select your preferred delivery option</CardDescription>
              </CardHeader>
              <CardContent>
                <RadioGroup value={deliveryMethod} onValueChange={setDeliveryMethod} className="space-y-3">
                  <div className="flex items-center space-x-2 rounded-md border p-4">
                    <RadioGroupItem value="standard" id="standard" />
                    <Label htmlFor="standard" className="flex flex-col cursor-pointer">
                      <span className="font-medium">Standard Delivery</span>
                      <span className="text-sm text-muted-foreground">3-5 business days</span>
                    </Label>
                    <div className="ml-auto font-medium">SZL 50.00</div>
                  </div>
                  <div className="flex items-center space-x-2 rounded-md border p-4">
                    <RadioGroupItem value="express" id="express" />
                    <Label htmlFor="express" className="flex flex-col cursor-pointer">
                      <span className="font-medium">Express Delivery</span>
                      <span className="text-sm text-muted-foreground">1-2 business days</span>
                    </Label>
                    <div className="ml-auto font-medium">SZL 100.00</div>
                  </div>
                </RadioGroup>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <CreditCard className="mr-2 h-5 w-5" />
                  Payment Method
                </CardTitle>
                <CardDescription>Select your preferred payment method</CardDescription>
              </CardHeader>
              <CardContent>
                <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod} className="space-y-3">
                  <div className="flex items-center space-x-2 rounded-md border p-4">
                    <RadioGroupItem value="card" id="card" />
                    <Label htmlFor="card" className="flex flex-col cursor-pointer">
                      <span className="font-medium">Credit/Debit Card</span>
                      <span className="text-sm text-muted-foreground">Pay securely with your card</span>
                    </Label>
                    <div className="ml-auto">
                      <Image src="/placeholder.svg?height=30&width=80" alt="Credit card logos" width={80} height={30} />
                    </div>
                  </div>
                  <div className="flex items-center space-x-2 rounded-md border p-4">
                    <RadioGroupItem value="mobileMoney" id="mobileMoney" />
                    <Label htmlFor="mobileMoney" className="flex flex-col cursor-pointer">
                      <span className="font-medium">Mobile Money</span>
                      <span className="text-sm text-muted-foreground">Pay with MTN or Eswatini Mobile</span>
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2 rounded-md border p-4">
                    <RadioGroupItem value="cashOnDelivery" id="cashOnDelivery" />
                    <Label htmlFor="cashOnDelivery" className="flex flex-col cursor-pointer">
                      <span className="font-medium">Cash on Delivery</span>
                      <span className="text-sm text-muted-foreground">Pay when you receive your order</span>
                    </Label>
                  </div>
                </RadioGroup>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button variant="outline" asChild>
                  <Link href="/cart">
                    <ArrowLeft className="mr-2 h-4 w-4" />
                    Back to Cart
                  </Link>
                </Button>
                <Button type="submit" disabled={isSubmitting}>
                  {isSubmitting ? "Processing..." : "Place Order"}
                </Button>
              </CardFooter>
            </Card>
          </form>
        </div>

        <div>
          <Card className="sticky top-4">
            <CardHeader>
              <CardTitle>Order Summary</CardTitle>
              <CardDescription>
                {cart && cart.length
                  ? `${cart.length} ${cart.length === 1 ? "item" : "items"} in your cart`
                  : "Your cart is empty"}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {cart && cart.length > 0 ? (
                <>
                  <div className="max-h-[300px] overflow-y-auto space-y-3 pr-2">
                    {cart.map((item) => (
                      <div key={item.id} className="flex items-center gap-3">
                        <div className="relative h-16 w-16 rounded-md overflow-hidden flex-shrink-0">
                          <Image
                            src={
                              imageErrors[item.id] || !item.images?.[0]
                                ? "/placeholder.svg?height=64&width=64"
                                : item.images[0]
                            }
                            alt={item.name || "Product"}
                            fill
                            className="object-cover"
                            onError={() => handleImageError(item.id)}
                          />
                        </div>
                        <div className="flex-grow">
                          <p className="font-medium text-sm">{item.name || "Unnamed Product"}</p>
                          <p className="text-xs text-muted-foreground">Qty: {item.quantity || 1}</p>
                        </div>
                        <div className="text-right">
                          <p className="font-medium">
                            SZL {((item.salePrice || item.price || 0) * (item.quantity || 1)).toFixed(2)}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>

                  <Separator />

                  <div className="space-y-1.5">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Subtotal</span>
                      <span>SZL {subtotal.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Shipping</span>
                      <span>SZL {shippingCost.toFixed(2)}</span>
                    </div>
                    <Separator className="my-2" />
                    <div className="flex justify-between font-medium text-lg">
                      <span>Total</span>
                      <span>SZL {total.toFixed(2)}</span>
                    </div>
                  </div>

                  <div className="rounded-md bg-muted p-4 text-sm">
                    <div className="flex items-center gap-2">
                      <AlertCircle className="h-4 w-4 text-muted-foreground" />
                      <p>Your personal data will be used to process your order and support your experience.</p>
                    </div>
                  </div>
                </>
              ) : (
                <div className="text-center py-6">
                  <p className="text-muted-foreground mb-4">Your cart is empty</p>
                  <Button asChild>
                    <Link href="/shop">Continue Shopping</Link>
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

