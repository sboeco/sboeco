import { CartPage } from "@/components/cart-page"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Shopping Cart | EcoShop",
  description: "View and manage your shopping cart",
}

export default function Cart() {
  return <CartPage />
}

