"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/components/ui/use-toast"
import { useCart } from "@/hooks/use-cart"
import { useWishlist } from "@/hooks/use-wishlist"
import { getProductById } from "@/lib/firebase/products"
import { Heart, ShoppingCart, Share2, ArrowLeft, Minus, Plus, Check, Star } from "lucide-react"
import { ProductReviews } from "@/components/product-reviews"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { ShareProduct } from "@/components/share-product"

export default function ProductDetailPage() {
  const params = useParams()
  const productId = params.id as string
  const [product, setProduct] = useState(null)
  const [loading, setLoading] = useState(true)
  const [quantity, setQuantity] = useState(1)
  const [activeImage, setActiveImage] = useState(0)
  const [addingToCart, setAddingToCart] = useState(false)
  const [shareDialogOpen, setShareDialogOpen] = useState(false)
  const { toast } = useToast()
  const { addToCart } = useCart()
  const { addToWishlist, isInWishlist } = useWishlist()

  useEffect(() => {
    const fetchProduct = async () => {
      try {
        const productData = await getProductById(productId)
        setProduct(productData)
      } catch (error) {
        console.error("Error fetching product:", error)
        toast({
          title: "Error",
          description: "Failed to load product details. Please try again.",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    }

    if (productId) {
      fetchProduct()
    }
  }, [productId, toast])

  const productInWishlist = productId ? isInWishlist(productId) : false

  const handleQuantityChange = (value) => {
    if (value < 1) return
    if (product && product.stock && value > product.stock) return
    setQuantity(value)
  }

  const handleAddToCart = () => {
    if (!product) return

    setAddingToCart(true)
    setTimeout(() => {
      addToCart(product, quantity)
      toast({
        title: "Added to cart",
        description: `${product.name} has been added to your cart.`,
      })
      setAddingToCart(false)
    }, 500)
  }

  const handleAddToWishlist = () => {
    if (!product) return

    addToWishlist(product)
    toast({
      title: productInWishlist ? "Already in wishlist" : "Added to wishlist",
      description: productInWishlist
        ? `${product.name} is already in your wishlist.`
        : `${product.name} has been added to your wishlist.`,
    })
  }

  const isOutOfStock = product?.stock === 0
  const isLowStock = product?.stock > 0 && product?.stock <= 5
  const isOnSale = product?.salePrice && Number(product?.salePrice) < Number(product?.price)

  return (
    <div className="container px-4 md:px-6 py-8 mx-auto">
      <Button variant="ghost" size="sm" className="mb-6" asChild>
        <Link href="/shop">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Shop
        </Link>
      </Button>

      {loading ? (
        <div className="grid gap-8 md:grid-cols-2">
          <div className="space-y-4">
            <Skeleton className="h-[400px] w-full rounded-lg" />
            <div className="grid grid-cols-4 gap-2">
              {Array.from({ length: 4 }).map((_, i) => (
                <Skeleton key={i} className="aspect-square rounded-md" />
              ))}
            </div>
          </div>
          <div className="space-y-6">
            <div className="space-y-2">
              <Skeleton className="h-8 w-3/4" />
              <Skeleton className="h-6 w-1/4" />
            </div>
            <Skeleton className="h-6 w-1/3" />
            <Skeleton className="h-24 w-full" />
            <div className="space-y-2">
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-10 w-full" />
            </div>
          </div>
        </div>
      ) : product ? (
        <div className="grid gap-6 md:gap-8 md:grid-cols-2">
          {/* Product Images */}
          <div className="space-y-4">
            <div className="relative aspect-square overflow-hidden rounded-lg border bg-muted">
              <img
                src={
                  product.images && product.images.length > 0
                    ? product.images[activeImage]
                    : "/placeholder.svg?height=600&width=600"
                }
                alt={product.name}
                className="h-full w-full object-cover"
              />
              {isOnSale && (
                <Badge variant="destructive" className="absolute top-4 left-4">
                  {Math.round(((Number(product.price) - Number(product.salePrice)) / Number(product.price)) * 100)}% Off
                </Badge>
              )}
            </div>
            {product.images && product.images.length > 1 && (
              <div className="grid grid-cols-5 sm:grid-cols-4 gap-2">
                {product.images.map((image, index) => (
                  <button
                    key={index}
                    className={`relative aspect-square rounded-md overflow-hidden border-2 ${
                      activeImage === index ? "border-primary" : "border-muted"
                    }`}
                    onClick={() => setActiveImage(index)}
                  >
                    <img
                      src={image || "/placeholder.svg"}
                      alt={`${product.name} - view ${index + 1}`}
                      className="h-full w-full object-cover"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Product Details */}
          <div className="flex flex-col space-y-4 md:space-y-6">
            <div>
              <h1 className="text-3xl font-bold">{product.name}</h1>
              <div className="mt-2 flex items-center gap-4">
                {product.rating && (
                  <div className="flex items-center">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star
                        key={i}
                        className={`h-4 w-4 ${
                          i < Math.floor(product.rating) ? "text-yellow-500 fill-yellow-500" : "text-muted-foreground"
                        }`}
                      />
                    ))}
                    <span className="ml-2 text-sm text-muted-foreground">{product.rating.toFixed(1)}</span>
                  </div>
                )}
                {product.category && (
                  <Badge variant="outline" className="capitalize">
                    {product.category}
                  </Badge>
                )}
              </div>
            </div>

            <div className="flex items-center gap-2">
              {isOnSale ? (
                <>
                  <span className="text-3xl font-bold">SZL {Number(product.salePrice).toFixed(2)}</span>
                  <span className="text-lg text-muted-foreground line-through">
                    SZL {Number(product.price).toFixed(2)}
                  </span>
                </>
              ) : (
                <span className="text-3xl font-bold">SZL {Number(product.price).toFixed(2)}</span>
              )}
            </div>

            <div>
              <p className="text-muted-foreground">{product.description}</p>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-medium">Availability:</span>
                {isOutOfStock ? (
                  <span className="text-red-500">Out of Stock</span>
                ) : isLowStock ? (
                  <span className="text-yellow-500">Low Stock - Only {product.stock} left</span>
                ) : (
                  <span className="text-green-500 flex items-center">
                    <Check className="mr-1 h-4 w-4" /> In Stock
                  </span>
                )}
              </div>
              {!isOutOfStock && (
                <div className="flex flex-col sm:flex-row items-center gap-4">
                  <span className="font-medium">Quantity:</span>
                  <div className="flex items-center border rounded-md w-full sm:w-auto">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 rounded-none"
                      onClick={() => handleQuantityChange(quantity - 1)}
                      disabled={quantity <= 1}
                    >
                      <Minus size={14} />
                      <span className="sr-only">Decrease quantity</span>
                    </Button>
                    <span className="w-10 text-center">{quantity}</span>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 rounded-none"
                      onClick={() => handleQuantityChange(quantity + 1)}
                      disabled={product.stock && quantity >= product.stock}
                    >
                      <Plus size={14} />
                      <span className="sr-only">Increase quantity</span>
                    </Button>
                  </div>
                </div>
              )}
            </div>

            <div className="flex flex-col sm:flex-row gap-3">
              <Button className="flex-1" size="lg" disabled={isOutOfStock || addingToCart} onClick={handleAddToCart}>
                {addingToCart ? (
                  "Adding..."
                ) : isOutOfStock ? (
                  "Out of Stock"
                ) : (
                  <>
                    Add to Cart
                    <ShoppingCart className="ml-2 h-5 w-5" />
                  </>
                )}
              </Button>
              <Button
                variant="outline"
                size="lg"
                className={productInWishlist ? "text-red-500" : ""}
                onClick={handleAddToWishlist}
              >
                <Heart className={`mr-2 h-5 w-5 ${productInWishlist ? "fill-red-500 text-red-500" : ""}`} />
                {productInWishlist ? "In Wishlist" : "Add to Wishlist"}
              </Button>
            </div>

            <div className="flex items-center justify-between border-t border-b py-4">
              <span className="font-medium">Share this product:</span>
              <div className="flex items-center gap-2">
                <Dialog open={shareDialogOpen} onOpenChange={setShareDialogOpen}>
                  <DialogTrigger asChild>
                    <Button variant="ghost" size="icon">
                      <Share2 className="h-4 w-4" />
                      <span className="sr-only">Share</span>
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Share this product</DialogTitle>
                      <DialogDescription>Share this product with your friends and family</DialogDescription>
                    </DialogHeader>
                    <ShareProduct product={product} />
                  </DialogContent>
                </Dialog>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="text-center py-12 border rounded-lg bg-muted/30">
          <h2 className="text-2xl font-bold mb-2">Product Not Found</h2>
          <p className="text-muted-foreground mb-6">
            The product you're looking for doesn't exist or has been removed.
          </p>
          <Button asChild>
            <Link href="/shop">Continue Shopping</Link>
          </Button>
        </div>
      )}

      {product && (
        <div className="mt-12">
          <Tabs defaultValue="description" className="w-full">
            <TabsList className="w-full grid grid-cols-3 mb-8">
              <TabsTrigger value="description">Description</TabsTrigger>
              <TabsTrigger value="specifications">Specifications</TabsTrigger>
              <TabsTrigger value="reviews">Reviews</TabsTrigger>
            </TabsList>
            <TabsContent value="description" className="space-y-4">
              <div className="prose max-w-none dark:prose-invert">
                <h3 className="text-xl font-bold">Product Description</h3>
                <p>{product.description}</p>
                {product.longDescription && <div dangerouslySetInnerHTML={{ __html: product.longDescription }} />}
              </div>
            </TabsContent>
            <TabsContent value="specifications" className="space-y-4">
              <h3 className="text-xl font-bold">Product Specifications</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <div className="flex justify-between py-2 border-b">
                    <span className="font-medium">Brand</span>
                    <span>{product.brand || "N/A"}</span>
                  </div>
                  <div className="flex justify-between py-2 border-b">
                    <span className="font-medium">Model</span>
                    <span>{product.model || "N/A"}</span>
                  </div>
                  <div className="flex justify-between py-2 border-b">
                    <span className="font-medium">SKU</span>
                    <span>{product.sku || product.id.slice(0, 8)}</span>
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between py-2 border-b">
                    <span className="font-medium">Weight</span>
                    <span>{product.weight ? `${product.weight} kg` : "N/A"}</span>
                  </div>
                  <div className="flex justify-between py-2 border-b">
                    <span className="font-medium">Dimensions</span>
                    <span>{product.dimensions || "N/A"}</span>
                  </div>
                  <div className="flex justify-between py-2 border-b">
                    <span className="font-medium">Warranty</span>
                    <span>{product.warranty || "Standard Warranty"}</span>
                  </div>
                </div>
              </div>
            </TabsContent>
            <TabsContent value="reviews" className="space-y-4">
              <ProductReviews productId={product.id} productName={product.name} />
            </TabsContent>
          </Tabs>
        </div>
      )}
    </div>
  )
}

