import { HeroSection } from "@/components/hero-section"
import { FeaturedProducts } from "@/components/featured-products"
import { TrendingProducts } from "@/components/trending-products"
import { Testimonials } from "@/components/testimonials"
import { Newsletter } from "@/components/newsletter"
import { FeaturedCategories } from "@/components/featured-categories"
import { ShopCTA } from "@/components/shop-cta"

export default function HomePage() {
  return (
    <main className="flex-1">
      <HeroSection />
      <div className="container px-4 md:px-6 py-8 mx-auto">
        <FeaturedCategories />
        <FeaturedProducts />
        <TrendingProducts />
        <ShopCTA />
        <Testimonials />
        <Newsletter />
      </div>
    </main>
  )
}

