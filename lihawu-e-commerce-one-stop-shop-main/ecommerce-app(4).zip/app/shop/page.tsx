import { Suspense } from "react"
import { ShopPage } from "@/components/shop-page"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Shop | EcoShop",
  description: "Browse our complete collection of products",
}

export default function Shop() {
  return (
    <Suspense fallback={<ShopPageSkeleton />}>
      <ShopPage />
    </Suspense>
  )
}

function ShopPageSkeleton() {
  return (
    <div className="container px-4 py-8 mx-auto">
      <div className="flex flex-col md:flex-row justify-between items-center mb-8 gap-4">
        <div className="h-10 w-48 bg-muted rounded-md animate-pulse" />
        <div className="flex items-center gap-4 w-full md:w-auto">
          <div className="h-10 w-64 bg-muted rounded-md animate-pulse" />
          <div className="h-10 w-40 bg-muted rounded-md animate-pulse" />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
        <div className="hidden md:block h-96 bg-muted rounded-md animate-pulse" />

        <div className="md:col-span-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {Array.from({ length: 6 }).map((_, index) => (
              <div key={index} className="rounded-lg overflow-hidden">
                <div className="aspect-square bg-muted animate-pulse" />
                <div className="p-4 space-y-2">
                  <div className="h-4 bg-muted rounded animate-pulse" />
                  <div className="h-4 bg-muted rounded w-2/3 animate-pulse" />
                  <div className="h-6 bg-muted rounded w-1/3 animate-pulse mt-4" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

