"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useWishlist } from "@/hooks/use-wishlist"
import { useCart } from "@/hooks/use-cart"
import { Button } from "@/components/ui/button"
import { useToast } from "@/components/ui/use-toast"
import { ShoppingCart, Trash2, ArrowRight } from "lucide-react"

export function WishlistPage() {
  const { wishlist, removeFromWishlist, clearWishlist, addToWishlist } = useWishlist()
  const { addItem } = useCart()
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(false)
  const [mounted, setMounted] = useState(false)

  // Handle client-side only rendering
  useEffect(() => {
    setMounted(true)
  }, [])

  // If not mounted yet (server-side), show empty state
  if (!mounted) {
    return (
      <div className="container px-4 md:px-6 py-8 mx-auto">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">My Wishlist</h1>
            <p className="text-muted-foreground">Items you've saved for later</p>
          </div>
        </div>
        <div className="text-center py-16 border rounded-lg bg-muted/30">
          <h3 className="text-lg font-medium mb-2">Loading your wishlist...</h3>
          <p className="text-muted-foreground mb-6">Please wait while we retrieve your saved items</p>
        </div>
      </div>
    )
  }

  const handleAddToCart = (product) => {
    addItem(product)
    toast({
      title: "Added to cart",
      description: `${product.name} has been added to your cart.`,
    })
  }

  const handleRemoveFromWishlist = (id, name) => {
    removeFromWishlist(id)
    toast({
      title: "Removed from wishlist",
      description: `${name} has been removed from your wishlist.`,
    })
  }

  const handleClearWishlist = () => {
    setIsLoading(true)
    setTimeout(() => {
      clearWishlist()
      toast({
        title: "Wishlist cleared",
        description: "All items have been removed from your wishlist.",
      })
      setIsLoading(false)
    }, 500)
  }

  // Ensure wishlist is an array
  const items = Array.isArray(wishlist) ? wishlist : []

  return (
    <div className="container px-4 md:px-6 py-8 mx-auto">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">My Wishlist</h1>
          <p className="text-muted-foreground">Items you've saved for later</p>
        </div>
        {items.length > 0 && (
          <Button variant="outline" className="mt-4 md:mt-0" onClick={handleClearWishlist} disabled={isLoading}>
            {isLoading ? "Clearing..." : "Clear Wishlist"}
          </Button>
        )}
      </div>

      {items.length > 0 ? (
        <div className="space-y-6">
          {items.map((item) => (
            <div key={item.id} className="flex flex-col sm:flex-row border rounded-lg overflow-hidden">
              <div className="w-full sm:w-48 h-48">
                <img
                  src={item.images && item.images.length > 0 ? item.images[0] : "/placeholder.svg?height=200&width=200"}
                  alt={item.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="flex-1 p-6 flex flex-col">
                <div className="flex-1">
                  <h3 className="font-medium text-lg mb-2">{item.name}</h3>
                  <p className="text-muted-foreground text-sm line-clamp-2 mb-4">{item.description}</p>
                  <div className="flex items-center gap-2 mb-4">
                    {item.salePrice ? (
                      <>
                        <span className="font-semibold">
                          SZL{" "}
                          {typeof item.salePrice === "number"
                            ? item.salePrice.toFixed(2)
                            : Number(item.salePrice).toFixed(2)}
                        </span>
                        <span className="text-sm text-muted-foreground line-through">
                          SZL {typeof item.price === "number" ? item.price.toFixed(2) : Number(item.price).toFixed(2)}
                        </span>
                        <span className="text-xs bg-red-100 text-red-800 px-2 py-0.5 rounded-full">
                          {Math.round(((Number(item.price) - Number(item.salePrice)) / Number(item.price)) * 100)}% Off
                        </span>
                      </>
                    ) : (
                      <span className="font-semibold">
                        SZL {typeof item.price === "number" ? item.price.toFixed(2) : Number(item.price).toFixed(2)}
                      </span>
                    )}
                  </div>
                </div>
                <div className="flex flex-col sm:flex-row gap-3">
                  <Button
                    variant="default"
                    className="sm:flex-1"
                    onClick={() => handleAddToCart(item)}
                    disabled={item.stock <= 0}
                  >
                    {item.stock <= 0 ? "Out of Stock" : "Add to Cart"}
                    {item.stock > 0 && <ShoppingCart size={16} className="ml-2" />}
                  </Button>
                  <Button
                    variant="outline"
                    className="sm:flex-1"
                    onClick={() => handleRemoveFromWishlist(item.id, item.name)}
                  >
                    Remove
                    <Trash2 size={16} className="ml-2" />
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-16 border rounded-lg bg-muted/30">
          <h3 className="text-lg font-medium mb-2">Your wishlist is empty</h3>
          <p className="text-muted-foreground mb-6">Save items you like by clicking the heart icon on product pages</p>
          <Button asChild>
            <Link href="/shop">
              Continue Shopping <ArrowRight size={16} className="ml-2" />
            </Link>
          </Button>
        </div>
      )}
    </div>
  )
}

