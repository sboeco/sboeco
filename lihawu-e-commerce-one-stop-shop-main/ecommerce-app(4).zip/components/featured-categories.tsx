"use client"

import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"
import { useEffect, useState } from "react"
import { collection, getDocs } from "firebase/firestore"
import { db } from "@/lib/firebase/index"
import { Skeleton } from "@/components/ui/skeleton"

export function FeaturedCategories() {
  const [categories, setCategories] = useState([
    {
      id: 1,
      name: "Electronics",
      image: "/placeholder.svg?height=200&width=200",
      slug: "electronics",
    },
    {
      id: 2,
      name: "Fashion",
      image: "/placeholder.svg?height=200&width=200",
      slug: "fashion",
    },
    {
      id: 3,
      name: "Home & Kitchen",
      image: "/placeholder.svg?height=200&width=200",
      slug: "home-kitchen",
    },
    {
      id: 4,
      name: "Beauty & Health",
      image: "/placeholder.svg?height=200&width=200",
      slug: "beauty-health",
    },
  ])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const categoriesRef = collection(db, "categories")
        const snapshot = await getDocs(categoriesRef)

        if (!snapshot.empty) {
          const fetchedCategories = snapshot.docs.map((doc) => ({
            id: doc.id,
            ...doc.data(),
            slug: doc.data().slug || doc.data().name.toLowerCase().replace(/\s+/g, "-"),
          }))
          setCategories(fetchedCategories)
        }
      } catch (error) {
        console.error("Error fetching categories:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchCategories()
  }, [])

  return (
    <section className="py-12">
      <div className="flex items-center justify-between mb-8">
        <h2 className="text-2xl font-bold tracking-tight">Shop by Category</h2>
        <Link href="/categories" className="text-sm font-medium text-primary hover:underline">
          View all categories
        </Link>
      </div>

      {loading ? (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {[1, 2, 3, 4].map((item) => (
            <div key={item} className="space-y-2">
              <Skeleton className="h-[200px] w-full rounded-lg" />
              <Skeleton className="h-4 w-20" />
            </div>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {categories.map((category) => (
            <Link key={category.id} href={`/categories/${category.slug}`}>
              <Card className="overflow-hidden transition-all hover:shadow-md">
                <CardContent className="p-0">
                  <div className="relative aspect-square">
                    <img
                      src={category.image || "/placeholder.svg?height=200&width=200"}
                      alt={category.name}
                      className="object-cover w-full h-full"
                    />
                    <div className="absolute inset-0 bg-black/30 flex items-end">
                      <div className="w-full p-4 bg-gradient-to-t from-black/80 to-transparent">
                        <h3 className="font-medium text-white">{category.name}</h3>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      )}
    </section>
  )
}

