import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

export function Testimonials() {
  const testimonials = [
    {
      id: 1,
      name: "Sarah Johnson",
      avatar: "/placeholder.svg?height=40&width=40",
      role: "Verified Customer",
      content:
        "I've been shopping with EcoShop for over a year now and I'm always impressed with the quality of products and the fast delivery. Their customer service is exceptional!",
      rating: 5,
    },
    {
      id: 2,
      name: "Michael Chen",
      avatar: "/placeholder.svg?height=40&width=40",
      role: "Verified Customer",
      content:
        "The variety of products available is amazing. I found exactly what I was looking for at a great price. Will definitely be shopping here again.",
      rating: 4,
    },
    {
      id: 3,
      name: "Thandi Dlamini",
      avatar: "/placeholder.svg?height=40&width=40",
      role: "Verified Customer",
      content:
        "As someone living in rural Eswatini, I appreciate the reliable delivery service. The products are always well-packaged and arrive in perfect condition.",
      rating: 5,
    },
  ]

  return (
    <section className="py-12">
      <div className="text-center mb-10">
        <h2 className="text-2xl font-bold tracking-tight mb-2">What Our Customers Say</h2>
        <p className="text-muted-foreground">Don't just take our word for it, hear from our satisfied customers</p>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        {testimonials.map((testimonial) => (
          <Card key={testimonial.id}>
            <CardContent className="p-6">
              <div className="flex items-center gap-4 mb-4">
                <Avatar>
                  <AvatarImage src={testimonial.avatar} alt={testimonial.name} />
                  <AvatarFallback>{testimonial.name[0]}</AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-medium">{testimonial.name}</p>
                  <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                </div>
              </div>
              <div className="flex mb-2">
                {Array.from({ length: 5 }).map((_, i) => (
                  <span key={i} className={i < testimonial.rating ? "text-yellow-500" : "text-gray-300"}>
                    ★
                  </span>
                ))}
              </div>
              <p className="text-muted-foreground">{testimonial.content}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </section>
  )
}

