"use client"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Facebook, Twitter, Linkedin, MessageCircle, Copy, Check, Share2 } from "lucide-react"
import { useState } from "react"
import { useToast } from "@/components/ui/use-toast"
import Image from "next/image"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

export function ShareProduct({ product }) {
  const [copied, setCopied] = useState(false)
  const [open, setOpen] = useState(false)
  const { toast } = useToast()

  const productUrl =
    typeof window !== "undefined" ? `${window.location.origin}/products/${product.id}` : `/products/${product.id}`

  const shareText = `Check out ${product.name} on our store!`

  const handleCopyLink = () => {
    navigator.clipboard.writeText(productUrl)
    setCopied(true)
    toast({
      title: "Link copied",
      description: "Product link copied to clipboard",
    })
    setTimeout(() => setCopied(false), 2000)
  }

  const handleShareWhatsApp = () => {
    const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(`${shareText} ${productUrl}`)}`
    window.open(whatsappUrl, "_blank")
    setOpen(false)
  }

  const handleShareFacebook = () => {
    const facebookUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(productUrl)}`
    window.open(facebookUrl, "_blank")
    setOpen(false)
  }

  const handleShareTwitter = () => {
    const twitterUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(productUrl)}`
    window.open(twitterUrl, "_blank")
    setOpen(false)
  }

  const handleShareLinkedIn = () => {
    const linkedinUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(productUrl)}`
    window.open(linkedinUrl, "_blank")
    setOpen(false)
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="flex items-center gap-2">
          <Share2 className="h-4 w-4" />
          Share
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Share this product</DialogTitle>
          <DialogDescription>Share this amazing product with your friends and family</DialogDescription>
        </DialogHeader>

        <div className="flex items-center space-x-4 py-4">
          <div className="relative h-24 w-24 flex-shrink-0 overflow-hidden rounded-md border">
            <Image
              src={product.images?.[0] || "/placeholder.svg?height=96&width=96"}
              alt={product.name}
              fill
              className="object-cover object-center"
            />
          </div>
          <div>
            <h3 className="text-sm font-medium text-gray-900 dark:text-gray-100">{product.name}</h3>
            <p className="mt-1 text-sm text-gray-500 dark:text-gray-400 line-clamp-2">{product.description}</p>
            <p className="mt-1 text-sm font-medium text-gray-900 dark:text-gray-100">SZL {product.price.toFixed(2)}</p>
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex items-center space-x-2">
            <Input value={productUrl} readOnly className="flex-1" />
            <Button size="sm" onClick={handleCopyLink}>
              {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
            </Button>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <Button variant="outline" className="w-full" onClick={handleShareWhatsApp}>
              <MessageCircle className="mr-2 h-4 w-4" />
              WhatsApp
            </Button>
            <Button variant="outline" className="w-full" onClick={handleShareFacebook}>
              <Facebook className="mr-2 h-4 w-4" />
              Facebook
            </Button>
            <Button variant="outline" className="w-full" onClick={handleShareTwitter}>
              <Twitter className="mr-2 h-4 w-4" />
              Twitter
            </Button>
            <Button variant="outline" className="w-full" onClick={handleShareLinkedIn}>
              <Linkedin className="mr-2 h-4 w-4" />
              LinkedIn
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}

