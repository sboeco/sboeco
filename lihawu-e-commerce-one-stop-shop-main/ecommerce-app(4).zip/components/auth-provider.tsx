"use client"

import { createContext, useContext, useEffect, useState, useRef } from "react"
import {
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  updateProfile,
  sendPasswordResetEmail,
  sendEmailVerification,
  getAuth,
} from "firebase/auth"
import { doc, getDoc, setDoc, updateDoc, serverTimestamp } from "firebase/firestore"
import { auth, db } from "@/lib/firebase"

const AuthContext = createContext({})

export const useAuth = () => useContext(AuthContext)

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)
  const [userRole, setUserRole] = useState(null)
  const [loading, setLoading] = useState(true)
  const [authError, setAuthError] = useState(null)
  const isMounted = useRef(true)

  useEffect(() => {
    return () => {
      isMounted.current = false
    }
  }, [])

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (authUser) => {
      try {
        if (authUser) {
          // Get basic user info
          const userData = {
            uid: authUser.uid,
            email: authUser.email,
            displayName: authUser.displayName,
            photoURL: authUser.photoURL,
            emailVerified: authUser.emailVerified,
          }

          // Get additional user data from Firestore including role
          try {
            const userDoc = await getDoc(doc(db, "users", authUser.uid))
            if (userDoc.exists() && isMounted.current) {
              const userDataFromFirestore = userDoc.data()
              setUserRole(userDataFromFirestore.role || "user")

              // Merge Firebase Auth data with Firestore data
              setUser({
                ...userData,
                phoneNumber: userDataFromFirestore.phoneNumber,
                region: userDataFromFirestore.region,
                role: userDataFromFirestore.role || "user",
                createdAt: userDataFromFirestore.createdAt,
                lastLogin: userDataFromFirestore.lastLogin,
              })

              // Update last login time
              await updateDoc(doc(db, "users", authUser.uid), {
                lastLogin: serverTimestamp(),
              })
            } else if (isMounted.current) {
              // If no additional data exists, just use the basic auth data
              setUser(userData)
              setUserRole("user")

              // Create a new user document in Firestore
              await setDoc(doc(db, "users", authUser.uid), {
                email: authUser.email,
                displayName: authUser.displayName || "",
                photoURL: authUser.photoURL || "",
                role: "user",
                createdAt: serverTimestamp(),
                lastLogin: serverTimestamp(),
              })
            }
          } catch (error) {
            console.error("Error fetching user data:", error)
            if (isMounted.current) {
              setUser(userData)
              setUserRole("user")
              setAuthError("Error fetching user data. Some features may be limited.")
            }
          }
        } else if (isMounted.current) {
          setUser(null)
          setUserRole(null)
          setAuthError(null)
        }
      } catch (error) {
        console.error("Auth state change error:", error)
        if (isMounted.current) {
          setUser(null)
          setUserRole(null)
          setAuthError("Authentication error. Please try again later.")
          setLoading(false)
        }
      } finally {
        if (isMounted.current) {
          setLoading(false)
        }
      }
    })

    return () => unsubscribe()
  }, [])

  const login = async (email, password) => {
    try {
      setAuthError(null)
      const userCredential = await signInWithEmailAndPassword(auth, email, password)
      return userCredential
    } catch (error) {
      console.error("Login error:", error)
      let errorMessage = "Failed to login. Please check your credentials."

      if (error.code === "auth/user-not-found" || error.code === "auth/wrong-password") {
        errorMessage = "Invalid email or password."
      } else if (error.code === "auth/too-many-requests") {
        errorMessage = "Too many failed login attempts. Please try again later."
      } else if (error.code === "auth/user-disabled") {
        errorMessage = "This account has been disabled. Please contact support."
      }

      setAuthError(errorMessage)
      throw error
    }
  }

  const signup = async (email, password, displayName) => {
    try {
      setAuthError(null)

      // First check if email already exists
      try {
        const methods = await getAuth().fetchSignInMethodsForEmail(email)
        if (methods && methods.length > 0) {
          throw { code: "auth/email-already-in-use" }
        }
      } catch (error) {
        if (error.code === "auth/email-already-in-use") {
          throw error
        }
        // Ignore other errors from this check
      }

      // Create new user
      const userCredential = await createUserWithEmailAndPassword(auth, email, password)

      // Update profile with display name
      if (displayName) {
        await updateProfile(userCredential.user, { displayName })
      }

      // Send email verification (wrapped in try/catch to not block the flow)
      try {
        await sendEmailVerification(userCredential.user)
      } catch (verifyError) {
        console.error("Failed to send verification email:", verifyError)
        // Continue with signup process even if verification email fails
      }

      return userCredential
    } catch (error) {
      console.error("Signup error:", error)
      let errorMessage = "Failed to create account."

      if (error.code === "auth/email-already-in-use") {
        errorMessage = "Email is already in use. Please use a different email or try logging in."
      } else if (error.code === "auth/invalid-email") {
        errorMessage = "Invalid email address."
      } else if (error.code === "auth/weak-password") {
        errorMessage = "Password is too weak. Please use a stronger password."
      } else if (error.code === "auth/network-request-failed") {
        errorMessage = "Network error. Please check your internet connection and try again."
      }

      setAuthError(errorMessage)
      throw error
    }
  }

  const logout = async () => {
    try {
      await signOut(auth)
      setUser(null)
      setUserRole(null)
      setAuthError(null)

      // Clear any user-specific data from localStorage
      // But keep cart and wishlist for guest shopping experience
    } catch (error) {
      console.error("Logout error:", error)
      setAuthError("Failed to log out. Please try again.")
      throw error
    }
  }

  const resetPassword = async (email) => {
    try {
      setAuthError(null)
      await sendPasswordResetEmail(auth, email)
      return true
    } catch (error) {
      console.error("Password reset error:", error)
      let errorMessage = "Failed to send password reset email."

      if (error.code === "auth/user-not-found") {
        errorMessage = "No account found with this email address."
      } else if (error.code === "auth/invalid-email") {
        errorMessage = "Invalid email address."
      }

      setAuthError(errorMessage)
      throw error
    }
  }

  const isAdmin = () => {
    return userRole === "admin"
  }

  const updateUserProfile = async (data) => {
    if (!user) return false

    try {
      // Update auth profile
      if (data.displayName || data.photoURL) {
        await updateProfile(auth.currentUser, {
          displayName: data.displayName || user.displayName,
          photoURL: data.photoURL || user.photoURL,
        })
      }

      // Update Firestore data
      await updateDoc(doc(db, "users", user.uid), {
        ...data,
        updatedAt: serverTimestamp(),
      })

      // Update local user state
      if (isMounted.current) {
        setUser((prev) => ({
          ...prev,
          ...data,
        }))
      }

      return true
    } catch (error) {
      console.error("Profile update error:", error)
      setAuthError("Failed to update profile. Please try again.")
      throw error
    }
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        login,
        signup,
        logout,
        loading,
        isAdmin,
        userRole,
        updateUserProfile,
        resetPassword,
        authError,
        setAuthError,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

