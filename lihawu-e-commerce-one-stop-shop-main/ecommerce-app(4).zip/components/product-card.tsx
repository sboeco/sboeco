"use client"

import { useState, useEffect, useRef } from "react"
import Link from "next/link"
import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Heart, ShoppingCart, AlertTriangle } from "lucide-react"
import { useCart } from "@/hooks/use-cart"
import { useWishlist } from "@/hooks/use-wishlist"
import { useToast } from "@/components/ui/use-toast"
import { cn } from "@/lib/utils"

export function ProductCard({ product }) {
  const { addToCart } = useCart()
  const { addToWishlist, removeFromWishlist, isInWishlist } = useWishlist()
  const { toast } = useToast()
  const [isInWishlistState, setIsInWishlistState] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [imageError, setImageError] = useState(false)
  const isMounted = useRef(true)
  const [hasMounted, setHasMounted] = useState(false)

  // Validate product data
  if (!product || !product.id || !product.name) {
    return null
  }

  // Convert price values to numbers safely
  const productPrice = typeof product.price === "number" ? product.price : Number.parseFloat(product.price) || 0
  const productSalePrice = product.salePrice
    ? typeof product.salePrice === "number"
      ? product.salePrice
      : Number.parseFloat(product.salePrice) || 0
    : null
  const isOnSale = !!productSalePrice && productSalePrice < productPrice

  // Calculate discount percentage if on sale
  const discountPercentage = isOnSale ? Math.round(((productPrice - productSalePrice) / productPrice) * 100) : 0

  useEffect(() => {
    setHasMounted(true)
    return () => {
      isMounted.current = false
    }
  }, [])

  useEffect(() => {
    let didCancel = false

    if (hasMounted && product && product.id) {
      const wishlistStatus = isInWishlist(product.id)
      if (!didCancel && isMounted.current) {
        setIsInWishlistState(wishlistStatus)
      }
    }

    return () => {
      didCancel = true
    }
  }, [product, isInWishlist, hasMounted])

  const handleAddToCart = () => {
    if (isLoading || !product || (product.stock !== undefined && product.stock <= 0)) return

    setIsLoading(true)
    try {
      addToCart(product)
      if (isMounted.current) {
        toast({
          title: "Added to cart",
          description: `${product.name} has been added to your cart.`,
        })
      }
    } catch (error) {
      console.error("Error adding to cart:", error)
      if (isMounted.current) {
        toast({
          title: "Error",
          description: "Failed to add product to cart.",
          variant: "destructive",
        })
      }
    } finally {
      if (isMounted.current) {
        setIsLoading(false)
      }
    }
  }

  const toggleWishlist = () => {
    if (!product || !product.id) return

    try {
      if (isInWishlistState) {
        removeFromWishlist(product.id)
        if (isMounted.current) {
          setIsInWishlistState(false)
          toast({
            title: "Removed from wishlist",
            description: `${product.name} has been removed from your wishlist.`,
          })
        }
      } else {
        addToWishlist(product)
        if (isMounted.current) {
          setIsInWishlistState(true)
          toast({
            title: "Added to wishlist",
            description: `${product.name} has been added to your wishlist.`,
          })
        }
      }
    } catch (error) {
      console.error("Error toggling wishlist:", error)
      if (isMounted.current) {
        toast({
          title: "Error",
          description: "Failed to update wishlist.",
          variant: "destructive",
        })
      }
    }
  }

  const handleImageError = () => {
    setImageError(true)
  }

  return (
    <Card className="overflow-hidden group h-full flex flex-col">
      <div className="relative aspect-square overflow-hidden">
        <Link href={`/products/${product.id}`}>
          <div className="h-full w-full relative">
            <Image
              src={imageError || !product.images?.[0] ? "/placeholder.svg?height=400&width=400" : product.images[0]}
              alt={product.name}
              fill
              sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
              className="object-cover transition-transform duration-300 group-hover:scale-105"
              onError={handleImageError}
              priority={false}
            />
          </div>
        </Link>
        <div className="absolute top-2 right-2">
          <Button
            variant="ghost"
            size="icon"
            className="rounded-full bg-white/80 backdrop-blur-sm hover:bg-white/90 dark:bg-black/80 dark:hover:bg-black/90"
            onClick={toggleWishlist}
            aria-label={isInWishlistState ? "Remove from wishlist" : "Add to wishlist"}
          >
            <Heart
              className={cn("h-5 w-5", isInWishlistState ? "fill-red-500 text-red-500" : "text-muted-foreground")}
            />
            <span className="sr-only">{isInWishlistState ? "Remove from wishlist" : "Add to wishlist"}</span>
          </Button>
        </div>
        {isOnSale && (
          <Badge className="absolute top-2 left-2 bg-red-500 hover:bg-red-600">{discountPercentage}% OFF</Badge>
        )}
        {product.isNew && <Badge className="absolute top-2 left-2 bg-green-500 hover:bg-green-600">NEW</Badge>}
        {product.stock === 0 && (
          <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
            <Badge className="bg-red-500 hover:bg-red-600 text-lg py-1.5">Out of Stock</Badge>
          </div>
        )}
        {product.stock > 0 && product.stock <= 5 && (
          <div className="absolute bottom-2 left-2 right-2">
            <Badge
              variant="outline"
              className="w-full bg-yellow-100 text-yellow-800 border-yellow-300 flex items-center justify-center gap-1"
            >
              <AlertTriangle className="h-3 w-3" /> Low Stock: {product.stock} left
            </Badge>
          </div>
        )}
      </div>
      <CardContent className="flex flex-col flex-grow p-4">
        <div className="flex-grow">
          <Link href={`/products/${product.id}`} className="hover:underline">
            <h3 className="font-medium line-clamp-1">{product.name}</h3>
          </Link>
          <p className="text-sm text-muted-foreground line-clamp-2 mt-1">
            {product.description || "No description available"}
          </p>
        </div>
        <div className="flex items-center justify-between mt-4">
          <div className="flex flex-col">
            {isOnSale ? (
              <>
                <span className="font-semibold">
                  SZL {(typeof productSalePrice === "number" ? productSalePrice : 0).toFixed(2)}
                </span>
                <span className="text-xs text-muted-foreground line-through">
                  SZL {(typeof productPrice === "number" ? productPrice : 0).toFixed(2)}
                </span>
              </>
            ) : (
              <span className="font-semibold">
                SZL {(typeof productPrice === "number" ? productPrice : 0).toFixed(2)}
              </span>
            )}
          </div>
          <Button
            size="sm"
            className="rounded-full"
            onClick={handleAddToCart}
            disabled={isLoading || product.stock === 0}
            aria-label="Add to cart"
          >
            <ShoppingCart className="h-4 w-4 mr-2" />
            Add
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

