"use client"

import { useState, useEffect } from "react"
import { collection, query, where, getDocs } from "firebase/firestore"
import { db } from "@/lib/firebase/index"
import { ProductCard } from "@/components/product-card"
import { Skeleton } from "@/components/ui/skeleton"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"

export function CategoryPage({ slug }) {
  const [category, setCategory] = useState(null)
  const [products, setProducts] = useState([])
  const [loading, setLoading] = useState(true)
  const [sortOption, setSortOption] = useState("featured")

  useEffect(() => {
    const fetchCategoryAndProducts = async () => {
      try {
        setLoading(true)

        // Fetch category details
        const categoriesRef = collection(db, "categories")
        const categoryQuery = query(categoriesRef, where("slug", "==", slug))
        const categorySnapshot = await getDocs(categoryQuery)

        let categoryData = null

        if (!categorySnapshot.empty) {
          categoryData = {
            id: categorySnapshot.docs[0].id,
            ...categorySnapshot.docs[0].data(),
          }
          setCategory(categoryData)
        } else {
          // Fallback for category not found in DB
          categoryData = {
            id: slug,
            name: slug
              .split("-")
              .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
              .join(" "),
            description: `Browse our collection of ${slug.split("-").join(" ")} products.`,
          }
          setCategory(categoryData)
        }

        // Fetch products by category
        const productsRef = collection(db, "products")
        const productsQuery = query(productsRef, where("category", "==", categoryData.name.toLowerCase()))
        const productsSnapshot = await getDocs(productsQuery)

        if (!productsSnapshot.empty) {
          const fetchedProducts = productsSnapshot.docs.map((doc) => ({
            id: doc.id,
            ...doc.data(),
          }))
          setProducts(fetchedProducts)
        } else {
          // If no products found with exact category name, try with slug
          const fallbackQuery = query(productsRef, where("category", "==", slug.replace(/-/g, " ")))
          const fallbackSnapshot = await getDocs(fallbackQuery)

          if (!fallbackSnapshot.empty) {
            const fetchedProducts = fallbackSnapshot.docs.map((doc) => ({
              id: doc.id,
              ...doc.data(),
            }))
            setProducts(fetchedProducts)
          } else {
            setProducts([])
          }
        }
      } catch (error) {
        console.error("Error fetching category data:", error)
      } finally {
        setLoading(false)
      }
    }

    if (slug) {
      fetchCategoryAndProducts()
    }
  }, [slug])

  const sortProducts = (products) => {
    switch (sortOption) {
      case "price-low":
        return [...products].sort((a, b) => {
          const aPrice = a.salePrice || a.price
          const bPrice = b.salePrice || b.price
          return aPrice - bPrice
        })
      case "price-high":
        return [...products].sort((a, b) => {
          const aPrice = a.salePrice || a.price
          const bPrice = b.salePrice || b.price
          return bPrice - aPrice
        })
      case "newest":
        return [...products].sort((a, b) => {
          return new Date(b.createdAt || 0) - new Date(a.createdAt || 0)
        })
      case "featured":
      default:
        return products
    }
  }

  const sortedProducts = sortProducts(products)

  return (
    <div className="container px-4 md:px-6 py-8 mx-auto">
      <Button variant="ghost" size="sm" className="mb-6" asChild>
        <Link href="/categories">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Categories
        </Link>
      </Button>

      {loading ? (
        <div className="space-y-8">
          <div className="space-y-2">
            <Skeleton className="h-10 w-1/3" />
            <Skeleton className="h-4 w-2/3" />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {[1, 2, 3, 4, 5, 6, 7, 8].map((item) => (
              <Skeleton key={item} className="h-[300px] w-full rounded-lg" />
            ))}
          </div>
        </div>
      ) : category ? (
        <div className="space-y-8">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">{category.name}</h1>
            <p className="text-muted-foreground mt-1">{category.description}</p>
          </div>

          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <p className="text-sm text-muted-foreground">
              {products.length} {products.length === 1 ? "product" : "products"} found
            </p>
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium">Sort by:</span>
              <Select value={sortOption} onValueChange={setSortOption}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="featured">Featured</SelectItem>
                  <SelectItem value="price-low">Price: Low to High</SelectItem>
                  <SelectItem value="price-high">Price: High to Low</SelectItem>
                  <SelectItem value="newest">Newest First</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {sortedProducts.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {sortedProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12 border rounded-lg bg-muted/30">
              <h2 className="text-xl font-bold mb-2">No Products Found</h2>
              <p className="text-muted-foreground mb-6">We couldn't find any products in this category.</p>
              <Button asChild>
                <Link href="/shop">Browse All Products</Link>
              </Button>
            </div>
          )}
        </div>
      ) : (
        <div className="text-center py-12 border rounded-lg bg-muted/30">
          <h2 className="text-xl font-bold mb-2">Category Not Found</h2>
          <p className="text-muted-foreground mb-6">
            The category you're looking for doesn't exist or has been removed.
          </p>
          <Button asChild>
            <Link href="/categories">Browse All Categories</Link>
          </Button>
        </div>
      )}
    </div>
  )
}

