"use client"

import { useState, useEffect, useRef } from "react"
import { useSearchParams } from "next/navigation"
import { getProducts } from "@/lib/firebase/products"
import { ProductCard } from "@/components/product-card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { Search, SlidersHorizontal, X } from "lucide-react"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"

export function ShopPage() {
  const searchParams = useSearchParams()
  const categoryParam = searchParams.get("category")
  const searchParam = searchParams.get("search")

  const [products, setProducts] = useState([])
  const [filteredProducts, setFilteredProducts] = useState([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState(searchParam || "")
  const [sortOption, setSortOption] = useState("featured")
  const [priceRange, setPriceRange] = useState([0, 5000])
  const [selectedCategories, setSelectedCategories] = useState(categoryParam ? [categoryParam] : [])
  const [availableCategories, setAvailableCategories] = useState([])
  const [inStockOnly, setInStockOnly] = useState(false)
  const [onSaleOnly, setOnSaleOnly] = useState(false)
  const isMounted = useRef(true)

  useEffect(() => {
    return () => {
      isMounted.current = false
    }
  }, [])

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        setLoading(true)
        const productsData = await getProducts()

        if (isMounted.current) {
          setProducts(productsData)

          // Extract unique categories
          const categories = [...new Set(productsData.map((product) => product.category).filter(Boolean))]
          setAvailableCategories(categories)

          // Find max price for range
          const maxPrice = Math.max(...productsData.map((product) => product.price || 0))
          setPriceRange([0, maxPrice > 0 ? maxPrice : 5000])

          setLoading(false)
        }
      } catch (error) {
        console.error("Error fetching products:", error)
        if (isMounted.current) {
          setLoading(false)
        }
      }
    }

    fetchProducts()
  }, [])

  useEffect(() => {
    if (categoryParam && !selectedCategories.includes(categoryParam)) {
      setSelectedCategories([categoryParam])
    }
  }, [categoryParam, selectedCategories])

  useEffect(() => {
    if (searchParam && searchParam !== searchQuery) {
      setSearchQuery(searchParam)
    }
  }, [searchParam, searchQuery])

  useEffect(() => {
    let filtered = [...products]

    // Filter by search query
    if (searchQuery) {
      filtered = filtered.filter(
        (product) =>
          product.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
          product.description?.toLowerCase().includes(searchQuery.toLowerCase()),
      )
    }

    // Filter by categories
    if (selectedCategories.length > 0) {
      filtered = filtered.filter((product) => product.category && selectedCategories.includes(product.category))
    }

    // Filter by price range
    filtered = filtered.filter(
      (product) => (product.price || 0) >= priceRange[0] && (product.price || 0) <= priceRange[1],
    )

    // Filter by stock
    if (inStockOnly) {
      filtered = filtered.filter((product) => product.stock > 0)
    }

    // Filter by sale
    if (onSaleOnly) {
      filtered = filtered.filter((product) => product.salePrice && product.salePrice < product.price)
    }

    // Sort products
    switch (sortOption) {
      case "price-asc":
        filtered.sort((a, b) => (a.salePrice || a.price || 0) - (b.salePrice || b.price || 0))
        break
      case "price-desc":
        filtered.sort((a, b) => (b.salePrice || b.price || 0) - (a.salePrice || a.price || 0))
        break
      case "newest":
        filtered.sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0))
        break
      case "bestselling":
        filtered.sort((a, b) => (b.soldCount || 0) - (a.soldCount || 0))
        break
      default:
        // Featured - no specific sort
        break
    }

    if (isMounted.current) {
      setFilteredProducts(filtered)
    }
  }, [products, searchQuery, selectedCategories, priceRange, inStockOnly, onSaleOnly, sortOption])

  const handleCategoryToggle = (category) => {
    setSelectedCategories((prev) =>
      prev.includes(category) ? prev.filter((c) => c !== category) : [...prev, category],
    )
  }

  const clearFilters = () => {
    setSearchQuery("")
    setSelectedCategories([])
    setPriceRange([0, Math.max(...products.map((product) => product.price || 0))])
    setInStockOnly(false)
    setOnSaleOnly(false)
    setSortOption("featured")
  }

  const hasActiveFilters = () => {
    return searchQuery !== "" || selectedCategories.length > 0 || inStockOnly || onSaleOnly || sortOption !== "featured"
  }

  const FilterSidebar = () => (
    <div className="space-y-6">
      <div>
        <h3 className="font-medium mb-4">Categories</h3>
        <div className="space-y-3">
          {availableCategories.map((category) => (
            <div key={category} className="flex items-center space-x-2">
              <Checkbox
                id={`category-${category}`}
                checked={selectedCategories.includes(category)}
                onCheckedChange={() => handleCategoryToggle(category)}
              />
              <Label htmlFor={`category-${category}`} className="text-sm cursor-pointer">
                {category}
              </Label>
            </div>
          ))}
        </div>
      </div>

      <div>
        <h3 className="font-medium mb-4">Price Range</h3>
        <div className="px-2">
          <Slider
            defaultValue={priceRange}
            min={0}
            max={Math.max(...products.map((product) => product.price || 0), 5000)}
            step={10}
            value={priceRange}
            onValueChange={setPriceRange}
            className="mb-6"
          />
          <div className="flex items-center justify-between">
            <span className="text-sm">SZL {priceRange[0]}</span>
            <span className="text-sm">SZL {priceRange[1]}</span>
          </div>
        </div>
      </div>

      <div>
        <h3 className="font-medium mb-4">Product Status</h3>
        <div className="space-y-3">
          <div className="flex items-center space-x-2">
            <Checkbox id="in-stock" checked={inStockOnly} onCheckedChange={setInStockOnly} />
            <Label htmlFor="in-stock" className="text-sm cursor-pointer">
              In Stock Only
            </Label>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox id="on-sale" checked={onSaleOnly} onCheckedChange={setOnSaleOnly} />
            <Label htmlFor="on-sale" className="text-sm cursor-pointer">
              On Sale Only
            </Label>
          </div>
        </div>
      </div>

      {hasActiveFilters() && (
        <Button variant="outline" className="w-full" onClick={clearFilters}>
          <X className="h-4 w-4 mr-2" />
          Clear Filters
        </Button>
      )}
    </div>
  )

  return (
    <div className="container px-4 py-8 mx-auto">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <h1 className="text-2xl md:text-3xl font-bold">Shop All Products</h1>

        <div className="flex flex-wrap items-center gap-4 w-full md:w-auto">
          <div className="relative flex-1 min-w-[200px] md:w-64">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search products..."
              className="pl-8"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          <div className="flex items-center gap-4">
            <Select value={sortOption} onValueChange={setSortOption}>
              <SelectTrigger className="w-[150px] md:w-[180px]">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="featured">Featured</SelectItem>
                <SelectItem value="price-asc">Price: Low to High</SelectItem>
                <SelectItem value="price-desc">Price: High to Low</SelectItem>
                <SelectItem value="newest">Newest Arrivals</SelectItem>
                <SelectItem value="bestselling">Best Selling</SelectItem>
              </SelectContent>
            </Select>

            <Sheet>
              <SheetTrigger asChild>
                <Button variant="outline" size="icon" className="md:hidden">
                  <SlidersHorizontal className="h-4 w-4" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left">
                <h2 className="text-xl font-semibold mb-6">Filters</h2>
                <FilterSidebar />
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
        <div className="hidden md:block sticky top-20 self-start">
          <Accordion type="multiple" defaultValue={["categories", "price", "status"]}>
            <AccordionItem value="categories">
              <AccordionTrigger>Categories</AccordionTrigger>
              <AccordionContent>
                <div className="space-y-3">
                  {availableCategories.map((category) => (
                    <div key={category} className="flex items-center space-x-2">
                      <Checkbox
                        id={`category-desktop-${category}`}
                        checked={selectedCategories.includes(category)}
                        onCheckedChange={() => handleCategoryToggle(category)}
                      />
                      <Label htmlFor={`category-desktop-${category}`} className="text-sm cursor-pointer">
                        {category}
                      </Label>
                    </div>
                  ))}
                </div>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="price">
              <AccordionTrigger>Price Range</AccordionTrigger>
              <AccordionContent>
                <div className="px-2">
                  <Slider
                    defaultValue={priceRange}
                    min={0}
                    max={Math.max(...products.map((product) => product.price || 0), 5000)}
                    step={10}
                    value={priceRange}
                    onValueChange={setPriceRange}
                    className="mb-6"
                  />
                  <div className="flex items-center justify-between">
                    <span className="text-sm">SZL {priceRange[0]}</span>
                    <span className="text-sm">SZL {priceRange[1]}</span>
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="status">
              <AccordionTrigger>Product Status</AccordionTrigger>
              <AccordionContent>
                <div className="space-y-3">
                  <div className="flex items-center space-x-2">
                    <Checkbox id="in-stock-desktop" checked={inStockOnly} onCheckedChange={setInStockOnly} />
                    <Label htmlFor="in-stock-desktop" className="text-sm cursor-pointer">
                      In Stock Only
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="on-sale-desktop" checked={onSaleOnly} onCheckedChange={setOnSaleOnly} />
                    <Label htmlFor="on-sale-desktop" className="text-sm cursor-pointer">
                      On Sale Only
                    </Label>
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>
          </Accordion>

          {hasActiveFilters() && (
            <Button variant="outline" className="w-full mt-4" onClick={clearFilters}>
              <X className="h-4 w-4 mr-2" />
              Clear Filters
            </Button>
          )}
        </div>

        <div className="md:col-span-3">
          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {Array.from({ length: 6 }).map((_, index) => (
                <div key={index} className="rounded-lg overflow-hidden">
                  <div className="aspect-square bg-muted animate-pulse" />
                  <div className="p-4 space-y-2">
                    <div className="h-4 bg-muted rounded animate-pulse" />
                    <div className="h-4 bg-muted rounded w-2/3 animate-pulse" />
                    <div className="h-6 bg-muted rounded w-1/3 animate-pulse mt-4" />
                  </div>
                </div>
              ))}
            </div>
          ) : filteredProducts.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
              {filteredProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <h3 className="text-xl font-medium mb-2">No products found</h3>
              <p className="text-muted-foreground mb-6">Try adjusting your search or filter criteria</p>
              <Button onClick={clearFilters}>Clear All Filters</Button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

