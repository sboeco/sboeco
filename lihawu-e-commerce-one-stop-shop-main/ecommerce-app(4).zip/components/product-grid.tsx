"use client"

import { useState, useEffect, useRef } from "react"
import { ProductCard } from "@/components/product-card"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { getProducts } from "@/lib/firebase/products"

export default function ProductGrid() {
  const isMounted = useRef(true)
  const [products, setProducts] = useState([])
  const [loading, setLoading] = useState(true)
  const [visibleProducts, setVisibleProducts] = useState(8)

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const productsData = await getProducts()
        if (isMounted.current) {
          setProducts(productsData || [])
        }
      } catch (error) {
        console.error("Error fetching products:", error)
        if (isMounted.current) {
          setProducts([])
        }
      } finally {
        if (isMounted.current) {
          setLoading(false)
        }
      }
    }

    fetchProducts()

    return () => {
      isMounted.current = false
    }
  }, [])

  const loadMore = () => {
    setVisibleProducts((prev) => prev + 8)
  }

  return (
    <section className="py-12">
      <div className="flex items-center justify-between mb-8">
        <h2 className="text-2xl font-bold tracking-tight">All Products</h2>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {Array.from({ length: 8 }).map((_, index) => (
            <div key={index} className="space-y-3">
              <Skeleton className="h-[200px] w-full rounded-xl" />
              <div className="space-y-2">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-10 w-full" />
              </div>
            </div>
          ))}
        </div>
      ) : products.length > 0 ? (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {products.slice(0, visibleProducts).map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>

          {visibleProducts < products.length && (
            <div className="mt-12 text-center">
              <Button onClick={loadMore} variant="outline" size="lg">
                Load More
              </Button>
            </div>
          )}
        </>
      ) : (
        <div className="text-center py-12">
          <p className="text-muted-foreground">No products available at the moment.</p>
        </div>
      )}
    </section>
  )
}

