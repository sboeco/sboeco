"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { useAuth } from "@/components/auth-provider"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  Package,
  ShoppingBag,
  Users,
  BarChart,
  Settings,
  LogOut,
  Home,
  MessageSquare,
  AlertTriangle,
  Search,
  ChevronDown,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"

export function AdminSidebar() {
  const pathname = usePathname()
  const { user, logout } = useAuth()
  const [openProducts, setOpenProducts] = useState(true)
  const [openUsers, setOpenUsers] = useState(false)

  const routes = [
    {
      label: "Dashboard",
      icon: Home,
      href: "/admin",
      active: pathname === "/admin",
    },
    {
      label: "Analytics",
      icon: BarChart,
      href: "/admin/analytics",
      active: pathname === "/admin/analytics",
    },
    {
      label: "Orders",
      icon: ShoppingBag,
      href: "/admin/orders",
      active: pathname === "/admin/orders",
    },
    {
      label: "Customer Feedback",
      icon: MessageSquare,
      href: "/admin/feedback",
      active: pathname === "/admin/feedback",
    },
    {
      label: "Search Analytics",
      icon: Search,
      href: "/admin/search-analytics",
      active: pathname === "/admin/search-analytics",
    },
    {
      label: "Inventory Alerts",
      icon: AlertTriangle,
      href: "/admin/inventory-alerts",
      active: pathname === "/admin/inventory-alerts",
    },
    {
      label: "Settings",
      icon: Settings,
      href: "/admin/settings",
      active: pathname === "/admin/settings",
    },
  ]

  return (
    <div className="flex h-full flex-col border-r bg-muted/40">
      <div className="p-6">
        <Link href="/admin" className="flex items-center gap-2">
          <Package className="h-6 w-6" />
          <span className="font-bold">Admin Panel</span>
        </Link>
      </div>
      <ScrollArea className="flex-1 px-3">
        <div className="flex flex-col gap-1 py-2">
          {routes.map((route) => (
            <Button
              key={route.href}
              variant={route.active ? "secondary" : "ghost"}
              className={cn("justify-start", route.active && "bg-secondary")}
              asChild
            >
              <Link href={route.href}>
                <route.icon className="mr-2 h-4 w-4" />
                {route.label}
              </Link>
            </Button>
          ))}

          <Collapsible open={openProducts} onOpenChange={setOpenProducts} className="w-full">
            <CollapsibleTrigger asChild>
              <Button variant="ghost" className="w-full justify-between">
                <div className="flex items-center">
                  <Package className="mr-2 h-4 w-4" />
                  Products
                </div>
                <ChevronDown className={cn("h-4 w-4 transition-transform", openProducts ? "rotate-180" : "")} />
              </Button>
            </CollapsibleTrigger>
            <CollapsibleContent className="pl-6 pt-1">
              <div className="flex flex-col gap-1">
                <Button
                  variant={pathname === "/admin/products" ? "secondary" : "ghost"}
                  className="justify-start"
                  asChild
                >
                  <Link href="/admin/products">All Products</Link>
                </Button>
                <Button
                  variant={pathname === "/admin/products/add" ? "secondary" : "ghost"}
                  className="justify-start"
                  asChild
                >
                  <Link href="/admin/products/add">Add Product</Link>
                </Button>
                <Button
                  variant={pathname === "/admin/products/categories" ? "secondary" : "ghost"}
                  className="justify-start"
                  asChild
                >
                  <Link href="/admin/products/categories">Categories</Link>
                </Button>
              </div>
            </CollapsibleContent>
          </Collapsible>

          <Collapsible open={openUsers} onOpenChange={setOpenUsers} className="w-full">
            <CollapsibleTrigger asChild>
              <Button variant="ghost" className="w-full justify-between">
                <div className="flex items-center">
                  <Users className="mr-2 h-4 w-4" />
                  Users
                </div>
                <ChevronDown className={cn("h-4 w-4 transition-transform", openUsers ? "rotate-180" : "")} />
              </Button>
            </CollapsibleTrigger>
            <CollapsibleContent className="pl-6 pt-1">
              <div className="flex flex-col gap-1">
                <Button variant={pathname === "/admin/users" ? "secondary" : "ghost"} className="justify-start" asChild>
                  <Link href="/admin/users">All Users</Link>
                </Button>
                <Button
                  variant={pathname === "/admin/users/admins" ? "secondary" : "ghost"}
                  className="justify-start"
                  asChild
                >
                  <Link href="/admin/users/admins">Admins</Link>
                </Button>
              </div>
            </CollapsibleContent>
          </Collapsible>
        </div>
      </ScrollArea>
      <div className="mt-auto p-4 border-t">
        <div className="flex items-center gap-4 mb-4">
          <Avatar>
            <AvatarImage src={user?.photoURL || ""} alt={user?.displayName || user?.email} />
            <AvatarFallback>{user?.displayName?.[0] || user?.email?.[0] || "A"}</AvatarFallback>
          </Avatar>
          <div className="space-y-1">
            <p className="text-sm font-medium">{user?.displayName || user?.email}</p>
            <p className="text-xs text-muted-foreground">Administrator</p>
          </div>
        </div>
        <Button variant="outline" className="w-full justify-start" onClick={() => logout()}>
          <LogOut className="mr-2 h-4 w-4" />
          Logout
        </Button>
      </div>
    </div>
  )
}

