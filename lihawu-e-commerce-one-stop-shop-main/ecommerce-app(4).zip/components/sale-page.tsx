"use client"

import { useState, useEffect } from "react"
import { ProductCard } from "@/components/product-card"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { getProductsOnSale } from "@/lib/firebase/products"

export function SalePage() {
  const [products, setProducts] = useState([])
  const [loading, setLoading] = useState(true)
  const [visibleProducts, setVisibleProducts] = useState(12)

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const productsData = await getProductsOnSale()
        setProducts(productsData || [])
      } catch (error) {
        console.error("Error fetching sale products:", error)
        setProducts([])
      } finally {
        setLoading(false)
      }
    }

    fetchProducts()
  }, [])

  const loadMore = () => {
    setVisibleProducts((prev) => prev + 12)
  }

  return (
    <div className="container px-4 md:px-6 py-8 mx-auto">
      <div className="relative mb-12 overflow-hidden rounded-xl bg-primary text-primary-foreground">
        <div className="absolute inset-0 bg-[url('/placeholder.svg?height=400&width=1200')] bg-cover bg-center opacity-20"></div>
        <div className="relative z-10 px-8 py-12 text-center md:py-24">
          <h1 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl mb-4">Sale</h1>
          <p className="text-primary-foreground/90 text-lg max-w-2xl mx-auto mb-6">
            Limited time offers on selected items. Grab your favorites at discounted prices before they're gone!
          </p>
          <div className="inline-block rounded-full bg-white px-4 py-2 text-primary font-medium">Up to 50% off</div>
        </div>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {Array.from({ length: 8 }).map((_, index) => (
            <div key={index} className="space-y-3">
              <Skeleton className="h-[200px] w-full rounded-xl" />
              <div className="space-y-2">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-10 w-full" />
              </div>
            </div>
          ))}
        </div>
      ) : products.length > 0 ? (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {products.slice(0, visibleProducts).map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>

          {visibleProducts < products.length && (
            <div className="mt-12 text-center">
              <Button onClick={loadMore} variant="outline" size="lg">
                Load More
              </Button>
            </div>
          )}
        </>
      ) : (
        <div className="text-center py-12 border rounded-lg bg-muted/30">
          <h3 className="text-lg font-medium mb-2">No sale items available</h3>
          <p className="text-muted-foreground">Check back soon for new promotions and discounts!</p>
        </div>
      )}
    </div>
  )
}

