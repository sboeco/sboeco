"use client"

import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { useState, useEffect, useRef } from "react"
import { getRandomProducts } from "@/lib/firebase/products"
import { Badge } from "@/components/ui/badge"
import { Star, ChevronLeft, ChevronRight } from "lucide-react"

export function FeaturedProducts() {
  const [products, setProducts] = useState([])
  const [loading, setLoading] = useState(true)
  const sliderRef = useRef(null)

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        // Get random products
        const productsData = await getRandomProducts(8) // Get more products for the slider
        setProducts(productsData || [])
      } catch (error) {
        console.error("Error fetching random products:", error)
        setProducts([])
      } finally {
        setLoading(false)
      }
    }

    fetchProducts()
  }, [])

  const scroll = (direction) => {
    if (sliderRef.current) {
      const { current } = sliderRef
      const scrollAmount =
        direction === "left" ? current.scrollLeft - current.offsetWidth : current.scrollLeft + current.offsetWidth

      current.scrollTo({
        left: scrollAmount,
        behavior: "smooth",
      })
    }
  }

  return (
    <section className="py-12 bg-gray-50 dark:bg-gray-900">
      <div className="container px-4 mx-auto">
        <div className="flex flex-col md:flex-row items-center justify-between mb-10">
          <div className="text-center md:text-left mb-6 md:mb-0">
            <h2 className="text-3xl font-bold tracking-tight">Featured Products</h2>
            <p className="text-muted-foreground mt-2 max-w-2xl">Discover our selection of exceptional products</p>
          </div>
          <Link
            href="/shop"
            className="inline-flex items-center justify-center px-6 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-primary hover:bg-primary/90 transition-colors"
          >
            View all products
          </Link>
        </div>

        <div className="relative">
          {/* Slider navigation buttons */}
          <div className="absolute top-1/2 left-0 -translate-y-1/2 -translate-x-4 z-10 hidden md:block">
            <Button
              variant="outline"
              size="icon"
              className="rounded-full bg-white/80 backdrop-blur-sm hover:bg-white shadow-md"
              onClick={() => scroll("left")}
              aria-label="Previous products"
            >
              <ChevronLeft className="h-5 w-5" />
            </Button>
          </div>

          <div className="absolute top-1/2 right-0 -translate-y-1/2 translate-x-4 z-10 hidden md:block">
            <Button
              variant="outline"
              size="icon"
              className="rounded-full bg-white/80 backdrop-blur-sm hover:bg-white shadow-md"
              onClick={() => scroll("right")}
              aria-label="Next products"
            >
              <ChevronRight className="h-5 w-5" />
            </Button>
          </div>

          {loading ? (
            <div className="flex gap-6 overflow-x-auto pb-4">
              {Array.from({ length: 4 }).map((_, index) => (
                <div
                  key={index}
                  className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden min-w-[280px] md:min-w-[320px] flex-shrink-0"
                >
                  <Skeleton className="h-[300px] w-full" />
                  <div className="p-5 space-y-3">
                    <Skeleton className="h-6 w-3/4" />
                    <Skeleton className="h-4 w-1/2" />
                    <Skeleton className="h-6 w-1/3" />
                    <Skeleton className="h-10 w-full" />
                  </div>
                </div>
              ))}
            </div>
          ) : products.length > 0 ? (
            <div
              ref={sliderRef}
              className="flex gap-6 overflow-x-auto pb-6 snap-x snap-mandatory scrollbar-hide"
              style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
            >
              {products.map((product) => (
                <div
                  key={product.id}
                  className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden min-w-[280px] md:min-w-[320px] flex-shrink-0 snap-start transition-all duration-300 hover:shadow-xl"
                >
                  <div className="relative">
                    <Link href={`/products/${product.id}`}>
                      <div className="relative h-[300px] w-full">
                        <Image
                          src={product.images?.[0] || "/placeholder.svg?height=300&width=300"}
                          alt={product.name}
                          fill
                          className="object-cover"
                          sizes="(max-width: 768px) 280px, 320px"
                        />
                      </div>
                    </Link>
                    {product.discount > 0 && (
                      <Badge className="absolute top-2 right-2 bg-red-500">{product.discount}% OFF</Badge>
                    )}
                  </div>

                  <div className="p-5">
                    <div className="flex items-center mb-2">
                      <div className="flex text-yellow-400">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`h-4 w-4 ${i < (product.rating || 0) ? "fill-current" : "text-gray-300"}`}
                          />
                        ))}
                      </div>
                      <span className="text-xs text-gray-500 ml-2">({product.reviewCount || 0} reviews)</span>
                    </div>

                    <Link href={`/products/${product.id}`}>
                      <h3 className="font-semibold text-lg mb-1 hover:text-primary transition-colors">
                        {product.name}
                      </h3>
                    </Link>

                    <p className="text-sm text-gray-500 mb-3 line-clamp-2">{product.description}</p>

                    <div className="flex items-center justify-between mb-4">
                      <div>
                        {product.discount > 0 ? (
                          <div className="flex items-center">
                            <span className="text-lg font-bold text-primary">
                              SZL {((product.price * (100 - product.discount)) / 100).toFixed(2)}
                            </span>
                            <span className="text-sm text-gray-500 line-through ml-2">
                              SZL {product.price.toFixed(2)}
                            </span>
                          </div>
                        ) : (
                          <span className="text-lg font-bold text-primary">SZL {product.price.toFixed(2)}</span>
                        )}
                      </div>
                      <Badge variant="outline" className="text-xs">
                        {product.category}
                      </Badge>
                    </div>

                    <Link href={`/products/${product.id}`}>
                      <Button className="w-full bg-primary hover:bg-primary/90 transition-colors">Buy Now</Button>
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-16 bg-white dark:bg-gray-800 rounded-lg shadow">
              <p className="text-muted-foreground text-lg">No products available at the moment.</p>
            </div>
          )}
        </div>

        {/* Mobile scroll indicator */}
        <div className="flex justify-center mt-6 gap-1 md:hidden">
          <div className="text-sm text-muted-foreground">Swipe to see more products</div>
          <ChevronRight className="h-5 w-5 text-muted-foreground animate-pulse" />
        </div>
      </div>
    </section>
  )
}

