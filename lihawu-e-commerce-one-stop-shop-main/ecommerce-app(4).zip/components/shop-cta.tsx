import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"

export function ShopCTA() {
  return (
    <section className="py-12">
      <div className="rounded-xl overflow-hidden relative">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/90 to-primary/40 z-10"></div>
        <img
          src="/placeholder.svg?height=400&width=1200"
          alt="Shop our collection"
          className="w-full h-64 md:h-80 object-cover"
        />
        <div className="absolute inset-0 z-20 flex flex-col justify-center p-8 md:p-12">
          <h2 className="text-2xl md:text-3xl font-bold text-white mb-4">Discover Our Full Collection</h2>
          <p className="text-white/90 max-w-md mb-6">
            Explore our complete range of products, from everyday essentials to premium selections. Find exactly what
            you're looking for with our easy-to-use filters.
          </p>
          <div>
            <Button size="lg" className="bg-white text-primary hover:bg-white/90" asChild>
              <Link href="/shop">
                Shop Now <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}

