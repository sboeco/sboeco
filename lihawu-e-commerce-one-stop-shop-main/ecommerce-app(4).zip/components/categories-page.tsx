"use client"

import { useState, useEffect } from "react"
import { collection, getDocs } from "firebase/firestore"
import { db } from "@/lib/firebase/index"
import { Card, CardContent } from "@/components/ui/card"
import Link from "next/link"
import { Skeleton } from "@/components/ui/skeleton"
import { Input } from "@/components/ui/input"
import { Search } from "lucide-react"

export function CategoriesPage() {
  const [categories, setCategories] = useState([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")

  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const categoriesRef = collection(db, "categories")
        const snapshot = await getDocs(categoriesRef)

        if (!snapshot.empty) {
          const fetchedCategories = snapshot.docs.map((doc) => ({
            id: doc.id,
            ...doc.data(),
            slug: doc.data().slug || doc.data().name.toLowerCase().replace(/\s+/g, "-"),
          }))
          setCategories(fetchedCategories)
        } else {
          // Fallback to default categories if none in database
          setCategories([
            {
              id: "1",
              name: "Electronics",
              image: "/placeholder.svg?height=300&width=300",
              slug: "electronics",
              description: "Explore the latest gadgets and electronic devices",
            },
            {
              id: "2",
              name: "Fashion",
              image: "/placeholder.svg?height=300&width=300",
              slug: "fashion",
              description: "Discover trendy clothing and accessories",
            },
            {
              id: "3",
              name: "Home & Kitchen",
              image: "/placeholder.svg?height=300&width=300",
              slug: "home-kitchen",
              description: "Find everything you need for your home",
            },
            {
              id: "4",
              name: "Beauty & Health",
              image: "/placeholder.svg?height=300&width=300",
              slug: "beauty-health",
              description: "Shop premium beauty and health products",
            },
            {
              id: "5",
              name: "Sports & Outdoors",
              image: "/placeholder.svg?height=300&width=300",
              slug: "sports-outdoors",
              description: "Gear up for your outdoor adventures",
            },
            {
              id: "6",
              name: "Toys & Games",
              image: "/placeholder.svg?height=300&width=300",
              slug: "toys-games",
              description: "Fun toys and games for all ages",
            },
            {
              id: "7",
              name: "Books & Stationery",
              image: "/placeholder.svg?height=300&width=300",
              slug: "books-stationery",
              description: "Expand your knowledge with our collection of books",
            },
            {
              id: "8",
              name: "Automotive",
              image: "/placeholder.svg?height=300&width=300",
              slug: "automotive",
              description: "Find parts and accessories for your vehicle",
            },
          ])
        }
      } catch (error) {
        console.error("Error fetching categories:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchCategories()
  }, [])

  const filteredCategories = categories.filter((category) =>
    category.name.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  return (
    <div className="container px-4 md:px-6 py-8 mx-auto">
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">All Categories</h1>
          <p className="text-muted-foreground mt-1">Browse all product categories in our store</p>
        </div>
        <div className="relative w-full md:w-64">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search categories..."
            className="pl-8"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {[1, 2, 3, 4, 5, 6, 7, 8].map((item) => (
            <div key={item} className="space-y-2">
              <Skeleton className="h-[200px] w-full rounded-lg" />
              <Skeleton className="h-6 w-32" />
              <Skeleton className="h-4 w-full" />
            </div>
          ))}
        </div>
      ) : filteredCategories.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {filteredCategories.map((category) => (
            <Link key={category.id} href={`/categories/${category.slug}`}>
              <Card className="overflow-hidden h-full transition-all hover:shadow-md">
                <CardContent className="p-0">
                  <div className="relative aspect-video">
                    <img
                      src={category.image || "/placeholder.svg?height=300&width=300"}
                      alt={category.name}
                      className="object-cover w-full h-full"
                    />
                    <div className="absolute inset-0 bg-black/30 flex items-end">
                      <div className="w-full p-4 bg-gradient-to-t from-black/80 to-transparent">
                        <h3 className="font-medium text-white text-lg">{category.name}</h3>
                      </div>
                    </div>
                  </div>
                  <div className="p-4">
                    <p className="text-sm text-muted-foreground line-clamp-2">
                      {category.description || `Browse our collection of ${category.name.toLowerCase()} products.`}
                    </p>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      ) : (
        <div className="text-center py-12">
          <h3 className="text-lg font-medium">No categories found</h3>
          <p className="text-muted-foreground mt-1">Try adjusting your search query</p>
        </div>
      )}
    </div>
  )
}

