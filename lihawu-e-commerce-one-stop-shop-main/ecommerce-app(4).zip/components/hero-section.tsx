import Link from "next/link"
import { Button } from "@/components/ui/button"

export function HeroSection() {
  return (
    <section className="relative bg-muted py-12 md:py-24">
      <div className="container px-4 md:px-6 mx-auto">
        <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
          <div className="space-y-4">
            <div className="inline-block rounded-lg bg-primary/10 px-3 py-1 text-sm text-primary">
              New Summer Collection
            </div>
            <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
              Discover Premium Quality Products
            </h1>
            <p className="text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
              Experience shopping like never before with our curated collection of high-quality products. Secure
              payments, fast delivery, and exceptional customer service.
            </p>
            <div className="flex flex-col gap-2 min-[400px]:flex-row">
              <Button size="lg" asChild>
                <Link href="/shop">Shop Now</Link>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <Link href="/categories">Explore Categories</Link>
              </Button>
            </div>
            <div className="flex items-center space-x-4 text-sm">
              <div className="flex items-center space-x-1">
                <span className="font-medium">✓</span>
                <span className="text-muted-foreground">Free Shipping</span>
              </div>
              <div className="flex items-center space-x-1">
                <span className="font-medium">✓</span>
                <span className="text-muted-foreground">Secure Payments</span>
              </div>
              <div className="flex items-center space-x-1">
                <span className="font-medium">✓</span>
                <span className="text-muted-foreground">Quality Guarantee</span>
              </div>
            </div>
          </div>
          <div className="flex items-center justify-center">
            <div className="relative w-full aspect-[4/3] overflow-hidden rounded-xl">
              <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-primary/10 z-10"></div>
              <img
                src="https://assets-us-01.kc-usercontent.com/9e9a95c0-1d15-00d5-e878-50f070203f13/0cff492c-5c80-4a29-8fb1-8b1d43aef52d/market-place-by-jasons-slider-1.jpg"
                alt="Featured Products"
                className="object-cover w-full h-full"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

